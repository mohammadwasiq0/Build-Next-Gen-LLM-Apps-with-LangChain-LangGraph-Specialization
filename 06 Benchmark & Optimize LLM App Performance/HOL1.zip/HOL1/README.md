# HOL1: Baseline or Bust – Your First Reproducible Benchmark

**Duration:** 25 minutes

## Learning Objectives

By the end of this activity, you will be able to:

- Run a lightweight benchmarking harness on a real 15-prompt evaluation dataset with fixed settings
- Compute and interpret p50/p95 latency, tokens/sec, and cost per task using exported logs
- Identify outliers and potential bottlenecks in LLM performance from baseline data
- Formulate data-driven hypotheses for the biggest performance wins to pursue next

---

## Quick Start

### 1. Setup Environment

```bash
# Create virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure API Key

```bash
# Copy the example env file
cp .env.example .env

# Edit .env and add your OpenAI API key
# OPENAI_API_KEY=sk-your-actual-key-here
```

### 3. Run the Benchmark

```bash
python run_eval.py --dataset datasets/support_chat_eval_v1.jsonl --variant baseline
```

---

## Project Structure

```
HOL1/
├── datasets/
│   ├── support_chat_eval_v1.jsonl   # Evaluation dataset (JSONL format)
│   └── support_chat_eval_v1.csv     # Evaluation dataset (CSV format)
├── runs/                             # Output directory for benchmark results
├── run_eval.py                       # Main benchmarking harness
├── config.yaml                       # Configuration settings
├── .env.example                      # Template for API credentials
├── requirements.txt                  # Python dependencies
└── README.md                         # This file
```

---

## Activity 1: Run the Benchmark Harness (8–10 minutes)

### Objective
Execute the benchmarking harness on the provided dataset (15 prompts) and generate JSONL + CSV outputs.

### Steps

1. **Inspect the Harness**
   - Open `run_eval.py`
   - Locate sections that: load dataset, call LLM, write outputs

2. **Configure the Run**
   - Verify `config.yaml` settings (model, temperature=0)
   - Ensure API key is set in `.env`

3. **Run the Baseline**
   ```bash
   python run_eval.py --dataset datasets/support_chat_eval_v1.jsonl --variant baseline
   ```

4. **Verify Output Files**
   - Check `runs/` directory for timestamped files
   - Confirm CSV includes: prompt_id, ttft_ms, total_ms, tokens, cost

---

## Activity 2: Analyze Baseline Metrics in pandas (10–12 minutes)

### Objective
Compute summary stats, identify outliers, and build a baseline table.

### Steps

```python
import pandas as pd

# Load your baseline results
df = pd.read_csv("runs/YYYY-MM-DD_HHMMSS_baseline.csv")  # Update filename

# Inspect columns
print(df.columns.tolist())
print(df.head())

# Compute summary statistics
summary = {
    "p50_ttft_ms": df["ttft_ms"].quantile(0.5),
    "p95_ttft_ms": df["ttft_ms"].quantile(0.95),
    "p50_total_ms": df["total_ms"].quantile(0.5),
    "p95_total_ms": df["total_ms"].quantile(0.95),
    "avg_tokens_per_sec": df["tokens_per_sec"].mean(),
    "avg_cost_per_task": df["cost_per_task"].mean(),
}
print(pd.Series(summary))

# Find outliers (slowest requests)
slowest = df.nlargest(3, "total_ms")[["prompt_id", "prompt", "total_ms", "cost_per_task"]]
print("\nSlowest Requests:")
print(slowest)

# Find highest cost requests
highest_cost = df.nlargest(3, "cost_per_task")[["prompt_id", "prompt", "cost_per_task", "output_tokens"]]
print("\nHighest Cost Requests:")
print(highest_cost)
```

---

## Activity 3: Formulate Performance Hypotheses (3–5 minutes)

Based on your analysis, identify:

1. **Two hypotheses** about the largest performance wins available
2. Each hypothesis must reference **specific metrics**
3. Explain **why** each area looks promising for optimization

### Example Hypotheses

- "Prompts with high output token counts (>150 tokens) show 2x higher total_ms. Limiting response length or using a smaller model for simple queries could reduce latency by 30%."

- "TTFT variance is high (p95/p50 ratio > 3x), suggesting network or cold-start issues. Regional endpoint selection or connection pooling may stabilize first-token latency."

---

## Deliverables

### 1. Baseline Report (CSV)
- Generated from Activity 1
- One row per test case with all metrics

### 2. Summary Table
- p50/p95 for ttft_ms and total_ms
- Average tokens_per_sec and cost_per_task
- Outlier counts and patterns

### 3. Reflection (200 words)
- Two hypotheses backed by your metrics
- Specific optimization opportunities identified

### 4. Executive Summary (3-5 sentences)
- Latency distribution observations
- Throughput and cost stability
- Bottleneck indicators
- System readiness assessment

---

## Output Columns Reference

| Column | Description |
|--------|-------------|
| `prompt_id` | Unique identifier for each test case |
| `prompt` | The input prompt text |
| `ttft_ms` | Time to first token (milliseconds) |
| `total_ms` | Total response time (milliseconds) |
| `input_tokens` | Estimated input token count |
| `output_tokens` | Estimated output token count |
| `tokens_per_sec` | Throughput (output tokens / seconds) |
| `cost_per_task` | Estimated cost in USD |
| `error` | Error message if request failed |
| `model` | Model used for the request |
| `variant` | Benchmark variant name |
| `timestamp` | ISO timestamp of the request |

---

## Resources

- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
- [pandas Documentation](https://pandas.pydata.org/docs/)
- [Python timeit/perf_counter](https://docs.python.org/3/library/time.html#time.perf_counter)

