#!/usr/bin/env python3
"""
Baseline Benchmark Harness for LLM Performance Evaluation
=========================================================

This script runs a reproducible benchmark on a dataset of prompts,
measuring latency, throughput, and cost metrics.

Usage:
    python run_eval.py --dataset datasets/support_chat_eval_v1.jsonl --variant baseline

Outputs:
    - JSONL file with detailed per-request metrics
    - CSV file with summary data for analysis
"""

import argparse
import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env file
load_dotenv()


def load_config(config_path: str = "config.yaml") -> dict:
    """Load configuration from YAML file."""
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def load_dataset(dataset_path: str) -> list[dict]:
    """
    Load evaluation dataset from JSONL or CSV file.
    
    Args:
        dataset_path: Path to the dataset file
        
    Returns:
        List of dictionaries with 'id' and 'prompt' keys
    """
    path = Path(dataset_path)
    
    if path.suffix == ".jsonl":
        data = []
        with open(path, "r") as f:
            for line in f:
                if line.strip():
                    data.append(json.loads(line))
        return data
    
    elif path.suffix == ".csv":
        df = pd.read_csv(path)
        return df.to_dict(orient="records")
    
    else:
        raise ValueError(f"Unsupported file format: {path.suffix}")


def call_llm(
    client: OpenAI,
    prompt: str,
    config: dict
) -> dict:
    """
    Call the LLM and measure performance metrics.
    
    Args:
        client: OpenAI client instance
        prompt: The user prompt to send
        config: Configuration dictionary
        
    Returns:
        Dictionary containing response and metrics
    """
    model_config = config["model"]
    system_prompt = config.get("system_prompt", "You are a helpful assistant.")
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]
    
    # Record start time
    start_time = time.perf_counter()
    ttft = None  # Time to first token
    
    # Make streaming request to capture TTFT
    response_chunks = []
    
    try:
        stream = client.chat.completions.create(
            model=model_config["name"],
            messages=messages,
            temperature=model_config.get("temperature", 0),
            max_tokens=model_config.get("max_tokens", 256),
            stream=True
        )
        
        for chunk in stream:
            if ttft is None:
                ttft = (time.perf_counter() - start_time) * 1000  # Convert to ms
            
            if chunk.choices[0].delta.content:
                response_chunks.append(chunk.choices[0].delta.content)
        
        end_time = time.perf_counter()
        total_time = (end_time - start_time) * 1000  # Convert to ms
        
        response_text = "".join(response_chunks)
        
        # Estimate token counts (rough approximation)
        # In production, use tiktoken for accurate counts
        input_tokens = len(prompt.split()) + len(system_prompt.split())
        output_tokens = len(response_text.split())
        
        # Calculate tokens per second
        tokens_per_sec = (output_tokens / (total_time / 1000)) if total_time > 0 else 0
        
        # Calculate cost
        pricing = config.get("pricing", {"input_per_1k": 0.00015, "output_per_1k": 0.0006})
        cost = (input_tokens / 1000 * pricing["input_per_1k"]) + \
               (output_tokens / 1000 * pricing["output_per_1k"])
        
        return {
            "response": response_text,
            "ttft_ms": round(ttft, 2) if ttft else None,
            "total_ms": round(total_time, 2),
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "tokens_per_sec": round(tokens_per_sec, 2),
            "cost_per_task": round(cost, 6),
            "error": None
        }
        
    except Exception as e:
        end_time = time.perf_counter()
        return {
            "response": None,
            "ttft_ms": None,
            "total_ms": round((end_time - start_time) * 1000, 2),
            "input_tokens": 0,
            "output_tokens": 0,
            "tokens_per_sec": 0,
            "cost_per_task": 0,
            "error": str(e)
        }


def run_benchmark(
    dataset_path: str,
    variant: str,
    config: dict,
    output_dir: str = "runs"
) -> tuple[str, str]:
    """
    Run the full benchmark on the dataset.
    
    Args:
        dataset_path: Path to the evaluation dataset
        variant: Name of this benchmark variant (e.g., 'baseline')
        config: Configuration dictionary
        output_dir: Directory to save outputs
        
    Returns:
        Tuple of (jsonl_path, csv_path) for output files
    """
    # Initialize OpenAI client
    client = OpenAI()
    
    # Load dataset
    print(f"Loading dataset from: {dataset_path}")
    dataset = load_dataset(dataset_path)
    print(f"Loaded {len(dataset)} prompts")
    
    # Prepare output directory and files
    Path(output_dir).mkdir(exist_ok=True)
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    base_filename = f"{timestamp}_{variant}"
    
    jsonl_path = Path(output_dir) / f"{base_filename}.jsonl"
    csv_path = Path(output_dir) / f"{base_filename}.csv"
    
    results = []
    
    print(f"\nRunning benchmark: {variant}")
    print(f"Model: {config['model']['name']}")
    print(f"Temperature: {config['model'].get('temperature', 0)}")
    print("-" * 50)
    
    for i, item in enumerate(dataset, 1):
        prompt_id = item.get("id", i)
        prompt = item["prompt"]
        
        print(f"Processing {i}/{len(dataset)}: Prompt ID {prompt_id}...", end=" ", flush=True)
        
        # Call LLM and get metrics
        metrics = call_llm(client, prompt, config)
        
        # Build result record
        result = {
            "prompt_id": prompt_id,
            "prompt": prompt,
            **metrics,
            "model": config["model"]["name"],
            "variant": variant,
            "timestamp": datetime.now().isoformat()
        }
        
        results.append(result)
        
        # Write to JSONL immediately (for crash safety)
        with open(jsonl_path, "a") as f:
            f.write(json.dumps(result) + "\n")
        
        if metrics["error"]:
            print(f"ERROR: {metrics['error']}")
        else:
            print(f"Done ({metrics['total_ms']:.0f}ms, {metrics['tokens_per_sec']:.1f} tok/s)")
    
    # Write CSV summary
    df = pd.DataFrame(results)
    
    # Select columns for CSV (exclude full response for readability)
    csv_columns = [
        "prompt_id", "prompt", "ttft_ms", "total_ms",
        "input_tokens", "output_tokens", "tokens_per_sec",
        "cost_per_task", "error", "model", "variant", "timestamp"
    ]
    
    df[csv_columns].to_csv(csv_path, index=False)
    
    print("-" * 50)
    print(f"\nBenchmark complete!")
    print(f"JSONL output: {jsonl_path}")
    print(f"CSV output: {csv_path}")
    
    # Print quick summary
    print(f"\n--- Quick Summary ---")
    print(f"Total prompts: {len(results)}")
    print(f"Successful: {len([r for r in results if not r['error']])}")
    print(f"Errors: {len([r for r in results if r['error']])}")
    
    if results:
        successful = [r for r in results if not r['error']]
        if successful:
            total_times = [r['total_ms'] for r in successful]
            print(f"p50 total_ms: {pd.Series(total_times).quantile(0.5):.2f}")
            print(f"p95 total_ms: {pd.Series(total_times).quantile(0.95):.2f}")
    
    return str(jsonl_path), str(csv_path)


def main():
    parser = argparse.ArgumentParser(
        description="Run LLM benchmark evaluation harness"
    )
    parser.add_argument(
        "--dataset",
        type=str,
        default="datasets/support_chat_eval_v1.jsonl",
        help="Path to evaluation dataset (JSONL or CSV)"
    )
    parser.add_argument(
        "--variant",
        type=str,
        default="baseline",
        help="Name for this benchmark variant"
    )
    parser.add_argument(
        "--config",
        type=str,
        default="config.yaml",
        help="Path to configuration file"
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="runs",
        help="Directory for output files"
    )
    
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Run benchmark
    run_benchmark(
        dataset_path=args.dataset,
        variant=args.variant,
        config=config,
        output_dir=args.output_dir
    )


if __name__ == "__main__":
    main()

