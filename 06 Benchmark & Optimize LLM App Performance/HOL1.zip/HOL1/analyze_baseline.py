#!/usr/bin/env python3
"""
Baseline Analysis Script for HOL1
=================================

This script helps analyze the benchmark results from run_eval.py.
Use this for Activity 2: Analyzing Baseline Metrics.

Usage:
    python analyze_baseline.py runs/YYYY-MM-DD_HHMMSS_baseline.csv

Or run interactively in Python/Jupyter.
"""

import argparse
import sys
from pathlib import Path

import pandas as pd


def load_results(csv_path: str) -> pd.DataFrame:
    """Load benchmark results from CSV."""
    df = pd.read_csv(csv_path)
    print(f"Loaded {len(df)} records from {csv_path}")
    return df


def compute_summary_stats(df: pd.DataFrame) -> dict:
    """Compute p50, p95, and averages for key metrics."""
    
    # Filter to successful requests only
    success_df = df[df["error"].isna()]
    
    if len(success_df) == 0:
        print("Warning: No successful requests found!")
        return {}
    
    summary = {
        # TTFT metrics
        "p50_ttft_ms": success_df["ttft_ms"].quantile(0.5),
        "p95_ttft_ms": success_df["ttft_ms"].quantile(0.95),
        
        # Total latency metrics
        "p50_total_ms": success_df["total_ms"].quantile(0.5),
        "p95_total_ms": success_df["total_ms"].quantile(0.95),
        
        # Throughput metrics
        "avg_tokens_per_sec": success_df["tokens_per_sec"].mean(),
        "min_tokens_per_sec": success_df["tokens_per_sec"].min(),
        "max_tokens_per_sec": success_df["tokens_per_sec"].max(),
        
        # Cost metrics
        "avg_cost_per_task": success_df["cost_per_task"].mean(),
        "total_cost": success_df["cost_per_task"].sum(),
        
        # Token stats
        "avg_input_tokens": success_df["input_tokens"].mean(),
        "avg_output_tokens": success_df["output_tokens"].mean(),
        
        # Success rate
        "total_requests": len(df),
        "successful_requests": len(success_df),
        "error_count": len(df) - len(success_df),
    }
    
    return summary


def identify_outliers(df: pd.DataFrame, n: int = 3) -> dict:
    """Identify slowest and highest-cost requests."""
    
    success_df = df[df["error"].isna()].copy()
    
    outliers = {
        "slowest_by_total_ms": success_df.nlargest(n, "total_ms")[
            ["prompt_id", "prompt", "total_ms", "output_tokens"]
        ],
        "slowest_by_ttft": success_df.nlargest(n, "ttft_ms")[
            ["prompt_id", "prompt", "ttft_ms"]
        ],
        "highest_cost": success_df.nlargest(n, "cost_per_task")[
            ["prompt_id", "prompt", "cost_per_task", "output_tokens"]
        ],
        "most_tokens": success_df.nlargest(n, "output_tokens")[
            ["prompt_id", "prompt", "output_tokens", "total_ms"]
        ],
    }
    
    return outliers


def build_summary_table(summary: dict) -> pd.DataFrame:
    """Create a formatted summary table."""
    
    rows = [
        ("Time to First Token (p50)", f"{summary['p50_ttft_ms']:.2f} ms"),
        ("Time to First Token (p95)", f"{summary['p95_ttft_ms']:.2f} ms"),
        ("Total Latency (p50)", f"{summary['p50_total_ms']:.2f} ms"),
        ("Total Latency (p95)", f"{summary['p95_total_ms']:.2f} ms"),
        ("Avg Tokens/Sec", f"{summary['avg_tokens_per_sec']:.2f}"),
        ("Avg Cost per Task", f"${summary['avg_cost_per_task']:.6f}"),
        ("Total Cost (all tasks)", f"${summary['total_cost']:.6f}"),
        ("Successful Requests", f"{summary['successful_requests']}/{summary['total_requests']}"),
    ]
    
    return pd.DataFrame(rows, columns=["Metric", "Value"])


def print_analysis_report(df: pd.DataFrame):
    """Print a complete analysis report."""
    
    print("\n" + "=" * 60)
    print("BASELINE BENCHMARK ANALYSIS REPORT")
    print("=" * 60)
    
    # Summary stats
    summary = compute_summary_stats(df)
    summary_table = build_summary_table(summary)
    
    print("\n📊 SUMMARY STATISTICS")
    print("-" * 40)
    print(summary_table.to_string(index=False))
    
    # Outliers
    outliers = identify_outliers(df)
    
    print("\n🐢 SLOWEST REQUESTS (by total_ms)")
    print("-" * 40)
    print(outliers["slowest_by_total_ms"].to_string(index=False))
    
    print("\n⏱️  SLOWEST TTFT")
    print("-" * 40)
    print(outliers["slowest_by_ttft"].to_string(index=False))
    
    print("\n💰 HIGHEST COST")
    print("-" * 40)
    print(outliers["highest_cost"].to_string(index=False))
    
    # Variance analysis
    print("\n📈 VARIANCE ANALYSIS")
    print("-" * 40)
    ttft_ratio = summary["p95_ttft_ms"] / summary["p50_ttft_ms"] if summary["p50_ttft_ms"] > 0 else 0
    total_ratio = summary["p95_total_ms"] / summary["p50_total_ms"] if summary["p50_total_ms"] > 0 else 0
    
    print(f"TTFT p95/p50 ratio: {ttft_ratio:.2f}x")
    print(f"Total latency p95/p50 ratio: {total_ratio:.2f}x")
    
    if ttft_ratio > 3:
        print("⚠️  High TTFT variance detected - potential cold start or network issues")
    if total_ratio > 2:
        print("⚠️  High total latency variance - some prompts take much longer")
    
    print("\n" + "=" * 60)
    print("END OF REPORT")
    print("=" * 60)
    
    return summary, outliers


def main():
    parser = argparse.ArgumentParser(
        description="Analyze baseline benchmark results"
    )
    parser.add_argument(
        "csv_file",
        type=str,
        help="Path to the baseline CSV file"
    )
    
    args = parser.parse_args()
    
    if not Path(args.csv_file).exists():
        print(f"Error: File not found: {args.csv_file}")
        sys.exit(1)
    
    df = load_results(args.csv_file)
    summary, outliers = print_analysis_report(df)


if __name__ == "__main__":
    main()

