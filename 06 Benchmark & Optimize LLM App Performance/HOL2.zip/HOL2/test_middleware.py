#!/usr/bin/env python3
"""
Test Script for Middleware Reliability
======================================

This script helps test the retry/backoff behavior of the middleware
by simulating failures and observing the response.

Usage:
    python test_middleware.py
"""

import time
from middleware import LLMMiddleware


def test_basic_functionality():
    """Test basic call functionality."""
    print("\n" + "=" * 50)
    print("TEST 1: Basic Functionality")
    print("=" * 50)
    
    middleware = LLMMiddleware()
    
    result = middleware.call("What is 2 + 2?")
    
    if result.get("response"):
        print(f"✓ Success: {result['response'][:100]}")
        print(f"  Tokens: {result['input_tokens']} in / {result['output_tokens']} out")
        return True
    else:
        print(f"✗ Failed: {result.get('error')}")
        return False


def test_cache_behavior():
    """Test that caching works correctly."""
    print("\n" + "=" * 50)
    print("TEST 2: Cache Behavior")
    print("=" * 50)
    
    middleware = LLMMiddleware(enable_cache=True)
    prompt = "What is the speed of light?"
    
    # First call - should hit API
    print("First call (should hit API)...")
    start1 = time.perf_counter()
    result1 = middleware.call(prompt)
    time1 = (time.perf_counter() - start1) * 1000
    
    # Second call - should hit cache
    print("Second call (should hit cache)...")
    start2 = time.perf_counter()
    result2 = middleware.call(prompt)
    time2 = (time.perf_counter() - start2) * 1000
    
    print(f"\nFirst call:  {time1:.2f}ms")
    print(f"Second call: {time2:.2f}ms")
    print(f"Speedup: {time1/time2:.1f}x")
    
    if time2 < time1 * 0.1:  # Cache should be at least 10x faster
        print("✓ Cache is working correctly")
        return True
    else:
        print("⚠ Cache may not be working as expected")
        return False


def test_rapid_calls():
    """Test behavior under rapid successive calls."""
    print("\n" + "=" * 50)
    print("TEST 3: Rapid Successive Calls")
    print("=" * 50)
    
    middleware = LLMMiddleware()
    
    prompts = [
        "What is 1 + 1?",
        "What is 2 + 2?",
        "What is 3 + 3?",
        "What is 4 + 4?",
        "What is 5 + 5?",
    ]
    
    results = []
    start = time.perf_counter()
    
    for i, prompt in enumerate(prompts, 1):
        print(f"Call {i}/5: {prompt}")
        result = middleware.call(prompt)
        results.append(result)
    
    total_time = (time.perf_counter() - start) * 1000
    success_count = sum(1 for r in results if r.get("response"))
    
    print(f"\n{success_count}/{len(prompts)} successful")
    print(f"Total time: {total_time:.0f}ms")
    print(f"Average: {total_time/len(prompts):.0f}ms per call")
    
    return success_count == len(prompts)


def test_cache_disabled():
    """Test behavior with cache disabled."""
    print("\n" + "=" * 50)
    print("TEST 4: Cache Disabled")
    print("=" * 50)
    
    middleware = LLMMiddleware(enable_cache=False)
    prompt = "What color is the sky?"
    
    print("Making two identical calls with cache disabled...")
    
    start1 = time.perf_counter()
    result1 = middleware.call(prompt)
    time1 = (time.perf_counter() - start1) * 1000
    
    start2 = time.perf_counter()
    result2 = middleware.call(prompt)
    time2 = (time.perf_counter() - start2) * 1000
    
    print(f"Call 1: {time1:.0f}ms")
    print(f"Call 2: {time2:.0f}ms")
    
    # Both should take similar time (no caching)
    if time2 > time1 * 0.5:
        print("✓ Cache is disabled - both calls hit API")
        return True
    else:
        print("⚠ Unexpected behavior")
        return False


def run_all_tests():
    """Run all tests and summarize results."""
    print("\n" + "=" * 60)
    print("MIDDLEWARE RELIABILITY TESTS")
    print("=" * 60)
    
    tests = [
        ("Basic Functionality", test_basic_functionality),
        ("Cache Behavior", test_cache_behavior),
        ("Rapid Calls", test_rapid_calls),
        ("Cache Disabled", test_cache_disabled),
    ]
    
    results = []
    for name, test_func in tests:
        try:
            passed = test_func()
            results.append((name, passed))
        except Exception as e:
            print(f"✗ Test failed with exception: {e}")
            results.append((name, False))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"  {status}: {name}")
    
    passed_count = sum(1 for _, p in results if p)
    print(f"\n{passed_count}/{len(results)} tests passed")


if __name__ == "__main__":
    run_all_tests()

