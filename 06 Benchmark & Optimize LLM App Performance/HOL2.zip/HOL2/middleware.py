#!/usr/bin/env python3
"""
Resilient LLM Middleware
========================

A production-ready middleware layer for calling LLM endpoints with:
- Retry logic with exponential backoff + jitter
- Timeout handling
- In-memory caching for deterministic calls
- Structured JSONL logging

Usage:
    python middleware.py

Or import and use in your own code:
    from middleware import LLMMiddleware
    client = LLMMiddleware()
    response = client.call("What is Python?")
"""

import hashlib
import json
import os
import random
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

import yaml
from dotenv import load_dotenv
from openai import OpenAI, RateLimitError, APITimeoutError, APIConnectionError, APIStatusError

# Load environment variables
load_dotenv()


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    max_retries: int = 3
    base_delay: float = 1.0  # seconds
    max_delay: float = 16.0  # seconds
    jitter_range: float = 0.2  # ±200ms
    timeout: float = 30.0  # seconds


@dataclass
class RequestLog:
    """Structured log entry for each request."""
    timestamp: str
    prompt_hash: str
    prompt_preview: str
    model: str
    latency_ms: float
    retry_count: int
    input_tokens: int
    output_tokens: int
    cost_estimate: float
    cache_hit: bool
    success: bool
    error: Optional[str] = None
    
    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "prompt_hash": self.prompt_hash,
            "prompt_preview": self.prompt_preview,
            "model": self.model,
            "latency_ms": round(self.latency_ms, 2),
            "retry_count": self.retry_count,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_estimate": round(self.cost_estimate, 6),
            "cache_hit": self.cache_hit,
            "success": self.success,
            "error": self.error
        }


class LLMMiddleware:
    """
    Resilient middleware for LLM API calls.
    
    Features:
    - Automatic retries with exponential backoff + jitter
    - Handles rate limits (429), timeouts, and transient errors
    - In-memory caching for repeated prompts
    - Structured JSONL logging
    """
    
    def __init__(
        self,
        config_path: str = "config.yaml",
        log_dir: str = "logs",
        enable_cache: bool = True
    ):
        """
        Initialize the middleware.
        
        Args:
            config_path: Path to YAML configuration file
            log_dir: Directory for JSONL log files
            enable_cache: Whether to enable response caching
        """
        self.config = self._load_config(config_path)
        self.retry_config = RetryConfig(
            max_retries=self.config.get("retry", {}).get("max_retries", 3),
            base_delay=self.config.get("retry", {}).get("base_delay", 1.0),
            max_delay=self.config.get("retry", {}).get("max_delay", 16.0),
            jitter_range=self.config.get("retry", {}).get("jitter_range", 0.2),
            timeout=self.config.get("retry", {}).get("timeout", 30.0)
        )
        
        self.client = OpenAI(timeout=self.retry_config.timeout)
        self.model = self.config.get("model", {}).get("name", "gpt-4o-mini")
        self.temperature = self.config.get("model", {}).get("temperature", 0)
        self.max_tokens = self.config.get("model", {}).get("max_tokens", 256)
        self.system_prompt = self.config.get("system_prompt", "You are a helpful assistant.")
        
        # Pricing (per 1K tokens)
        pricing = self.config.get("pricing", {})
        self.input_price = pricing.get("input_per_1k", 0.00015)
        self.output_price = pricing.get("output_per_1k", 0.0006)
        
        # Cache setup
        self.enable_cache = enable_cache
        self._cache: dict[str, dict] = {}
        
        # Logging setup
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        self.log_file = self.log_dir / f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jsonl"
    
    def _load_config(self, config_path: str) -> dict:
        """Load configuration from YAML file."""
        try:
            with open(config_path, "r") as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            print(f"Warning: Config file {config_path} not found, using defaults")
            return {}
    
    def _hash_prompt(self, prompt: str) -> str:
        """Generate a hash for cache key."""
        return hashlib.md5(prompt.encode()).hexdigest()[:12]
    
    def _calculate_backoff(self, attempt: int) -> float:
        """
        Calculate backoff delay with exponential increase and jitter.
        
        Formula: min(base * 2^attempt, max_delay) ± jitter
        """
        # Exponential backoff: 1s, 2s, 4s, 8s...
        delay = min(
            self.retry_config.base_delay * (2 ** attempt),
            self.retry_config.max_delay
        )
        
        # Add random jitter (±jitter_range seconds)
        jitter = random.uniform(
            -self.retry_config.jitter_range,
            self.retry_config.jitter_range
        )
        
        return max(0, delay + jitter)
    
    def _should_retry(self, error: Exception) -> bool:
        """Determine if an error is retryable."""
        # Rate limit errors (429)
        if isinstance(error, RateLimitError):
            return True
        
        # Timeout errors
        if isinstance(error, APITimeoutError):
            return True
        
        # Connection errors (network issues)
        if isinstance(error, APIConnectionError):
            return True
        
        # Server errors (5xx)
        if isinstance(error, APIStatusError):
            if 500 <= error.status_code < 600:
                return True
        
        return False
    
    def _log_request(self, log_entry: RequestLog):
        """Write log entry to JSONL file."""
        with open(self.log_file, "a") as f:
            f.write(json.dumps(log_entry.to_dict()) + "\n")
    
    def _estimate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Estimate cost based on token usage."""
        input_cost = (input_tokens / 1000) * self.input_price
        output_cost = (output_tokens / 1000) * self.output_price
        return input_cost + output_cost
    
    def call(
        self,
        prompt: str,
        use_cache: bool = True,
        **kwargs
    ) -> dict:
        """
        Call the LLM with retry logic and caching.
        
        Args:
            prompt: The user prompt
            use_cache: Whether to use cache for this request
            **kwargs: Additional arguments to pass to the API
            
        Returns:
            Dictionary with response and metadata
        """
        start_time = time.perf_counter()
        prompt_hash = self._hash_prompt(prompt)
        prompt_preview = prompt[:50] + "..." if len(prompt) > 50 else prompt
        
        # Check cache first
        if self.enable_cache and use_cache and prompt_hash in self._cache:
            cached = self._cache[prompt_hash]
            latency = (time.perf_counter() - start_time) * 1000
            
            log_entry = RequestLog(
                timestamp=datetime.now().isoformat(),
                prompt_hash=prompt_hash,
                prompt_preview=prompt_preview,
                model=self.model,
                latency_ms=latency,
                retry_count=0,
                input_tokens=cached["input_tokens"],
                output_tokens=cached["output_tokens"],
                cost_estimate=0,  # No cost for cache hit
                cache_hit=True,
                success=True
            )
            self._log_request(log_entry)
            
            print(f"✓ Cache hit for {prompt_hash} ({latency:.1f}ms)")
            return cached
        
        # Attempt API call with retries
        last_error = None
        retry_count = 0
        
        for attempt in range(self.retry_config.max_retries + 1):
            try:
                response = self.client.chat.completions.create(
                    model=kwargs.get("model", self.model),
                    messages=[
                        {"role": "system", "content": self.system_prompt},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=kwargs.get("temperature", self.temperature),
                    max_tokens=kwargs.get("max_tokens", self.max_tokens)
                )
                
                # Success! Extract response data
                end_time = time.perf_counter()
                latency = (end_time - start_time) * 1000
                
                result = {
                    "response": response.choices[0].message.content,
                    "input_tokens": response.usage.prompt_tokens,
                    "output_tokens": response.usage.completion_tokens,
                    "model": response.model,
                    "finish_reason": response.choices[0].finish_reason
                }
                
                cost = self._estimate_cost(result["input_tokens"], result["output_tokens"])
                
                # Cache the result
                if self.enable_cache and use_cache:
                    self._cache[prompt_hash] = result
                
                # Log success
                log_entry = RequestLog(
                    timestamp=datetime.now().isoformat(),
                    prompt_hash=prompt_hash,
                    prompt_preview=prompt_preview,
                    model=result["model"],
                    latency_ms=latency,
                    retry_count=retry_count,
                    input_tokens=result["input_tokens"],
                    output_tokens=result["output_tokens"],
                    cost_estimate=cost,
                    cache_hit=False,
                    success=True
                )
                self._log_request(log_entry)
                
                status = "✓" if retry_count == 0 else f"✓ (after {retry_count} retries)"
                print(f"{status} {prompt_hash}: {latency:.0f}ms, {result['output_tokens']} tokens")
                
                return result
                
            except Exception as e:
                last_error = e
                
                if not self._should_retry(e):
                    # Non-retryable error, fail immediately
                    break
                
                if attempt < self.retry_config.max_retries:
                    retry_count += 1
                    backoff = self._calculate_backoff(attempt)
                    
                    error_type = type(e).__name__
                    print(f"⚠ {error_type}: Retry {retry_count}/{self.retry_config.max_retries} "
                          f"in {backoff:.2f}s...")
                    
                    time.sleep(backoff)
        
        # All retries exhausted or non-retryable error
        end_time = time.perf_counter()
        latency = (end_time - start_time) * 1000
        
        error_msg = str(last_error) if last_error else "Unknown error"
        
        log_entry = RequestLog(
            timestamp=datetime.now().isoformat(),
            prompt_hash=prompt_hash,
            prompt_preview=prompt_preview,
            model=self.model,
            latency_ms=latency,
            retry_count=retry_count,
            input_tokens=0,
            output_tokens=0,
            cost_estimate=0,
            cache_hit=False,
            success=False,
            error=error_msg
        )
        self._log_request(log_entry)
        
        print(f"✗ Failed after {retry_count} retries: {error_msg[:100]}")
        
        return {
            "response": None,
            "error": error_msg,
            "retry_count": retry_count
        }
    
    def get_cache_stats(self) -> dict:
        """Get cache statistics."""
        return {
            "entries": len(self._cache),
            "prompts": list(self._cache.keys())
        }
    
    def clear_cache(self):
        """Clear the response cache."""
        self._cache.clear()
        print("Cache cleared")


def demo_middleware():
    """Demonstrate the middleware functionality."""
    print("=" * 60)
    print("LLM Middleware Demo")
    print("=" * 60)
    
    # Initialize middleware
    middleware = LLMMiddleware()
    
    # Sample prompts for testing
    test_prompts = [
        "What is the capital of France?",
        "Explain photosynthesis in one sentence.",
        "What is 2 + 2?",
        "What is the capital of France?",  # Duplicate - should hit cache
        "Give me a short Python hello world example."
    ]
    
    print(f"\nRunning {len(test_prompts)} test prompts...")
    print("-" * 40)
    
    for i, prompt in enumerate(test_prompts, 1):
        print(f"\n[{i}/{len(test_prompts)}] {prompt[:40]}...")
        result = middleware.call(prompt)
        
        if result.get("response"):
            preview = result["response"][:100].replace("\n", " ")
            print(f"   Response: {preview}...")
    
    # Show cache stats
    print("\n" + "-" * 40)
    print(f"Cache stats: {middleware.get_cache_stats()}")
    print(f"Logs written to: {middleware.log_file}")
    print("=" * 60)


if __name__ == "__main__":
    demo_middleware()

