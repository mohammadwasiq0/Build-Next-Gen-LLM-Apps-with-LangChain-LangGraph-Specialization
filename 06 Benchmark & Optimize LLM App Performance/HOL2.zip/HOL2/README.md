# HOL2: Backend Reliability Challenge - Handle It Smart

**Duration:** 25 minutes

## Learning Objectives

By the end of this activity, you will be able to:

- Implement a minimal LLM middleware with retry, backoff, and timeout handling
- Detect rate-limit (429) and transient errors and respond with jittered backoff
- Add lightweight request logging, including token usage and latency
- Evaluate trade-offs between reliability, latency, and cost when designing a resilient backend

---

## Scenario

Your company builds a lightweight AI assistant used by several hundred customers daily. Recently, traffic increased and your app began failing unpredictably due to API rate-limit errors (HTTP 429). Users saw confusing timeouts and your logs showed bursts of failures without retries.

Your CTO asks you to build the first version of a resilient middleware layer:

> "If we're going to grow, our API calls can't collapse under load. Build the guardrails so requests survive temporary failures."

---

## Quick Start

### 1. Setup Environment

```bash
# Create virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure API Key

```bash
# Copy the example env file
cp env.example .env

# Edit .env and add your OpenAI API key
# OPENAI_API_KEY=sk-your-actual-key-here
```

### 3. Run the Demo

```bash
python middleware.py
```

---

## Project Structure

```
HOL2/
├── logs/                    # JSONL log files (generated during runs)
├── middleware.py            # Main resilient middleware implementation
├── api_wrapper.py           # Optional FastAPI wrapper
├── test_middleware.py       # Test script for reliability testing
├── config.yaml              # Configuration (retry, model, pricing)
├── env.example              # Template for API credentials
├── example_request.json     # Sample LLM request body
├── example_log.jsonl        # Sample log format
├── requirements.txt         # Python dependencies
└── README.md                # This file
```

---

## Activity 1: Build the Resilient Middleware (12–14 minutes)

### Objective
Implement a simple LLM-calling function with retry, backoff, caching, and structured logging.

### Steps

#### Step 1: Define Your Call Function
Review `middleware.py` and locate:
- The `call()` method that handles LLM requests
- Parameters for model, temperature, and timeout

#### Step 2: Understand Retry Logic with Jittered Backoff
The middleware implements:
- **Max retries:** 3 attempts
- **Exponential backoff:** 1s → 2s → 4s → 8s
- **Random jitter:** ±200ms to prevent thundering herd
- **Retryable errors:** 429, 5xx, timeouts

```python
def _calculate_backoff(self, attempt: int) -> float:
    # Exponential: min(base * 2^attempt, max_delay)
    delay = min(self.retry_config.base_delay * (2 ** attempt), self.retry_config.max_delay)
    # Add jitter
    jitter = random.uniform(-self.retry_config.jitter_range, self.retry_config.jitter_range)
    return max(0, delay + jitter)
```

#### Step 3: Explore Caching Behavior
- Cache uses MD5 hash of prompt as key
- Cache hit returns instantly with `cache_hit=True` in logs
- Disable with `enable_cache=False`

#### Step 4: Review Log Structure
Each log entry in `logs/run_*.jsonl` includes:

| Field | Description |
|-------|-------------|
| `timestamp` | ISO timestamp |
| `prompt_hash` | MD5 hash of prompt |
| `latency_ms` | Total request time |
| `retry_count` | Number of retries needed |
| `input_tokens` | Tokens in prompt |
| `output_tokens` | Tokens in response |
| `cost_estimate` | Estimated cost (USD) |
| `cache_hit` | Whether response was cached |
| `success` | Whether request succeeded |
| `error` | Error message (if failed) |

#### Step 5: Test Your Middleware

```bash
# Run the demo
python middleware.py

# Or run the test suite
python test_middleware.py
```

---

## Activity 2: Evaluate Behavior Under Failure (7–8 minutes)

### Objective
Simulate or trigger rate-limit/timeout errors and observe middleware response.

### Steps

#### Step 1: Trigger Mild Load

```python
from middleware import LLMMiddleware

middleware = LLMMiddleware()

# Run 5-10 calls in quick succession
for i in range(5):
    result = middleware.call(f"What is {i} + {i}?")
    print(result.get("response", result.get("error")))
```

#### Step 2: Observe Retry Behavior
- Watch console output for retry messages
- Check if cache helps on repeated prompts
- Note latency differences between cached and fresh calls

#### Step 3: Simulate Errors (Optional)
Temporarily modify `middleware.py` to force errors:

```python
# In the call() method, add before API call:
if attempt == 0:
    raise RateLimitError("Simulated rate limit", response=None, body=None)
```

#### Step 4: Verify Logging Detail

```bash
# View the latest log file
cat logs/run_*.jsonl | python -m json.tool
```

Look for:
- `retry_count` > 0 for recovered failures
- `cache_hit: true` for repeated prompts
- Reasonable `latency_ms` values

---

## Optional: FastAPI Wrapper

Run the middleware as a REST API:

```bash
uvicorn api_wrapper:app --reload --port 8000
```

### Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/chat` | Send prompt, get response |
| GET | `/health` | Health check |
| GET | `/cache` | Cache statistics |
| POST | `/cache/clear` | Clear cache |

### Example Request

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"prompt": "What is Python?"}'
```

---

## Deliverables

### 1. Middleware Script
Your implementation should include:
- ✅ Retry/backoff logic
- ✅ Timeout handling
- ✅ Optional cache behavior
- ✅ Structured logging

### 2. Retry Policy Explanation (100–150 words)
Write a summary covering:
- Why you chose your number of retries (3)
- How exponential + jittered backoff works
- When retries stop vs. fail fast
- How this policy prevents cascading failures

### 3. Performance Reflection (200 words)
Analyze trade-offs between:
- When retries help vs. hurt
- How caching changes latency and cost
- Why p95 behavior matters more than p50
- Impact on real user experience

---

## Key Concepts

### Exponential Backoff
Each retry waits longer: `delay = base * 2^attempt`
- Attempt 0: 1s
- Attempt 1: 2s
- Attempt 2: 4s
- Attempt 3: 8s

### Jitter
Random variation prevents "thundering herd" when many clients retry simultaneously:
```
actual_delay = calculated_delay ± random(0, jitter_range)
```

### Retryable vs Non-Retryable Errors

| Retryable (retry) | Non-Retryable (fail fast) |
|-------------------|---------------------------|
| 429 Rate Limit | 400 Bad Request |
| 500 Server Error | 401 Unauthorized |
| 502 Bad Gateway | 403 Forbidden |
| 503 Service Unavailable | 404 Not Found |
| Timeout | 422 Validation Error |
| Connection Error | |

---

## Configuration Reference

Edit `config.yaml` to customize:

```yaml
retry:
  max_retries: 3        # Maximum retry attempts
  base_delay: 1.0       # Initial backoff (seconds)
  max_delay: 16.0       # Maximum backoff cap
  jitter_range: 0.2     # ±200ms jitter
  timeout: 30.0         # Request timeout
```

---

## Resources

- [OpenAI API Rate Limits](https://platform.openai.com/docs/guides/rate-limits)
- [Exponential Backoff (AWS)](https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/)
- [Google SRE Book - Handling Overload](https://sre.google/sre-book/handling-overload/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)

