#!/usr/bin/env python3
"""
FastAPI Wrapper for LLM Middleware (Optional)
==============================================

A simple REST API wrapper around the resilient middleware.

Usage:
    uvicorn api_wrapper:app --reload --port 8000

Endpoints:
    POST /chat      - Send a prompt and get a response
    GET  /health    - Health check
    GET  /cache     - View cache statistics
    POST /cache/clear - Clear the cache
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional

from middleware import LLMMiddleware

# Initialize FastAPI app
app = FastAPI(
    title="Resilient LLM API",
    description="A resilient LLM API with retry, caching, and logging",
    version="1.0.0"
)

# Initialize middleware (shared instance)
middleware = LLMMiddleware()


class ChatRequest(BaseModel):
    """Request model for chat endpoint."""
    prompt: str
    use_cache: bool = True
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None


class ChatResponse(BaseModel):
    """Response model for chat endpoint."""
    response: Optional[str]
    input_tokens: int = 0
    output_tokens: int = 0
    model: str = ""
    cache_hit: bool = False
    error: Optional[str] = None


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "llm-middleware"}


@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Send a prompt to the LLM and get a response.
    
    The middleware handles:
    - Retry with exponential backoff + jitter
    - Rate limit (429) handling
    - Response caching
    - Structured logging
    """
    kwargs = {}
    if request.temperature is not None:
        kwargs["temperature"] = request.temperature
    if request.max_tokens is not None:
        kwargs["max_tokens"] = request.max_tokens
    
    result = middleware.call(
        prompt=request.prompt,
        use_cache=request.use_cache,
        **kwargs
    )
    
    if result.get("error"):
        return ChatResponse(
            response=None,
            error=result["error"]
        )
    
    return ChatResponse(
        response=result.get("response"),
        input_tokens=result.get("input_tokens", 0),
        output_tokens=result.get("output_tokens", 0),
        model=result.get("model", ""),
        cache_hit=False  # API doesn't expose cache hit directly
    )


@app.get("/cache")
async def get_cache_stats():
    """Get cache statistics."""
    return middleware.get_cache_stats()


@app.post("/cache/clear")
async def clear_cache():
    """Clear the response cache."""
    middleware.clear_cache()
    return {"status": "cache cleared"}


@app.get("/logs")
async def get_log_info():
    """Get current log file information."""
    return {
        "log_file": str(middleware.log_file),
        "log_dir": str(middleware.log_dir)
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

