#!/usr/bin/env python
"""
run_experiment.py

Starter harness for:
"Experiment Orchestrator - From Data to Decision"

- Loads a small eval dataset (JSONL or CSV)
- Runs three variants (A/B/C) over all rows
- Records latency, token usage, and cost estimates
- Writes one CSV per variant into results/
"""

import argparse
import csv
import json
import os
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Any

import pandas as pd
from openai import OpenAI


# -----------------------------
# Variant configuration
# -----------------------------
# Learners can tweak these settings, but the dataset
# and prompts must stay identical for all variants.
VARIANTS: Dict[str, Dict[str, Any]] = {
    "A": {"name": "baseline", "model": "gpt-4o-mini", "temperature": 0.0},
    "B": {"name": "fast", "model": "gpt-4o-mini", "temperature": 0.4},
    "C": {"name": "high_quality", "model": "gpt-4o-mini", "temperature": 0.2},
}

# Optional price table (USD per 1K tokens).
# Set to real values if you want non-zero costs.
MODEL_PRICES = {
    "gpt-4o-mini": {"input": 0.0, "output": 0.0},
    "gpt-4o": {"input": 0.0, "output": 0.0},
}


@dataclass
class RowResult:
    id: str
    prompt: str
    variant: str
    latency_ms: float
    input_tokens: int
    output_tokens: int
    tokens_per_sec: float
    cost_per_task: float
    quality_score: float  # placeholder column


# -----------------------------
# Helpers
# -----------------------------


def load_dataset(path: Path) -> List[dict]:
    """Load JSONL or CSV dataset with 'id' and 'prompt' columns."""
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    if path.suffix.lower() == ".jsonl":
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
        return rows

    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
        return df.to_dict(orient="records")

    raise ValueError(f"Unsupported dataset format: {path.suffix}")


def ensure_results_dir() -> Path:
    results_dir = Path("results")
    results_dir.mkdir(exist_ok=True)
    return results_dir


def get_price(model: str):
    cfg = MODEL_PRICES.get(model, {"input": 0.0, "output": 0.0})
    return cfg["input"], cfg["output"]


# -----------------------------
# Core experiment logic
# -----------------------------


def run_one_variant(
    client: OpenAI,
    rows: List[dict],
    variant_key: str,
    config: Dict[str, Any],
    dataset_name: str,
) -> Path:
    """Run one variant over all rows and write a CSV."""
    model = config["model"]
    temperature = config["temperature"]
    input_price, output_price = get_price(model)

    results: List[RowResult] = []

    for row in rows:
        prompt_id = str(row.get("id", ""))
        prompt_text = row.get("prompt") or row.get("text") or ""

        start = time.perf_counter()
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant for a productivity app.",
                },
                {"role": "user", "content": prompt_text},
            ],
            temperature=temperature,
        )
        end = time.perf_counter()

        latency_ms = (end - start) * 1000.0

        usage = response.usage or None
        input_tokens = int(getattr(usage, "prompt_tokens", 0)) if usage else 0
        output_tokens = int(getattr(usage, "completion_tokens", 0)) if usage else 0

        tokens_per_sec = 0.0
        if latency_ms > 0:
            tokens_per_sec = output_tokens / (latency_ms / 1000.0)

        cost_per_task = 0.0
        if input_price > 0 or output_price > 0:
            cost_per_task = (
                input_tokens * input_price + output_tokens * output_price
            ) / 1000.0

        # Placeholder quality_score (to be filled or computed later)
        quality_score = 0.0

        results.append(
            RowResult(
                id=prompt_id,
                prompt=prompt_text,
                variant=variant_key,
                latency_ms=latency_ms,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                tokens_per_sec=tokens_per_sec,
                cost_per_task=cost_per_task,
                quality_score=quality_score,
            )
        )

    results_dir = ensure_results_dir()
    out_name = f"variant_{variant_key}.csv"
    out_path = results_dir / out_name

    with out_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "id",
                "prompt",
                "variant",
                "latency_ms",
                "input_tokens",
                "output_tokens",
                "tokens_per_sec",
                "cost_per_task",
                "quality_score",
            ],
        )
        writer.writeheader()
        for r in results:
            writer.writerow(asdict(r))

    print(f"[{variant_key}] Saved results to {out_path}")
    return out_path


def run_all_variants(dataset_path: Path):
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY is not set. Please configure your API key before running."
        )

    client = OpenAI()
    rows = load_dataset(dataset_path)

    print(f"Loaded {len(rows)} eval cases from {dataset_path}")
    dataset_name = dataset_path.stem

    for key, cfg in VARIANTS.items():
        print(f"Running variant {key} ({cfg['name']}) on dataset '{dataset_name}'...")
        run_one_variant(client, rows, key, cfg, dataset_name)


# -----------------------------
# CLI
# -----------------------------


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run A/B/C experiments over an eval dataset."
    )
    parser.add_argument(
        "--dataset",
        type=str,
        default="data/eval_cases.jsonl",
        help="Path to eval dataset (.jsonl or .csv). Default: data/eval_cases.jsonl",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    dataset_path = Path(args.dataset)
    run_all_variants(dataset_path)


if __name__ == "__main__":
    main()

