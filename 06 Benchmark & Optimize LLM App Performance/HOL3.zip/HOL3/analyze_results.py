#!/usr/bin/env python3
"""
Experiment Results Analyzer & Visualizer
=========================================

Analyze A/B/C experiment results, create visualizations,
and generate a decision summary.

Usage:
    python analyze_results.py                          # Analyze all variants
    python analyze_results.py --summary-only           # Just show summary
    python analyze_results.py --metric p95_latency_ms  # Custom chart metric
"""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

# Set style for better-looking charts
plt.style.use('seaborn-v0_8-whitegrid')


def load_results(results_dir: str = "results") -> dict[str, pd.DataFrame]:
    """Load all variant results from CSV files."""
    results = {}
    
    for variant in ["A", "B", "C"]:
        path = Path(results_dir) / f"variant_{variant}.csv"
        if path.exists():
            results[variant] = pd.read_csv(path)
            print(f"Loaded variant {variant}: {len(results[variant])} cases")
    
    return results


def load_summary(results_dir: str = "results") -> pd.DataFrame:
    """Load summary metrics if available."""
    path = Path(results_dir) / "summary_metrics.csv"
    if path.exists():
        return pd.read_csv(path)
    return None


def compute_detailed_stats(results: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Compute detailed statistics for each variant."""
    stats = []
    
    for variant, df in results.items():
        successful = df[df["error"].isna()]
        
        stat = {
            "Variant": variant,
            "Name": successful["variant_name"].iloc[0] if len(successful) > 0 else "N/A",
            "Cases": len(df),
            "Success Rate": f"{len(successful)/len(df)*100:.1f}%",
            "p50 Latency": f"{successful['latency_ms'].quantile(0.5):.0f}ms",
            "p95 Latency": f"{successful['latency_ms'].quantile(0.95):.0f}ms",
            "Avg Tokens/s": f"{successful['tokens_per_sec'].mean():.1f}",
            "Avg Cost": f"${successful['cost_per_task'].mean():.5f}",
            "Avg Quality": f"{successful['quality_score'].mean():.1f}",
        }
        stats.append(stat)
    
    return pd.DataFrame(stats)


def create_latency_chart(
    summary: pd.DataFrame,
    output_dir: str = "results"
) -> str:
    """Create p50/p95 latency comparison bar chart."""
    fig, ax = plt.subplots(figsize=(10, 6))
    
    variants = summary["variant"].tolist()
    x = range(len(variants))
    width = 0.35
    
    p50 = summary["p50_latency_ms"].tolist()
    p95 = summary["p95_latency_ms"].tolist()
    
    bars1 = ax.bar([i - width/2 for i in x], p50, width, label='p50', color='#4CAF50', alpha=0.8)
    bars2 = ax.bar([i + width/2 for i in x], p95, width, label='p95', color='#FF5722', alpha=0.8)
    
    ax.set_xlabel('Variant', fontsize=12)
    ax.set_ylabel('Latency (ms)', fontsize=12)
    ax.set_title('Latency Comparison: p50 vs p95', fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels([f"Variant {v}\n({n})" for v, n in 
                       zip(variants, summary["variant_name"].tolist())])
    ax.legend()
    
    # Add value labels on bars
    for bar in bars1:
        height = bar.get_height()
        ax.annotate(f'{height:.0f}',
                   xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points",
                   ha='center', va='bottom', fontsize=9)
    
    for bar in bars2:
        height = bar.get_height()
        ax.annotate(f'{height:.0f}',
                   xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points",
                   ha='center', va='bottom', fontsize=9)
    
    plt.tight_layout()
    
    output_path = Path(output_dir) / "p95_latency.png"
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Saved: {output_path}")
    return str(output_path)


def create_cost_chart(
    summary: pd.DataFrame,
    output_dir: str = "results"
) -> str:
    """Create cost per task comparison chart."""
    fig, ax = plt.subplots(figsize=(8, 6))
    
    variants = summary["variant"].tolist()
    costs = summary["avg_cost_per_task"].tolist()
    
    colors = ['#2196F3', '#4CAF50', '#FF9800']
    bars = ax.bar(variants, [c * 1000 for c in costs], color=colors[:len(variants)], alpha=0.8)
    
    ax.set_xlabel('Variant', fontsize=12)
    ax.set_ylabel('Cost per Task ($ × 1000)', fontsize=12)
    ax.set_title('Average Cost per Task Comparison', fontsize=14, fontweight='bold')
    
    # Add value labels
    for bar, cost in zip(bars, costs):
        height = bar.get_height()
        ax.annotate(f'${cost:.5f}',
                   xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points",
                   ha='center', va='bottom', fontsize=10)
    
    plt.tight_layout()
    
    output_path = Path(output_dir) / "cost_comparison.png"
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Saved: {output_path}")
    return str(output_path)


def create_quality_chart(
    summary: pd.DataFrame,
    output_dir: str = "results"
) -> str:
    """Create quality score comparison chart."""
    fig, ax = plt.subplots(figsize=(8, 6))
    
    variants = summary["variant"].tolist()
    quality = summary["avg_quality_score"].tolist()
    
    colors = ['#9C27B0', '#E91E63', '#673AB7']
    bars = ax.bar(variants, quality, color=colors[:len(variants)], alpha=0.8)
    
    ax.set_xlabel('Variant', fontsize=12)
    ax.set_ylabel('Quality Score', fontsize=12)
    ax.set_title('Average Quality Score Comparison', fontsize=14, fontweight='bold')
    ax.set_ylim(0, 100)
    
    # Add value labels
    for bar in bars:
        height = bar.get_height()
        ax.annotate(f'{height:.1f}',
                   xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points",
                   ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    plt.tight_layout()
    
    output_path = Path(output_dir) / "quality_comparison.png"
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Saved: {output_path}")
    return str(output_path)


def create_winrate_chart(
    summary: pd.DataFrame,
    output_dir: str = "results"
) -> str:
    """Create win-rate vs baseline chart."""
    fig, ax = plt.subplots(figsize=(8, 6))
    
    # Filter to variants B and C (win rate vs A)
    comparison = summary[summary["variant"] != "A"].copy()
    
    if len(comparison) == 0:
        print("No comparison data available for win-rate chart")
        return None
    
    variants = comparison["variant"].tolist()
    win_rates = comparison["win_rate_vs_A"].tolist()
    
    colors = ['#4CAF50' if wr > 50 else '#F44336' for wr in win_rates]
    bars = ax.bar(variants, win_rates, color=colors, alpha=0.8)
    
    # Add 50% reference line
    ax.axhline(y=50, color='gray', linestyle='--', linewidth=1.5, label='Baseline (50%)')
    
    ax.set_xlabel('Variant', fontsize=12)
    ax.set_ylabel('Win Rate vs Baseline A (%)', fontsize=12)
    ax.set_title('Quality Win Rate vs Baseline', fontsize=14, fontweight='bold')
    ax.set_ylim(0, 100)
    ax.legend()
    
    # Add value labels
    for bar, wr in zip(bars, win_rates):
        height = bar.get_height()
        ax.annotate(f'{wr:.1f}%',
                   xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points",
                   ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    plt.tight_layout()
    
    output_path = Path(output_dir) / "winrate_comparison.png"
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Saved: {output_path}")
    return str(output_path)


def create_combined_dashboard(
    summary: pd.DataFrame,
    output_dir: str = "results"
) -> str:
    """Create a combined dashboard with all metrics."""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    variants = summary["variant"].tolist()
    
    # Chart 1: Latency (top-left)
    ax1 = axes[0, 0]
    x = range(len(variants))
    width = 0.35
    ax1.bar([i - width/2 for i in x], summary["p50_latency_ms"], width, 
            label='p50', color='#4CAF50', alpha=0.8)
    ax1.bar([i + width/2 for i in x], summary["p95_latency_ms"], width, 
            label='p95', color='#FF5722', alpha=0.8)
    ax1.set_xticks(x)
    ax1.set_xticklabels(variants)
    ax1.set_ylabel('Latency (ms)')
    ax1.set_title('Latency: p50 vs p95')
    ax1.legend()
    
    # Chart 2: Throughput (top-right)
    ax2 = axes[0, 1]
    ax2.bar(variants, summary["avg_tokens_per_sec"], color='#2196F3', alpha=0.8)
    ax2.set_ylabel('Tokens/sec')
    ax2.set_title('Average Throughput')
    
    # Chart 3: Cost (bottom-left)
    ax3 = axes[1, 0]
    ax3.bar(variants, [c * 1000 for c in summary["avg_cost_per_task"]], 
            color='#FF9800', alpha=0.8)
    ax3.set_ylabel('Cost ($ × 1000)')
    ax3.set_title('Average Cost per Task')
    
    # Chart 4: Quality (bottom-right)
    ax4 = axes[1, 1]
    ax4.bar(variants, summary["avg_quality_score"], color='#9C27B0', alpha=0.8)
    ax4.set_ylabel('Quality Score')
    ax4.set_title('Average Quality Score')
    ax4.set_ylim(0, 100)
    
    plt.suptitle('Experiment Dashboard: A/B/C Comparison', fontsize=16, fontweight='bold')
    plt.tight_layout()
    
    output_path = Path(output_dir) / "experiment_dashboard.png"
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close()
    
    print(f"Saved: {output_path}")
    return str(output_path)


def generate_decision_analysis(summary: pd.DataFrame) -> str:
    """Generate a decision analysis based on the metrics."""
    
    # Find best in each category
    best_latency = summary.loc[summary["p95_latency_ms"].idxmin()]
    best_cost = summary.loc[summary["avg_cost_per_task"].idxmin()]
    best_quality = summary.loc[summary["avg_quality_score"].idxmax()]
    best_throughput = summary.loc[summary["avg_tokens_per_sec"].idxmax()]
    
    analysis = f"""
{'='*60}
DECISION ANALYSIS
{'='*60}

WINNER BY CATEGORY:
  • Fastest (p95):     Variant {best_latency['variant']} ({best_latency['variant_name']}) - {best_latency['p95_latency_ms']:.0f}ms
  • Cheapest:          Variant {best_cost['variant']} ({best_cost['variant_name']}) - ${best_cost['avg_cost_per_task']:.5f}/task
  • Highest Quality:   Variant {best_quality['variant']} ({best_quality['variant_name']}) - {best_quality['avg_quality_score']:.1f}/100
  • Best Throughput:   Variant {best_throughput['variant']} ({best_throughput['variant_name']}) - {best_throughput['avg_tokens_per_sec']:.1f} tok/s

TRADE-OFF ANALYSIS:
"""
    
    # Compare B vs A
    if "B" in summary["variant"].values:
        variant_a = summary[summary["variant"] == "A"].iloc[0]
        variant_b = summary[summary["variant"] == "B"].iloc[0]
        
        latency_diff = ((variant_b["p95_latency_ms"] - variant_a["p95_latency_ms"]) / 
                       variant_a["p95_latency_ms"] * 100)
        cost_diff = ((variant_b["avg_cost_per_task"] - variant_a["avg_cost_per_task"]) / 
                    variant_a["avg_cost_per_task"] * 100)
        quality_diff = variant_b["avg_quality_score"] - variant_a["avg_quality_score"]
        
        analysis += f"""
  Variant B vs A (Fast vs Baseline):
    - Latency: {latency_diff:+.1f}% {'faster' if latency_diff < 0 else 'slower'}
    - Cost: {cost_diff:+.1f}% {'cheaper' if cost_diff < 0 else 'more expensive'}
    - Quality: {quality_diff:+.1f} points
"""
    
    # Compare C vs A
    if "C" in summary["variant"].values:
        variant_a = summary[summary["variant"] == "A"].iloc[0]
        variant_c = summary[summary["variant"] == "C"].iloc[0]
        
        latency_diff = ((variant_c["p95_latency_ms"] - variant_a["p95_latency_ms"]) / 
                       variant_a["p95_latency_ms"] * 100)
        cost_diff = ((variant_c["avg_cost_per_task"] - variant_a["avg_cost_per_task"]) / 
                    variant_a["avg_cost_per_task"] * 100)
        quality_diff = variant_c["avg_quality_score"] - variant_a["avg_quality_score"]
        
        analysis += f"""
  Variant C vs A (High-Quality vs Baseline):
    - Latency: {latency_diff:+.1f}% {'faster' if latency_diff < 0 else 'slower'}
    - Cost: {cost_diff:+.1f}% {'cheaper' if cost_diff < 0 else 'more expensive'}
    - Quality: {quality_diff:+.1f} points
"""
    
    analysis += f"""
{'='*60}
"""
    
    return analysis


def main():
    parser = argparse.ArgumentParser(
        description="Analyze A/B/C experiment results and create visualizations"
    )
    parser.add_argument(
        "--results-dir",
        default="results",
        help="Directory containing result CSV files"
    )
    parser.add_argument(
        "--summary-only",
        action="store_true",
        help="Only show summary, skip chart generation"
    )
    
    args = parser.parse_args()
    
    print("Loading experiment results...")
    results = load_results(args.results_dir)
    
    if not results:
        print("No results found. Run experiments first with: python run_experiments.py")
        return
    
    # Load or compute summary
    summary = load_summary(args.results_dir)
    
    if summary is None:
        print("Summary not found. Computing from results...")
        # Would need to recompute - for now just show detailed stats
        summary = None
    
    # Show detailed statistics
    print("\n" + "="*60)
    print("DETAILED STATISTICS")
    print("="*60)
    
    stats = compute_detailed_stats(results)
    print(stats.to_string(index=False))
    
    if summary is not None:
        # Generate decision analysis
        analysis = generate_decision_analysis(summary)
        print(analysis)
        
        if not args.summary_only:
            # Create visualizations
            print("\nGenerating visualizations...")
            create_latency_chart(summary, args.results_dir)
            create_cost_chart(summary, args.results_dir)
            create_quality_chart(summary, args.results_dir)
            create_winrate_chart(summary, args.results_dir)
            create_combined_dashboard(summary, args.results_dir)
            
            print("\n✓ Analysis complete! Charts saved to results/")


if __name__ == "__main__":
    main()

