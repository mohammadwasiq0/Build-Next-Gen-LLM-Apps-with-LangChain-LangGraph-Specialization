# Ship/No-Ship Decision Memo

**Date:** [YYYY-MM-DD]  
**Author:** [Your Name]  
**Experiment:** A/B/C Variant Comparison

---

## Executive Summary

[One paragraph summarizing your recommendation and key findings]

---

## Recommended Variant

**Recommendation:** Variant [A/B/C] - [Variant Name]

---

## Justification

### Performance Metrics

| Metric | Variant A | Variant B | Variant C | Winner |
|--------|-----------|-----------|-----------|--------|
| p50 Latency | [X]ms | [X]ms | [X]ms | [X] |
| p95 Latency | [X]ms | [X]ms | [X]ms | [X] |
| Avg Tokens/sec | [X] | [X] | [X] | [X] |
| Avg Cost/Task | $[X] | $[X] | $[X] | [X] |
| Quality Score | [X] | [X] | [X] | [X] |
| Win Rate vs A | 100% | [X]% | [X]% | [X] |

### Trade-off Analysis

1. **Speed vs Quality:** [Describe the trade-off observed]

2. **Cost vs Quality:** [Describe the trade-off observed]

3. **Consistency (p95/p50 ratio):** [Describe tail latency behavior]

---

## Rollback Trigger

If any of the following conditions occur within the first [X] hours of deployment, immediately rollback to Variant A (baseline):

- [ ] p95 latency exceeds [X]ms (2x baseline)
- [ ] Error rate exceeds [X]%
- [ ] User-reported quality issues exceed [X] per hour
- [ ] Cost per task exceeds $[X] (1.5x projected)

---

## Next Steps

1. **Immediate:** [What to do right after shipping]

2. **Short-term (1-2 weeks):** [Follow-up experiments or monitoring]

3. **Long-term:** [Future optimization opportunities]

---

## Appendix

### Charts Referenced

- `results/p95_latency.png`
- `results/cost_comparison.png`
- `results/quality_comparison.png`
- `results/experiment_dashboard.png`

### Raw Data

- `results/variant_A.csv`
- `results/variant_B.csv`
- `results/variant_C.csv`
- `results/summary_metrics.csv`

