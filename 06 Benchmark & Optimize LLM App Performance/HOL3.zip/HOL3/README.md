# HOL3: Experiment Orchestrator – From Data to Decision

**Duration:** 25 minutes

## Learning Objectives

By the end of this activity, you will be able to:

- Run A/B/C experiments using a reproducible evaluation harness
- Compute latency percentiles (p50/p95), tokens/sec, cost per task, and win-rate
- Visualize model or prompt performance to compare variants effectively
- Make a structured Ship/No-Ship decision with justification and rollback criteria

---

## Scenario

Your team has tested three LLM configurations for a productivity assistant and now needs a data-driven recommendation on which variant to ship. You will run identical evaluations across all variants, compare performance, and provide a Ship/No-Ship recommendation supported by metrics and a rollback criterion.

---

## Quick Start

### 1. Setup Environment

```bash
# Create virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure API Key

```bash
# Copy the example env file
cp env.example .env

# Edit .env and add your OpenAI API key
```

### 3. Run All Experiments

```bash
python run_experiments.py
```

### 4. Analyze Results

```bash
python analyze_results.py
```

---

## Project Structure

```
HOL3/
├── data/
│   ├── eval_cases.jsonl      # 25 evaluation cases (JSONL)
│   └── eval_cases.csv        # Same data in CSV format
├── results/                   # Output directory
│   ├── variant_A.csv         # Results for each variant
│   ├── variant_B.csv
│   ├── variant_C.csv
│   ├── summary_metrics.csv   # Aggregated comparison
│   └── *.png                 # Generated charts
├── run_experiments.py        # Main experiment harness
├── analyze_results.py        # Analysis & visualization
├── config.yaml               # Variant configurations
├── decision_memo_template.md # Ship/No-Ship template
├── env.example               # API key template
├── requirements.txt          # Python dependencies
└── README.md                 # This file
```

---

## Variant Configurations

| Variant | Name | Temperature | Max Tokens | Strategy |
|---------|------|-------------|------------|----------|
| A | Baseline | 0.7 | 256 | Standard configuration |
| B | Fast | 0.3 | 128 | Optimized for speed |
| C | High-Quality | 0.5 | 512 | Optimized for detail |

---

## Activity 1: Run A/B/C Experiments (10–12 minutes)

### Objective
Execute the harness for three variants and collect clean, comparable metrics.

### Steps

#### Step 1: Run All Variants

```bash
# Run all variants (A, B, C)
python run_experiments.py

# Or run specific variants
python run_experiments.py --variant A B
python run_experiments.py --variant C
```

#### Step 2: Verify Outputs

Check that these files are created in `results/`:
- `variant_A.csv`
- `variant_B.csv`
- `variant_C.csv`
- `summary_metrics.csv`

#### Step 3: Review Summary Metrics

The summary includes:

| Metric | Description |
|--------|-------------|
| `p50_latency_ms` | Median latency |
| `p95_latency_ms` | 95th percentile latency |
| `avg_tokens_per_sec` | Throughput |
| `avg_cost_per_task` | Cost efficiency |
| `avg_quality_score` | Quality heuristic (0-100) |
| `win_rate_vs_A` | % of cases where variant beats baseline |

---

## Activity 2: Visualize & Interpret Results (7–8 minutes)

### Objective
Create charts that highlight differences clearly.

### Steps

#### Step 1: Generate All Charts

```bash
python analyze_results.py
```

This creates:
- `p95_latency.png` - Latency comparison
- `cost_comparison.png` - Cost per task
- `quality_comparison.png` - Quality scores
- `winrate_comparison.png` - Win rate vs baseline
- `experiment_dashboard.png` - Combined dashboard

#### Step 2: Interpret Results

Look for:
- **Fastest variant** (lowest p95 latency)
- **Cheapest variant** (lowest cost/task)
- **Highest quality** (best quality score)
- **Trade-offs** (speed vs quality, cost vs quality)

#### Step 3: Custom Charts

```python
import pandas as pd
import matplotlib.pyplot as plt

# Load summary
summary = pd.read_csv("results/summary_metrics.csv")

# Create custom chart
plt.figure(figsize=(10, 6))
plt.bar(summary["variant"], summary["avg_quality_score"])
plt.title("Quality Score by Variant")
plt.ylabel("Quality Score")
plt.savefig("results/custom_chart.png")
```

---

## Activity 3: Make Ship/No-Ship Decision (5–7 minutes)

### Objective
Produce a decision memo with justification and rollback criteria.

### Steps

#### Step 1: Review Decision Template

Open `decision_memo_template.md` and fill in:
- Your recommended variant
- Performance metrics table
- Trade-off analysis
- Rollback triggers
- Next steps

#### Step 2: Key Decision Factors

Consider:
1. **Does B or C beat baseline A?** (win-rate > 50%)
2. **Is the latency acceptable?** (p95 < threshold)
3. **Is the cost justified?** (ROI on quality)
4. **Is consistency good?** (p95/p50 ratio < 2x)

#### Step 3: Define Rollback Criteria

Example rollback triggers:
- p95 latency > 2x baseline
- Error rate > 5%
- User complaints > threshold
- Cost > 150% of projected

---

## Deliverables

### 1. Metrics Table (CSV)
`results/summary_metrics.csv` containing:
- p50/p95 latency
- tokens/sec
- cost/task
- win-rate vs baseline

### 2. Visualization Chart
One or more charts in `results/`:
- `experiment_dashboard.png` (recommended)
- Or individual metric charts

### 3. Decision Memo (250 words)
Include:
- Recommended variant
- Justification with metrics
- Rollback trigger
- Next-step improvement

---

## Key Metrics Explained

### p50 vs p95 Latency
- **p50 (median):** Typical user experience
- **p95:** Worst 5% of requests (tail latency)
- **Why p95 matters:** Bad tail latency frustrates users and indicates instability

### Win-Rate
- Percentage of test cases where variant beats baseline on quality
- **> 50%:** Variant is generally better
- **< 50%:** Variant is generally worse

### Quality Score
A heuristic combining:
- Response length
- Structure (lists, paragraphs)
- Key explanatory words

*In production, use human evaluation or LLM-as-judge*

---

## Example Decision

```
RECOMMENDATION: Ship Variant B (Fast)

JUSTIFICATION:
- 40% faster p95 latency (800ms vs 1200ms)
- 35% lower cost per task
- Quality score only 5 points lower (still acceptable)
- Win-rate of 42% is acceptable for speed-focused use case

ROLLBACK IF:
- p95 latency exceeds 1500ms
- User complaints about quality exceed 10/day
- Error rate exceeds 2%

NEXT STEPS:
- Monitor quality feedback for 1 week
- Consider Variant C for complex queries only
```

---

## Configuration Reference

Edit `config.yaml` to customize variants:

```yaml
variant_a:
  name: "Baseline"
  model: "gpt-4o-mini"
  temperature: 0.7
  max_tokens: 256
  system_prompt: "You are a helpful assistant."

variant_b:
  name: "Fast"
  model: "gpt-4o-mini"
  temperature: 0.3
  max_tokens: 128
  system_prompt: "You are a helpful assistant. Be concise."
```

---

## Resources

- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
- [pandas Documentation](https://pandas.pydata.org/docs/)
- [matplotlib Gallery](https://matplotlib.org/stable/gallery/index.html)
- [A/B Testing Best Practices](https://www.optimizely.com/optimization-glossary/ab-testing/)

