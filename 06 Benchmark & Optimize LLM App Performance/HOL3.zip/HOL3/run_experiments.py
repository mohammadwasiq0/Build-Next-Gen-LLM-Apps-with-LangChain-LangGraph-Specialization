#!/usr/bin/env python3
"""
Experiment Orchestrator - A/B/C Evaluation Harness
==================================================

Run controlled experiments across multiple LLM configurations
and collect comparable metrics for decision-making.

Usage:
    python run_experiments.py                    # Run all variants
    python run_experiments.py --variant A        # Run specific variant
    python run_experiments.py --variant A B      # Run multiple variants
"""

import argparse
import json
import os
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables
load_dotenv()


def load_config(config_path: str = "config.yaml") -> dict:
    """Load experiment configuration."""
    with open(config_path, "r") as f:
        return yaml.safe_load(f)


def load_dataset(dataset_path: str) -> list[dict]:
    """Load evaluation dataset from JSONL or CSV."""
    path = Path(dataset_path)
    
    if path.suffix == ".jsonl":
        data = []
        with open(path, "r") as f:
            for line in f:
                if line.strip():
                    data.append(json.loads(line))
        return data
    elif path.suffix == ".csv":
        df = pd.read_csv(path)
        return df.to_dict(orient="records")
    else:
        raise ValueError(f"Unsupported format: {path.suffix}")


def compute_quality_score(response: str, config: dict) -> float:
    """
    Compute a simple quality score based on heuristics.
    
    In production, use human evaluation or LLM-as-judge.
    This is a simplified proxy for demonstration.
    """
    if not response:
        return 0.0
    
    quality_config = config.get("quality", {})
    min_length = quality_config.get("min_response_length", 50)
    keywords = quality_config.get("preferred_keywords", [])
    
    score = 0.0
    
    # Length score (0-40 points)
    length = len(response)
    if length >= min_length:
        score += min(40, 20 + (length / 20))
    else:
        score += (length / min_length) * 20
    
    # Structure score (0-30 points)
    if "\n" in response:
        score += 10  # Has line breaks
    if any(c in response for c in ["•", "-", "1.", "2.", "*"]):
        score += 10  # Has list formatting
    if len(response.split(".")) > 2:
        score += 10  # Has multiple sentences
    
    # Keyword score (0-30 points)
    keyword_count = sum(1 for kw in keywords if kw.lower() in response.lower())
    score += min(30, keyword_count * 10)
    
    return min(100, score)


def run_variant(
    client: OpenAI,
    dataset: list[dict],
    variant_config: dict,
    config: dict,
    variant_name: str,
    output_dir: str = "results"
) -> pd.DataFrame:
    """
    Run evaluation for a single variant.
    
    Args:
        client: OpenAI client
        dataset: List of evaluation cases
        variant_config: Configuration for this variant
        config: Full configuration
        variant_name: Name of the variant (A, B, C)
        output_dir: Directory for output files
        
    Returns:
        DataFrame with results for this variant
    """
    # Set seed for reproducibility
    seed = config.get("experiment", {}).get("seed", 42)
    random.seed(seed)
    
    results = []
    pricing = config.get("pricing", {"input_per_1k": 0.00015, "output_per_1k": 0.0006})
    
    print(f"\n{'='*60}")
    print(f"Running Variant {variant_name}: {variant_config['name']}")
    print(f"Model: {variant_config['model']}")
    print(f"Temperature: {variant_config['temperature']}")
    print(f"Max Tokens: {variant_config['max_tokens']}")
    print(f"{'='*60}")
    
    for i, case in enumerate(dataset, 1):
        case_id = case.get("id", i)
        prompt = case["prompt"]
        category = case.get("category", "general")
        
        print(f"[{i}/{len(dataset)}] Case {case_id}...", end=" ", flush=True)
        
        start_time = time.perf_counter()
        
        try:
            response = client.chat.completions.create(
                model=variant_config["model"],
                messages=[
                    {"role": "system", "content": variant_config["system_prompt"]},
                    {"role": "user", "content": prompt}
                ],
                temperature=variant_config["temperature"],
                max_tokens=variant_config["max_tokens"],
                seed=seed
            )
            
            end_time = time.perf_counter()
            latency_ms = (end_time - start_time) * 1000
            
            response_text = response.choices[0].message.content
            input_tokens = response.usage.prompt_tokens
            output_tokens = response.usage.completion_tokens
            
            # Calculate metrics
            tokens_per_sec = output_tokens / (latency_ms / 1000) if latency_ms > 0 else 0
            cost = (input_tokens / 1000 * pricing["input_per_1k"]) + \
                   (output_tokens / 1000 * pricing["output_per_1k"])
            quality_score = compute_quality_score(response_text, config)
            
            result = {
                "case_id": case_id,
                "prompt": prompt[:100] + "..." if len(prompt) > 100 else prompt,
                "category": category,
                "variant": variant_name,
                "variant_name": variant_config["name"],
                "response": response_text,
                "latency_ms": round(latency_ms, 2),
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "tokens_per_sec": round(tokens_per_sec, 2),
                "cost_per_task": round(cost, 6),
                "quality_score": round(quality_score, 2),
                "error": None,
                "timestamp": datetime.now().isoformat()
            }
            
            print(f"{latency_ms:.0f}ms, quality={quality_score:.0f}")
            
        except Exception as e:
            end_time = time.perf_counter()
            latency_ms = (end_time - start_time) * 1000
            
            result = {
                "case_id": case_id,
                "prompt": prompt[:100] + "..." if len(prompt) > 100 else prompt,
                "category": category,
                "variant": variant_name,
                "variant_name": variant_config["name"],
                "response": None,
                "latency_ms": round(latency_ms, 2),
                "input_tokens": 0,
                "output_tokens": 0,
                "tokens_per_sec": 0,
                "cost_per_task": 0,
                "quality_score": 0,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
            
            print(f"ERROR: {str(e)[:50]}")
        
        results.append(result)
    
    # Create DataFrame and save
    df = pd.DataFrame(results)
    
    Path(output_dir).mkdir(exist_ok=True)
    output_path = Path(output_dir) / f"variant_{variant_name}.csv"
    df.to_csv(output_path, index=False)
    
    print(f"\nSaved to: {output_path}")
    
    return df


def compute_summary_metrics(results: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """
    Compute summary metrics across all variants.
    
    Args:
        results: Dictionary mapping variant name to DataFrame
        
    Returns:
        Summary DataFrame with aggregated metrics
    """
    summaries = []
    
    # Get baseline for win-rate calculation
    baseline_df = results.get("A")
    
    for variant_name, df in results.items():
        successful = df[df["error"].isna()]
        
        if len(successful) == 0:
            continue
        
        summary = {
            "variant": variant_name,
            "variant_name": successful["variant_name"].iloc[0],
            "total_cases": len(df),
            "successful": len(successful),
            "error_rate": round((len(df) - len(successful)) / len(df) * 100, 2),
            "p50_latency_ms": round(successful["latency_ms"].quantile(0.5), 2),
            "p95_latency_ms": round(successful["latency_ms"].quantile(0.95), 2),
            "avg_tokens_per_sec": round(successful["tokens_per_sec"].mean(), 2),
            "avg_cost_per_task": round(successful["cost_per_task"].mean(), 6),
            "total_cost": round(successful["cost_per_task"].sum(), 6),
            "avg_quality_score": round(successful["quality_score"].mean(), 2),
            "p50_quality_score": round(successful["quality_score"].quantile(0.5), 2),
        }
        
        # Calculate win-rate vs baseline (quality comparison)
        if baseline_df is not None and variant_name != "A":
            baseline_successful = baseline_df[baseline_df["error"].isna()]
            
            # Merge on case_id and compare quality
            merged = successful.merge(
                baseline_successful[["case_id", "quality_score"]],
                on="case_id",
                suffixes=("", "_baseline")
            )
            
            if len(merged) > 0:
                wins = (merged["quality_score"] > merged["quality_score_baseline"]).sum()
                win_rate = wins / len(merged) * 100
                summary["win_rate_vs_A"] = round(win_rate, 2)
            else:
                summary["win_rate_vs_A"] = None
        else:
            summary["win_rate_vs_A"] = 100.0 if variant_name == "A" else None
        
        summaries.append(summary)
    
    return pd.DataFrame(summaries)


def main():
    parser = argparse.ArgumentParser(
        description="Run A/B/C experiments for LLM evaluation"
    )
    parser.add_argument(
        "--variant",
        nargs="*",
        default=["A", "B", "C"],
        choices=["A", "B", "C"],
        help="Which variants to run (default: all)"
    )
    parser.add_argument(
        "--config",
        default="config.yaml",
        help="Path to configuration file"
    )
    parser.add_argument(
        "--dataset",
        default=None,
        help="Override dataset path from config"
    )
    parser.add_argument(
        "--output-dir",
        default="results",
        help="Directory for output files"
    )
    
    args = parser.parse_args()
    
    # Load configuration
    config = load_config(args.config)
    
    # Determine dataset path
    dataset_path = args.dataset or config.get("experiment", {}).get(
        "dataset", "data/eval_cases.jsonl"
    )
    
    # Load dataset
    print(f"Loading dataset from: {dataset_path}")
    dataset = load_dataset(dataset_path)
    print(f"Loaded {len(dataset)} evaluation cases")
    
    # Initialize client
    client = OpenAI()
    
    # Map variant letters to config keys
    variant_map = {
        "A": "variant_a",
        "B": "variant_b",
        "C": "variant_c"
    }
    
    # Run selected variants
    results = {}
    
    for variant in args.variant:
        config_key = variant_map[variant]
        variant_config = config[config_key]
        
        df = run_variant(
            client=client,
            dataset=dataset,
            variant_config=variant_config,
            config=config,
            variant_name=variant,
            output_dir=args.output_dir
        )
        
        results[variant] = df
    
    # Compute and save summary metrics
    if results:
        print("\n" + "="*60)
        print("COMPUTING SUMMARY METRICS")
        print("="*60)
        
        summary_df = compute_summary_metrics(results)
        
        summary_path = Path(args.output_dir) / "summary_metrics.csv"
        summary_df.to_csv(summary_path, index=False)
        
        print("\n" + summary_df.to_string(index=False))
        print(f"\nSaved summary to: {summary_path}")
    
    print("\n✓ Experiment complete!")


if __name__ == "__main__":
    main()

