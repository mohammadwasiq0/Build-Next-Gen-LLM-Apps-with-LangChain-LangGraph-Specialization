# Optimize & Ship Your LLM App v1.0 – Starter Project

This repo contains the starter code and data for the **Course-End Project** "Optimize & Ship Your LLM App v1.0".

Learners will:

- Run a reproducible baseline with `run_eval.py`
- Optimize prompts (`prompts/`)
- Implement resilient middleware (`client/middleware.py`)
- Run A/B/C experiments and export CSVs (`runs/`)
- Write a Ship/No-Ship decision memo

## Project Structure

```text
.
├── README.md
├── requirements.txt
├── run_eval.py
├── config
│   ├── variants.yaml
│   ├── baseline.yaml
│   └── experiment.yaml
├── data
│   ├── test_cases.jsonl
│   └── test_cases_small.jsonl
├── prompts
│   ├── baseline_prompts.md
│   └── prompts_v2.md
├── client
│   ├── middleware.py
│   └── config.py
├── runs
│   ├── baseline_A.csv
│   ├── variant_B.csv
│   └── variant_C.csv
└── logs
    └── (JSONL logs written at runtime)
```

## Quick Start

### Install dependencies

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Set your API key

```bash
export OPENAI_API_KEY="your_key_here"      # macOS / Linux
# or
setx OPENAI_API_KEY "your_key_here"        # Windows (new shell required)
```

### Run a baseline for Variant A

```bash
python run_eval.py --variant A --dataset data/test_cases.jsonl
```

This will:
- Read config/variants.yaml
- Call the middleware in client/middleware.py
- Write per-request logs to logs/
- Export a metrics CSV to runs/variant_A.csv

### Experiment with prompts and middleware

- Update prompts/prompts_v2.md
- Tune client/middleware.py and config/variants.yaml
- Re-run run_eval.py for variants A/B/C

### Analyze results

Use pandas or your favorite tool to compute:
- p50/p95 latency
- tokens/sec
- cost per task
- win-rate vs baseline

Charts can be saved into runs/ (e.g. runs/p95_latency.png).

**Note:** This starter harness is intentionally minimal and safe. It is designed for educational use and can be adapted to any compatible LLM SDK.

