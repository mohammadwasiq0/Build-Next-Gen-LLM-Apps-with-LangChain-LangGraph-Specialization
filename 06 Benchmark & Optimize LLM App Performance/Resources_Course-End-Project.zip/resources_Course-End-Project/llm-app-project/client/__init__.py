# Client module for LLM middleware

