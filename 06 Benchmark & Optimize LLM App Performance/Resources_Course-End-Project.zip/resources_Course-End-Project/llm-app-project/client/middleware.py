import json
import os
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from openai import OpenAI

from client.config import LLMConfig, get_api_key

LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(exist_ok=True)

# Simple in-memory cache keyed by (variant, prompt)
_CACHE: Dict[str, Dict[str, Any]] = {}

_client: Optional[OpenAI] = None


def _get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(api_key=get_api_key())
    return _client


def _build_config(config_dict: Dict[str, Any]) -> LLMConfig:
    return LLMConfig(
        model=config_dict.get("model", "gpt-4o-mini"),
        temperature=float(config_dict.get("temperature", 0.4)),
        max_output_tokens=int(config_dict.get("max_output_tokens", 512)),
        timeout_s=int(config_dict.get("timeout_s", 20)),
        max_retries=int(config_dict.get("max_retries", 2)),
        cache_enabled=bool(config_dict.get("cache_enabled", True)),
    )


def call_llm(prompt: str, variant_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Minimal, production-minded middleware wrapper around an LLM call.

    - Adds retries with jittered backoff on transient errors
    - Adds optional in-memory caching for deterministic prompts
    - Returns structured metrics for the evaluation harness
    """
    cfg = _build_config(config)
    cache_key = f"{variant_name}::{prompt}"
    start_wall = time.perf_counter()

    # Check cache
    if cfg.cache_enabled and cache_key in _CACHE:
        cached = _CACHE[cache_key].copy()
        cached.update(
            {
                "latency_ms": (time.perf_counter() - start_wall) * 1000.0,
                "cache_hit": True,
                "retry_count": 0,
            }
        )
        return cached

    client = _get_client()
    retries = 0
    base_backoff = 1.0  # seconds
    last_error: Optional[str] = None

    while True:
        try:
            t0 = time.perf_counter()

            # NOTE: Adjust this block if your environment uses a different SDK
            response = client.chat.completions.create(
                model=cfg.model,
                messages=[
                    {"role": "system", "content": "You are a helpful AI writing assistant."},
                    {"role": "user", "content": prompt},
                ],
                temperature=cfg.temperature,
                max_tokens=cfg.max_output_tokens,
                timeout=cfg.timeout_s,
            )

            t1 = time.perf_counter()
            latency_ms = (t1 - t0) * 1000.0

            choice = response.choices[0]
            content = choice.message.content or ""
            usage = response.usage

            input_tokens = usage.prompt_tokens
            output_tokens = usage.completion_tokens
            total_tokens = usage.total_tokens

            # Simple, configurable cost estimate example (dummy values)
            # Replace with your provider's official pricing if desired.
            cost_per_1k = 0.015  # placeholder
            cost_usd = (total_tokens / 1000.0) * cost_per_1k

            result: Dict[str, Any] = {
                "raw_response": content,
                "latency_ms": latency_ms,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
                "cost_usd": cost_usd,
                "quality_score": 0.0,  # learners can later fill in heuristic scores if needed
                "retry_count": retries,
                "cache_hit": False,
            }

            # Cache successful deterministic responses
            if cfg.cache_enabled:
                _CACHE[cache_key] = result.copy()

            # Also append a low-level log line (optional secondary log, separate from run_eval)
            log_record = {
                "ts": datetime.utcnow().isoformat(),
                "variant": variant_name,
                "prompt": prompt,
                "latency_ms": latency_ms,
                "tokens": total_tokens,
                "cost_usd": cost_usd,
                "retry_count": retries,
            }
            with open(LOGS_DIR / "middleware_trace.jsonl", "a", encoding="utf-8") as f:
                f.write(json.dumps(log_record) + "\n")

            return result

        except Exception as exc:  # noqa: BLE001
            last_error = repr(exc)
            retries += 1
            if retries > cfg.max_retries:
                latency_ms = (time.perf_counter() - start_wall) * 1000.0
                return {
                    "raw_response": None,
                    "latency_ms": latency_ms,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "cost_usd": 0.0,
                    "quality_score": 0.0,
                    "retry_count": retries,
                    "cache_hit": False,
                    "error": last_error,
                }

            # Jittered exponential backoff
            backoff = base_backoff * (2 ** (retries - 1))
            jitter = random.uniform(-0.25, 0.25) * backoff
            sleep_for = max(0.0, backoff + jitter)
            time.sleep(sleep_for)

