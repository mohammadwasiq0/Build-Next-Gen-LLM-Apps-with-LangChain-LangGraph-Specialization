import os
from dataclasses import dataclass


@dataclass
class LLMConfig:
    model: str
    temperature: float
    max_output_tokens: int
    timeout_s: int
    max_retries: int
    cache_enabled: bool = True


def get_api_key() -> str:
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set. Please export it before running the harness.")
    return key

