import argparse
import csv
import json
import os
import time
from datetime import datetime
from pathlib import Path
from statistics import median
from typing import Any, Dict, List

import yaml
from tqdm import tqdm

from client.middleware import call_llm

DATASET_DEFAULT = "data/test_cases.jsonl"
VARIANTS_CONFIG = "config/variants.yaml"
RUNS_DIR = Path("runs")
LOGS_DIR = Path("logs")


def load_variants(path: str) -> Dict[str, Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)["variants"]


def load_dataset(path: str) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            items.append(json.loads(line))
    return items


def percentile(values: List[float], p: float) -> float:
    """Simple percentile implementation for small lists."""
    if not values:
        return 0.0
    values_sorted = sorted(values)
    k = (len(values_sorted) - 1) * (p / 100.0)
    f = int(k)
    c = min(f + 1, len(values_sorted) - 1)
    if f == c:
        return values_sorted[int(k)]
    d0 = values_sorted[f] * (c - k)
    d1 = values_sorted[c] * (k - f)
    return d0 + d1


def run_experiment(variant: str, dataset_path: str) -> str:
    RUNS_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)

    variants = load_variants(VARIANTS_CONFIG)
    if variant not in variants:
        raise ValueError(f"Unknown variant '{variant}'. Available: {list(variants.keys())}")

    cfg = variants[variant]
    dataset = load_dataset(dataset_path)

    timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    csv_path = RUNS_DIR / f"variant_{variant}_{timestamp}.csv"
    jsonl_path = LOGS_DIR / f"run_{variant}_{timestamp}.jsonl"

    rows: List[Dict[str, Any]] = []
    latencies_ms: List[float] = []
    tokens_per_sec: List[float] = []
    costs_usd: List[float] = []

    with open(jsonl_path, "w", encoding="utf-8") as log_f:
        for item in tqdm(dataset, desc=f"Variant {variant}", unit="case"):
            case_id = item.get("id")
            prompt = item.get("prompt") or item.get("input")

            start = time.perf_counter()
            result = call_llm(prompt=prompt, variant_name=variant, config=cfg)
            elapsed = (time.perf_counter() - start) * 1000.0  # ms

            latency_ms = float(result.get("latency_ms", elapsed))
            input_tokens = int(result.get("input_tokens", 0))
            output_tokens = int(result.get("output_tokens", 0))
            total_tokens = input_tokens + output_tokens
            cost_usd = float(result.get("cost_usd", 0.0))
            quality_score = float(result.get("quality_score", 0.0))
            retry_count = int(result.get("retry_count", 0))
            cache_hit = bool(result.get("cache_hit", False))

            latencies_ms.append(latency_ms)
            if latency_ms > 0 and total_tokens > 0:
                tokens_per_sec.append((total_tokens / latency_ms) * 1000.0)
            costs_usd.append(cost_usd)

            log_record = {
                "timestamp": datetime.utcnow().isoformat(),
                "case_id": case_id,
                "variant": variant,
                "prompt": prompt,
                "latency_ms": latency_ms,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total_tokens,
                "cost_usd": cost_usd,
                "quality_score": quality_score,
                "retry_count": retry_count,
                "cache_hit": cache_hit,
                "raw_response": result.get("raw_response", None),
            }
            log_f.write(json.dumps(log_record) + "\n")

            rows.append(
                {
                    "case_id": case_id,
                    "variant": variant,
                    "latency_ms": latency_ms,
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "total_tokens": total_tokens,
                    "tokens_per_sec": (total_tokens / latency_ms) * 1000.0
                    if latency_ms > 0 and total_tokens > 0
                    else 0.0,
                    "cost_usd": cost_usd,
                    "quality_score": quality_score,
                    "retry_count": retry_count,
                    "cache_hit": cache_hit,
                }
            )

    # Aggregate stats row
    p50 = percentile(latencies_ms, 50)
    p95 = percentile(latencies_ms, 95)
    median_tps = median(tokens_per_sec) if tokens_per_sec else 0.0
    total_cost = sum(costs_usd)

    summary_row = {
        "case_id": "SUMMARY",
        "variant": variant,
        "latency_ms": p50,
        "input_tokens": "",
        "output_tokens": "",
        "total_tokens": "",
        "tokens_per_sec": median_tps,
        "cost_usd": total_cost,
        "quality_score": "",
        "retry_count": "",
        "cache_hit": "",
        "p50_latency_ms": p50,
        "p95_latency_ms": p95,
    }
    rows.append(summary_row)

    fieldnames = list(rows[0].keys())
    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"\nSaved metrics to {csv_path}")
    print(f"Saved logs to {jsonl_path}")
    return str(csv_path)


def main():
    parser = argparse.ArgumentParser(description="Run A/B/C evaluation for LLM variants.")
    parser.add_argument("--variant", "-v", required=True, help="Variant ID (e.g., A, B, C)")
    parser.add_argument(
        "--dataset", "-d", default=DATASET_DEFAULT, help=f"Path to JSONL dataset (default: {DATASET_DEFAULT})"
    )
    args = parser.parse_args()

    if not Path(args.dataset).exists():
        raise SystemExit(f"Dataset not found: {args.dataset}")

    run_experiment(args.variant, args.dataset)


if __name__ == "__main__":
    main()

