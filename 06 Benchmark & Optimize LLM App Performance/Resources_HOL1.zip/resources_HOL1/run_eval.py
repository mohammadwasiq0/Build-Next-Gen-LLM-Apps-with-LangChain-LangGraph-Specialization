#!/usr/bin/env python
import argparse
import csv
import json
import os
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List

import pandas as pd
from openai import OpenAI


# -----------------------------
# Configuration & Pricing
# -----------------------------

DEFAULT_MODEL = "gpt-4o-mini"  # learners can override via --model

# Optional price table (USD per 1K tokens) – tweak as needed or leave at 0
MODEL_PRICES = {
    # "model-name": {"input": 0.0005, "output": 0.0015},
    DEFAULT_MODEL: {"input": 0.0, "output": 0.0},  # set real prices if desired
}


@dataclass
class EvalResult:
    id: str
    prompt: str
    ttft_ms: float
    total_ms: float
    input_tokens: int
    output_tokens: int
    tokens_per_sec: float
    cost_per_task: float


# -----------------------------
# Helper functions
# -----------------------------


def load_dataset(path: Path) -> List[dict]:
    """Load JSONL or CSV dataset with columns/id+prompt."""
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")

    if path.suffix.lower() == ".jsonl":
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
        return rows

    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
        return df.to_dict(orient="records")

    raise ValueError(f"Unsupported dataset format: {path.suffix}")


def get_prices(model: str):
    cfg = MODEL_PRICES.get(model, {"input": 0.0, "output": 0.0})
    return cfg["input"], cfg["output"]


def ensure_runs_dir() -> Path:
    runs_dir = Path("runs")
    runs_dir.mkdir(exist_ok=True)
    return runs_dir


# -----------------------------
# Main evaluation logic
# -----------------------------


def run_benchmark(
    dataset_path: Path,
    model: str,
    variant: str,
    max_samples: int | None = None,
) -> Path:
    client = OpenAI()  # uses OPENAI_API_KEY and OPENAI_BASE_URL if set

    rows = load_dataset(dataset_path)
    if max_samples is not None:
        rows = rows[:max_samples]

    input_price, output_price = get_prices(model)
    results: List[EvalResult] = []

    for row in rows:
        prompt_id = str(row.get("id", ""))
        prompt_text = row.get("prompt") or row.get("text") or ""

        start = time.perf_counter()
        # Simple non-streaming call for teaching purposes
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful customer support assistant."},
                {"role": "user", "content": prompt_text},
            ],
            temperature=0.0,
        )
        end = time.perf_counter()

        total_ms = (end - start) * 1000.0
        ttft_ms = total_ms  # simplification for this lab

        usage = response.usage or None
        input_tokens = int(getattr(usage, "prompt_tokens", 0)) if usage else 0
        output_tokens = int(getattr(usage, "completion_tokens", 0)) if usage else 0

        tokens_per_sec = 0.0
        if total_ms > 0:
            tokens_per_sec = output_tokens / (total_ms / 1000.0)

        cost_per_task = 0.0
        if input_price > 0 or output_price > 0:
            cost_per_task = (
                input_tokens * input_price + output_tokens * output_price
            ) / 1000.0

        results.append(
            EvalResult(
                id=prompt_id,
                prompt=prompt_text,
                ttft_ms=ttft_ms,
                total_ms=total_ms,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                tokens_per_sec=tokens_per_sec,
                cost_per_task=cost_per_task,
            )
        )

    runs_dir = ensure_runs_dir()
    out_csv = runs_dir / f"{variant}_baseline.csv"

    with out_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "id",
                "prompt",
                "ttft_ms",
                "total_ms",
                "input_tokens",
                "output_tokens",
                "tokens_per_sec",
                "cost_per_task",
            ],
        )
        writer.writeheader()
        for r in results:
            writer.writerow(asdict(r))

    print(f"Saved baseline CSV to: {out_csv}")
    return out_csv


# -----------------------------
# CLI entry point
# -----------------------------


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run a simple LLM baseline benchmark over a small dataset."
    )
    parser.add_argument(
        "--dataset",
        type=str,
        required=True,
        help="Path to dataset file (.jsonl or .csv).",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=DEFAULT_MODEL,
        help=f"Model name to use (default: {DEFAULT_MODEL}).",
    )
    parser.add_argument(
        "--variant",
        type=str,
        default="baseline",
        help="Variant name (used in output filename).",
    )
    parser.add_argument(
        "--max-samples",
        type=int,
        default=None,
        help="Optional: limit number of rows evaluated.",
    )
    return parser.parse_args()


def main():
    args = parse_args()

    dataset_path = Path(args.dataset)

    # Basic sanity checks for Coursera learners
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError(
            "OPENAI_API_KEY environment variable is not set. "
            "Please configure your key before running this script."
        )

    run_benchmark(
        dataset_path=dataset_path,
        model=args.model,
        variant=args.variant,
        max_samples=args.max_samples,
    )


if __name__ == "__main__":
    main()

