#!/bin/bash

# Run all three variants sequentially
python run_variant.py --model gpt-4o-mini --variant A --output results_A
python run_variant.py --model gpt-4o-mini --variant B --output results_B
python run_variant.py --model gpt-4o-mini --variant C --output results_C

echo "All variants complete!"

