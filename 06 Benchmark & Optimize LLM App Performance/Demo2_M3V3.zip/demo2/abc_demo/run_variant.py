import json, time, csv, argparse
from pathlib import Path
from statistics import median
from openai import OpenAI

client = OpenAI()


def score_quality(output):
    # Placeholder heuristic score.
    # Real system would use rubric / evals / regex / LLM judge.
    return 1.0 if len(output) > 20 else 0.0


def run(model, variant, output_dir, eval_file):
    out = Path(output_dir)
    out.mkdir(exist_ok=True)
    raw_path = out / "raw.jsonl"
    csv_path = out / "summary.csv"

    rows = []

    with open(eval_file, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            item = json.loads(line)
            prompt = item["input"]

            start = time.time()
            stream = client.chat.completions.create(
                model=model,
                messages=[{"role": "system", "content": f"Variant {variant} system prompt."},
                          {"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=150,
                stream=True
            )

            first = None
            tokens = 0
            output = ""

            for chunk in stream:
                if first is None:
                    first = time.time()
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    output += delta.content
                    tokens += 1

            end = time.time()

            ttft = first - start
            total = end - start
            tps = tokens / total if total > 0 else 0
            cost = tokens * 0.0000005
            quality = score_quality(output)

            row = {
                "id": item["id"],
                "variant": variant,
                "ttft": ttft,
                "total_latency": total,
                "tokens_out": tokens,
                "tokens_per_sec": tps,
                "cost_usd": cost,
                "quality_score": quality,
            }
            rows.append(row)

            with open(raw_path, "a") as raw:
                raw.write(json.dumps(row) + "\n")

    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print(f"[{variant}] Done → {output_dir}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--model")
    p.add_argument("--variant")
    p.add_argument("--output")
    p.add_argument("--eval", default="eval_set.jsonl")
    args = p.parse_args()

    run(args.model, args.variant, args.output, args.eval)

