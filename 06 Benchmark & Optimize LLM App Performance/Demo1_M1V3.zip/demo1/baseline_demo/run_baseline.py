import json, time, csv, argparse
from pathlib import Path
from openai import OpenAI


client = OpenAI()


def run_eval(model, eval_path, output_path):
    output_path = Path(output_path)
    output_path.mkdir(exist_ok=True)

    raw_log_path = output_path / "raw_logs.jsonl"
    csv_path = output_path / "summary.csv"

    rows = []
    with open(eval_path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            item = json.loads(line)
            prompt = item["input"]

            start = time.time()
            stream = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=150,
                stream=True
            )

            first_token_time = None
            tokens = 0
            output = ""

            for chunk in stream:
                if first_token_time is None:
                    first_token_time = time.time()
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    output += delta.content
                    tokens += 1

            end = time.time()

            ttft = first_token_time - start
            total = end - start
            tokens_per_sec = tokens / total if total > 0 else 0
            cost = (tokens * 0.0000005)

            row = {
                "id": item["id"],
                "prompt": prompt,
                "ttft": ttft,
                "total_latency": total,
                "tokens_out": tokens,
                "tokens_per_sec": tokens_per_sec,
                "cost_usd": cost
            }
            rows.append(row)

            with open(raw_log_path, "a") as log:
                log.write(json.dumps(row) + "\n")

    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)

    print(f"Export complete → {output_path}")
    print(f"Raw logs → {raw_log_path}")
    print(f"CSV → {csv_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    run_eval(args.model, "eval_set.jsonl", args.output)

