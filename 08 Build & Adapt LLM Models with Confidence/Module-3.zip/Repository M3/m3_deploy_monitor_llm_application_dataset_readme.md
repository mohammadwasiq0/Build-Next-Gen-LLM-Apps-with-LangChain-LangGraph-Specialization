# HealthTech Inc Sample Payloads & Security Policies

## Overview
This file contains synthetic payloads that simulate clinician document submissions and security policies for the HealthTech Inc deployment lab. No full dataset is required; these samples support security testing and monitoring exercises.

## Contents
- **Sample Prompts**: Synthetic clinician prompts including safe queries and malicious injection attempts
- **Security Policies**: Prompt blocklists, rate limits, and authentication requirements
- **Monitoring Thresholds**: SLA targets for latency, error rates, and pod stability

## Usage Notes
- Use sample prompts to test prompt filtering middleware
- Reference security policies when configuring ingress and middleware
- Apply monitoring thresholds when defining alert rules
- All payloads are synthetic; no real PHI is included

## Security Testing
The sample includes both safe prompts and malicious injection attempts to validate defense mechanisms:
- Safe prompts simulate legitimate clinician queries
- Malicious prompts test prompt injection filters
- Use these to verify security controls before load testing

## File Location
These assets are referenced in the starter notebook under `./assets/` directory. Security policies are also available as YAML files for Kubernetes configuration.

