# TechCorp Intent Dataset

## Overview
This dataset contains anonymized customer intent logs and product metadata for TechCorp's retail assistant evaluation. The data supports architecture comparison across encoder-only, decoder-only, and encoder-decoder LLM families.

## Dataset Schema
- `conversation_id`: Unique identifier for each conversation (e.g., "tc_001")
- `intent`: Labeled intent category (product_lookup, order_status, returns)
- `user_message`: Customer query text
- `assistant_response`: Generated response text
- `response_time_ms`: Historical response latency in milliseconds
- `tokens`: Token count for the conversation (capped at 1,024)
- `satisfaction`: Customer satisfaction rating (1-5 scale)

## Usage Notes
- Load using `prepare_dataloaders()` utility in the starter notebook
- Split into train/validation sets maintaining intent distribution
- Ensure compliance with TechCorp privacy policy when storing derived metrics
- Token counts are pre-computed; use for cost modeling exercises

## Sample Size
The full dataset contains 1,000 conversations. This sample file includes 10 representative examples. The complete dataset will be provided in the Coursera lab environment.

## Privacy & Compliance
All customer identifiers have been anonymized. Sensitive PII has been redacted. Follow TechCorp's data handling checklist when exporting metrics or sharing results.

