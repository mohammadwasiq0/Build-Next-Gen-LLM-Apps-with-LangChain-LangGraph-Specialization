# RetailCorp Customer Conversations Dataset

## Overview
This dataset contains 5,000 anonymized customer service conversations from RetailCorp, labeled with intents, policy references, and satisfaction ratings. The data supports LoRA fine-tuning for policy-aware customer service models.

## Dataset Schema
- `conversation_id`: Unique identifier (e.g., "rc_001")
- `text`: Full conversation transcript (customer + assistant)
- `intent`: Labeled intent category (returns, sizing, warranty)
- `policy_tag`: Policy category tag for stratification
- `policy_reference`: Specific policy code referenced (e.g., "RET-30D", "WAR-12M")
- `satisfaction`: Customer satisfaction rating (1-5 scale)
- `tokens`: Token count (under 1,024 as specified)

## Usage Notes
- Load using `load_retailcorp_dataset()` helper in the starter notebook
- Use `stratified_split()` with `stratify_column='policy_tag'` to maintain balanced splits
- Follow data handling checklist when exporting metrics
- Sensitive attributes are redacted; document any limitations for SME review

## Sample Size
The full dataset contains 5,000 conversations. This sample file includes 10 representative examples. The complete dataset will be provided in the Coursera lab environment (Google Colab with GPU).

## Policy Tags Distribution
- `returns`: Return and exchange inquiries
- `sizing`: Product sizing questions
- `warranty`: Warranty claims and coverage questions

## Privacy & Compliance
All customer identifiers have been anonymized. Sensitive PII has been redacted. Follow RetailCorp's data handling checklist when exporting metrics or sharing results externally.

