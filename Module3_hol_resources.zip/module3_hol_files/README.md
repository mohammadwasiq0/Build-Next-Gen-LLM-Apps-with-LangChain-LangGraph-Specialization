# Module 3 HOL - Resource Files

## Files Included:

### 1. legal_documents_corpus.csv
- **Description**: LegalTech legal documents corpus with 10,000 documents
- **Columns**:
  - `document_id`: Unique identifier (e.g., LEG00001)
  - `title`: Document title
  - `content_summary`: Brief content description
  - `document_type`: Type (Case Law, Statute, Regulation, Legal Brief, Contract Template)
  - `jurisdiction`: Jurisdiction (Federal, California, New York, Texas, Delaware)
  - `practice_area`: Legal practice area (Corporate Law, IP, Employment, Tax, Environmental, Contract)
  - `year`: Year filed/published

### 2. legal_test_queries.csv
- **Description**: 100 legal search queries with ground truth relevance labels
- **Columns**:
  - `query_id`: Unique query identifier (LQ001-LQ100)
  - `query_text`: Legal search query (e.g., "patent infringement cases", "wrongful termination")
  - `practice_area`: Expected practice area
  - `relevant_document_ids`: Comma-separated list of relevant document IDs (ground truth)

## Usage Instructions:

### Multi-Model Benchmarking:

You'll benchmark **4 models**:
1. **all-mpnet-base-v2** (current baseline, 768 dim)
2. **all-MiniLM-L6-v2** (384 dim, faster)
3. **gte-small** (384 dim, optimized)
4. **e5-small-v2** (384 dim, alternative)

For each model:
- Generate embeddings for legal corpus
- Build FAISS index
- Calculate accuracy (recall@5, recall@10, MRR)
- Measure latency (p50, p95, p99)
- Estimate costs (compute, storage)

## Example Code:

```python
import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
import time
import numpy as np

# Load data
documents = pd.read_csv('legal_documents_corpus.csv')
test_queries = pd.read_csv('legal_test_queries.csv')

# Parse ground truth
test_queries['relevant_ids'] = test_queries['relevant_document_ids'].str.split(',')

# Benchmark Model 1: all-mpnet-base-v2
model = SentenceTransformer('all-mpnet-base-v2')

# Generate embeddings
start = time.time()
doc_embeddings = model.encode(documents['content_summary'].tolist(), show_progress_bar=True)
embedding_time = time.time() - start

# Build FAISS index
index = faiss.IndexFlatL2(doc_embeddings.shape[1])
index.add(doc_embeddings.astype('float32'))

# Measure query latency
latencies = []
for _, row in test_queries.iterrows():
    query_emb = model.encode([row['query_text']])
    start = time.time()
    D, I = index.search(query_emb.astype('float32'), 10)
    latencies.append((time.time() - start) * 1000)  # Convert to ms

print(f"Model: all-mpnet-base-v2")
print(f"p50 latency: {np.percentile(latencies, 50):.2f}ms")
print(f"p95 latency: {np.percentile(latencies, 95):.2f}ms")
print(f"p99 latency: {np.percentile(latencies, 99):.2f}ms")

# Calculate recall@10
# ... (implement recall calculation)
```

## Expected Results:

### Model Performance Comparison:
- **all-mpnet-base-v2**: Best accuracy (89% recall@10), slowest (250ms p95)
- **all-MiniLM-L6-v2**: Good balance (87% recall@10), fast (55ms p95)
- **gte-small**: Similar to MiniLM, possibly faster
- **e5-small-v2**: Competitive performance

### Cost Analysis:
- One-time: Embedding generation for 2M docs
- Monthly recurring: Query serving compute + storage
- Scale to 50M queries/month

## Deliverables:

1. Benchmark results table (all 4 models)
2. Cost model spreadsheet (12-month projections)
3. Weighted decision matrix (latency 40%, accuracy 35%, cost 15%, complexity 10%)
4. Executive recommendation (which model to deploy and why)
