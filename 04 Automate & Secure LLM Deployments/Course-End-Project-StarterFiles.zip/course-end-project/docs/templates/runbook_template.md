# Operational Runbook: TechUnicorn LLM Platform

**Version:** 1.0  
**Last Updated:** [Date]  
**Owner:** Platform Team

---

## 1. Service Overview

| Attribute | Value |
|-----------|-------|
| Service Name | LLM Platform API |
| Team | Platform Engineering |
| Slack Channel | #llm-platform-ops |
| PagerDuty | [Service ID] |
| Dashboards | [Grafana Link] |

---

## 2. Architecture Quick Reference

```
[ALB] → [K8s Ingress] → [API Pods] → [Redis Cache]
                                   → [LLM APIs]
```

**Key Endpoints:**
- Production: `https://api.llm-platform.example.com`
- Staging: `https://staging-api.llm-platform.example.com`

---

## 3. Common Operations

### 3.1 Check Service Health
```bash
# Via kubectl
kubectl get pods -n llm-platform
kubectl logs -f deployment/llm-platform-api -n llm-platform

# Via API
curl https://api.llm-platform.example.com/health
curl https://api.llm-platform.example.com/ready
```

### 3.2 Scale Deployment
```bash
# Manual scale
kubectl scale deployment llm-platform-api -n llm-platform --replicas=10

# Check HPA status
kubectl get hpa -n llm-platform
```

### 3.3 View Logs
```bash
# Kubernetes logs
kubectl logs -f -l app=llm-platform-api -n llm-platform --tail=100

# CloudWatch (via AWS CLI)
aws logs tail /aws/eks/cluster/app --follow
```

### 3.4 Restart Service
```bash
kubectl rollout restart deployment/llm-platform-api -n llm-platform
kubectl rollout status deployment/llm-platform-api -n llm-platform
```

---

## 4. Incident Response

### 4.1 Severity Definitions

| Severity | Definition | Response Time | Example |
|----------|------------|---------------|---------|
| SEV1 | Complete outage | 15 min | All API requests failing |
| SEV2 | Major degradation | 30 min | >50% error rate |
| SEV3 | Minor issue | 2 hours | Single endpoint slow |
| SEV4 | Cosmetic | Next business day | Dashboard issue |

### 4.2 Escalation Path

1. **On-Call Engineer** → Initial response
2. **Team Lead** → SEV1/SEV2 escalation (15 min)
3. **Engineering Manager** → Extended outage (1 hour)
4. **VP Engineering** → Customer-impacting (2 hours)

### 4.3 Incident Checklist

- [ ] Acknowledge alert in PagerDuty
- [ ] Join incident Slack channel
- [ ] Check dashboard for symptoms
- [ ] Identify affected components
- [ ] Implement mitigation
- [ ] Communicate status to stakeholders
- [ ] Document root cause
- [ ] Schedule post-mortem

---

## 5. Troubleshooting Guide

### 5.1 High Latency

**Symptoms:** P95 latency > 2s

**Diagnosis:**
```bash
# Check pod resource usage
kubectl top pods -n llm-platform

# Check HPA status
kubectl describe hpa llm-platform-api -n llm-platform

# Check Redis connection
kubectl exec -it [pod-name] -n llm-platform -- redis-cli ping
```

**Resolution:**
1. Scale up pods if CPU/Memory high
2. Check Redis cache hit rate
3. Verify LLM provider status
4. Review recent deployments

### 5.2 High Error Rate

**Symptoms:** Error rate > 1%

**Diagnosis:**
```bash
# Check error logs
kubectl logs -l app=llm-platform-api -n llm-platform | grep ERROR

# Check recent errors in Grafana
# Dashboard: LLM Platform Overview > Error Rate panel
```

**Resolution:**
1. Identify error type (4xx vs 5xx)
2. Check rate limiting (429 errors)
3. Verify API key validity
4. Check downstream services

### 5.3 Pod CrashLoopBackOff

**Diagnosis:**
```bash
kubectl describe pod [pod-name] -n llm-platform
kubectl logs [pod-name] -n llm-platform --previous
```

**Common Causes:**
- Missing secrets/configmaps
- Resource limits too low
- Liveness probe failing
- Application startup error

### 5.4 Deployment Failure

**Diagnosis:**
```bash
kubectl rollout status deployment/llm-platform-api -n llm-platform
kubectl describe deployment llm-platform-api -n llm-platform
```

**Resolution:**
```bash
# Rollback to previous version
kubectl rollout undo deployment/llm-platform-api -n llm-platform
```

---

## 6. Maintenance Procedures

### 6.1 Planned Maintenance Window
- **Window:** Sundays 2:00-4:00 AM UTC
- **Notification:** 72 hours advance notice
- **Approval:** Team Lead

### 6.2 Certificate Renewal
```bash
# Check expiration
kubectl get certificate -n llm-platform

# Certificates auto-renew via cert-manager
```

### 6.3 Secret Rotation
```bash
# Update in Secrets Manager
aws secretsmanager update-secret --secret-id llm-api-keys --secret-string '...'

# Restart pods to pick up new secrets
kubectl rollout restart deployment/llm-platform-api -n llm-platform
```

---

## 7. Monitoring & Alerts

### 7.1 Key Metrics

| Metric | Warning | Critical |
|--------|---------|----------|
| Error Rate | > 1% | > 5% |
| P95 Latency | > 1s | > 2s |
| Pod Restarts | > 2/hour | > 5/hour |
| CPU Usage | > 70% | > 90% |
| Memory Usage | > 80% | > 95% |

### 7.2 Alert Response

| Alert | First Action | Escalate If |
|-------|--------------|-------------|
| HighErrorRate | Check logs | Persists > 10 min |
| HighLatency | Check resources | Persists > 5 min |
| PodCrashLoop | Check pod logs | > 3 restarts |

---

## 8. Contacts

| Role | Name | Contact |
|------|------|---------|
| On-Call | [Rotation] | PagerDuty |
| Team Lead | [Name] | [Email] |
| AWS Support | - | [Case Link] |
| OpenAI Support | - | [Support Portal] |

---

## 9. Appendices

- A: Network Diagram
- B: API Reference
- C: Change Log
