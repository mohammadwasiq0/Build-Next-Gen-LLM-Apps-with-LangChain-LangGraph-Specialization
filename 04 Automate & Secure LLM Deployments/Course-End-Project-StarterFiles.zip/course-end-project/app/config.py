"""
TechUnicorn LLM Platform - Configuration Management
Centralized configuration with environment variable support
"""

import os
from typing import Optional


class Config:
    """Application configuration from environment variables"""
    
    # ==========================================================================
    # Application Settings
    # ==========================================================================
    APP_NAME: str = os.getenv('APP_NAME', 'TechUnicorn LLM Platform')
    APP_VERSION: str = os.getenv('APP_VERSION', '1.0.0')
    ENVIRONMENT: str = os.getenv('ENVIRONMENT', 'development')
    DEBUG: bool = os.getenv('DEBUG', 'false').lower() == 'true'
    LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')
    
    # ==========================================================================
    # Server Settings
    # ==========================================================================
    HOST: str = os.getenv('HOST', '0.0.0.0')
    PORT: int = int(os.getenv('PORT', 8000))
    WORKERS: int = int(os.getenv('WORKERS', 4))
    
    # ==========================================================================
    # Security Settings
    # ==========================================================================
    API_KEY: Optional[str] = os.getenv('API_KEY')
    SECRET_KEY: str = os.getenv('SECRET_KEY', 'change-me-in-production')
    JWT_SECRET: Optional[str] = os.getenv('JWT_SECRET')
    ALLOWED_ORIGINS: list = os.getenv('ALLOWED_ORIGINS', '*').split(',')
    
    # ==========================================================================
    # Database & Cache Settings
    # ==========================================================================
    REDIS_URL: Optional[str] = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    CACHE_TTL: int = int(os.getenv('CACHE_TTL', 3600))  # 1 hour default
    
    # ==========================================================================
    # LLM Model Settings
    # ==========================================================================
    DEFAULT_MODEL: str = os.getenv('DEFAULT_MODEL', 'gpt-4')
    
    # OpenAI
    OPENAI_API_KEY: Optional[str] = os.getenv('OPENAI_API_KEY')
    OPENAI_ORG_ID: Optional[str] = os.getenv('OPENAI_ORG_ID')
    OPENAI_API_BASE: str = os.getenv('OPENAI_API_BASE', 'https://api.openai.com/v1')
    
    # Anthropic
    ANTHROPIC_API_KEY: Optional[str] = os.getenv('ANTHROPIC_API_KEY')
    
    # Local Llama (vLLM or similar)
    LLAMA_API_BASE: str = os.getenv('LLAMA_API_BASE', 'http://localhost:8080')
    
    # ==========================================================================
    # Rate Limiting
    # ==========================================================================
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv('RATE_LIMIT_PER_MINUTE', 60))
    RATE_LIMIT_PER_HOUR: int = int(os.getenv('RATE_LIMIT_PER_HOUR', 1000))
    RATE_LIMIT_PER_DAY: int = int(os.getenv('RATE_LIMIT_PER_DAY', 10000))
    
    # ==========================================================================
    # Monitoring Settings
    # ==========================================================================
    PROMETHEUS_PORT: int = int(os.getenv('PROMETHEUS_PORT', 9090))
    ENABLE_METRICS: bool = os.getenv('ENABLE_METRICS', 'true').lower() == 'true'
    METRICS_PREFIX: str = os.getenv('METRICS_PREFIX', 'llm_platform')
    
    # ==========================================================================
    # AWS Settings (for production)
    # ==========================================================================
    AWS_REGION: str = os.getenv('AWS_REGION', 'us-east-1')
    AWS_ACCESS_KEY_ID: Optional[str] = os.getenv('AWS_ACCESS_KEY_ID')
    AWS_SECRET_ACCESS_KEY: Optional[str] = os.getenv('AWS_SECRET_ACCESS_KEY')
    
    # Secrets Manager
    SECRETS_MANAGER_SECRET_ID: Optional[str] = os.getenv('SECRETS_MANAGER_SECRET_ID')
    
    # CloudWatch
    CLOUDWATCH_LOG_GROUP: str = os.getenv('CLOUDWATCH_LOG_GROUP', '/llm-platform/app')
    
    # ==========================================================================
    # Security Validation Settings
    # ==========================================================================
    PROMPT_MAX_LENGTH: int = int(os.getenv('PROMPT_MAX_LENGTH', 32000))
    INJECTION_RISK_THRESHOLD: float = float(os.getenv('INJECTION_RISK_THRESHOLD', 0.7))
    ENABLE_CONTENT_FILTERING: bool = os.getenv('ENABLE_CONTENT_FILTERING', 'true').lower() == 'true'
    
    # ==========================================================================
    # Cost Optimization Settings
    # ==========================================================================
    ENABLE_RESPONSE_CACHING: bool = os.getenv('ENABLE_RESPONSE_CACHING', 'true').lower() == 'true'
    ENABLE_MODEL_ROUTING: bool = os.getenv('ENABLE_MODEL_ROUTING', 'true').lower() == 'true'
    SIMPLE_QUERY_MODEL: str = os.getenv('SIMPLE_QUERY_MODEL', 'llama')  # Route simple queries to cheaper model
    COMPLEX_QUERY_MODEL: str = os.getenv('COMPLEX_QUERY_MODEL', 'gpt-4')
    
    @classmethod
    def validate(cls) -> list:
        """Validate required configuration"""
        errors = []
        
        if cls.ENVIRONMENT == 'production':
            if cls.SECRET_KEY == 'change-me-in-production':
                errors.append("SECRET_KEY must be set in production")
            
            if not cls.API_KEY:
                errors.append("API_KEY must be set in production")
            
            if not cls.OPENAI_API_KEY and not cls.ANTHROPIC_API_KEY:
                errors.append("At least one LLM API key must be configured")
        
        return errors
    
    @classmethod
    def to_dict(cls, include_secrets: bool = False) -> dict:
        """Export configuration as dictionary"""
        config = {
            'app_name': cls.APP_NAME,
            'app_version': cls.APP_VERSION,
            'environment': cls.ENVIRONMENT,
            'debug': cls.DEBUG,
            'log_level': cls.LOG_LEVEL,
            'default_model': cls.DEFAULT_MODEL,
            'rate_limit_per_minute': cls.RATE_LIMIT_PER_MINUTE,
            'cache_ttl': cls.CACHE_TTL,
            'enable_metrics': cls.ENABLE_METRICS
        }
        
        if include_secrets:
            config.update({
                'api_key': cls.API_KEY,
                'openai_api_key': cls.OPENAI_API_KEY[:8] + '...' if cls.OPENAI_API_KEY else None,
                'anthropic_api_key': cls.ANTHROPIC_API_KEY[:8] + '...' if cls.ANTHROPIC_API_KEY else None
            })
        
        return config


# Validate on import in production
if Config.ENVIRONMENT == 'production':
    errors = Config.validate()
    if errors:
        raise RuntimeError(f"Configuration errors: {errors}")
