"""
TechUnicorn LLM Platform - Main Application
Enterprise-grade LLM API Gateway with multi-model support
"""

import os
import time
import uuid
import hashlib
import logging
from datetime import datetime
from functools import wraps

from flask import Flask, request, jsonify, g
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import redis

from config import Config
from security.prompt_validator import PromptValidator
from security.input_sanitizer import InputSanitizer
from monitoring.metrics import MetricsCollector

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Initialize components
redis_client = redis.from_url(Config.REDIS_URL) if Config.REDIS_URL else None
prompt_validator = PromptValidator()
input_sanitizer = InputSanitizer()
metrics = MetricsCollector()

# Configure logging
logging.basicConfig(
    level=getattr(logging, Config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Rate limiter
limiter = Limiter(
    key_func=get_remote_address,
    app=app,
    default_limits=["1000 per hour", "100 per minute"],
    storage_uri=Config.REDIS_URL if Config.REDIS_URL else "memory://"
)


# =============================================================================
# Middleware & Decorators
# =============================================================================

@app.before_request
def before_request():
    """Pre-request processing: tracking, validation"""
    g.request_id = str(uuid.uuid4())
    g.start_time = time.time()
    
    # Log request for audit
    logger.info(f"Request started", extra={
        'request_id': g.request_id,
        'method': request.method,
        'path': request.path,
        'client_ip': request.remote_addr,
        'user_agent': request.user_agent.string
    })


@app.after_request
def after_request(response):
    """Post-request processing: metrics, audit logging"""
    duration = time.time() - g.start_time
    
    # Record metrics
    metrics.record_request(
        endpoint=request.path,
        method=request.method,
        status_code=response.status_code,
        duration=duration
    )
    
    # Add tracking headers
    response.headers['X-Request-ID'] = g.request_id
    response.headers['X-Response-Time'] = f"{duration:.3f}s"
    
    # Audit log
    logger.info(f"Request completed", extra={
        'request_id': g.request_id,
        'status_code': response.status_code,
        'duration_ms': duration * 1000
    })
    
    return response


def require_api_key(f):
    """Decorator to require valid API key"""
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        
        if not api_key:
            logger.warning(f"Missing API key", extra={'request_id': g.request_id})
            return jsonify({'error': 'API key required'}), 401
        
        # TODO: Validate API key against database/secrets manager
        # For now, check against environment variable
        if api_key != Config.API_KEY:
            logger.warning(f"Invalid API key", extra={'request_id': g.request_id})
            return jsonify({'error': 'Invalid API key'}), 403
        
        return f(*args, **kwargs)
    return decorated


# =============================================================================
# Health & Status Endpoints
# =============================================================================

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint for load balancers"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': Config.APP_VERSION
    })


@app.route('/ready', methods=['GET'])
def readiness_check():
    """Readiness check - verifies all dependencies"""
    checks = {
        'redis': False,
        'models': False
    }
    
    # Check Redis connection
    try:
        if redis_client:
            redis_client.ping()
            checks['redis'] = True
    except Exception as e:
        logger.error(f"Redis health check failed: {e}")
    
    # Check model availability
    # TODO: Add actual model health checks
    checks['models'] = True
    
    all_healthy = all(checks.values())
    status_code = 200 if all_healthy else 503
    
    return jsonify({
        'ready': all_healthy,
        'checks': checks,
        'timestamp': datetime.utcnow().isoformat()
    }), status_code


@app.route('/metrics', methods=['GET'])
def get_metrics():
    """Prometheus-compatible metrics endpoint"""
    return metrics.get_prometheus_metrics(), 200, {'Content-Type': 'text/plain'}


# =============================================================================
# LLM API Endpoints
# =============================================================================

@app.route('/v1/completions', methods=['POST'])
@limiter.limit("60 per minute")
@require_api_key
def completions():
    """
    Generate LLM completions
    
    Request body:
    {
        "model": "gpt-4" | "claude" | "llama",
        "prompt": "Your prompt here",
        "max_tokens": 1000,
        "temperature": 0.7
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Request body required'}), 400
        
        # Extract and validate parameters
        prompt = data.get('prompt', '')
        model = data.get('model', Config.DEFAULT_MODEL)
        max_tokens = data.get('max_tokens', 1000)
        temperature = data.get('temperature', 0.7)
        
        # Input sanitization
        sanitized_prompt = input_sanitizer.sanitize(prompt)
        
        # Prompt injection validation
        is_safe, risk_score, flags = prompt_validator.validate(sanitized_prompt)
        
        if not is_safe:
            logger.warning(f"Prompt injection detected", extra={
                'request_id': g.request_id,
                'risk_score': risk_score,
                'flags': flags
            })
            return jsonify({
                'error': 'Prompt validation failed',
                'risk_score': risk_score,
                'flags': flags
            }), 400
        
        # Check cache for identical requests
        cache_key = _generate_cache_key(sanitized_prompt, model, max_tokens, temperature)
        
        if redis_client:
            cached_response = redis_client.get(cache_key)
            if cached_response:
                metrics.record_cache_hit()
                logger.info(f"Cache hit", extra={'request_id': g.request_id})
                return jsonify({
                    'response': cached_response.decode('utf-8'),
                    'model': model,
                    'cached': True,
                    'request_id': g.request_id
                })
        
        metrics.record_cache_miss()
        
        # Route to appropriate model
        response_text = _route_to_model(
            model=model,
            prompt=sanitized_prompt,
            max_tokens=max_tokens,
            temperature=temperature
        )
        
        # Cache the response
        if redis_client and response_text:
            redis_client.setex(cache_key, Config.CACHE_TTL, response_text)
        
        # Record token usage for cost tracking
        input_tokens = len(sanitized_prompt.split())  # Approximate
        output_tokens = len(response_text.split()) if response_text else 0
        metrics.record_token_usage(model, input_tokens, output_tokens)
        
        return jsonify({
            'response': response_text,
            'model': model,
            'cached': False,
            'usage': {
                'input_tokens': input_tokens,
                'output_tokens': output_tokens
            },
            'request_id': g.request_id
        })
        
    except Exception as e:
        logger.error(f"Completion error: {e}", extra={'request_id': g.request_id})
        return jsonify({'error': 'Internal server error'}), 500


@app.route('/v1/chat', methods=['POST'])
@limiter.limit("60 per minute")
@require_api_key
def chat():
    """
    Chat completion endpoint with conversation history
    
    Request body:
    {
        "model": "gpt-4",
        "messages": [
            {"role": "system", "content": "You are a helpful assistant"},
            {"role": "user", "content": "Hello!"}
        ],
        "max_tokens": 1000
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'Request body required'}), 400
        
        messages = data.get('messages', [])
        model = data.get('model', Config.DEFAULT_MODEL)
        max_tokens = data.get('max_tokens', 1000)
        
        if not messages:
            return jsonify({'error': 'Messages array required'}), 400
        
        # Validate each message
        for msg in messages:
            content = msg.get('content', '')
            sanitized = input_sanitizer.sanitize(content)
            is_safe, risk_score, flags = prompt_validator.validate(sanitized)
            
            if not is_safe:
                return jsonify({
                    'error': 'Message validation failed',
                    'risk_score': risk_score
                }), 400
            
            msg['content'] = sanitized
        
        # Route to model
        response_text = _route_to_model(
            model=model,
            messages=messages,
            max_tokens=max_tokens
        )
        
        return jsonify({
            'response': {
                'role': 'assistant',
                'content': response_text
            },
            'model': model,
            'request_id': g.request_id
        })
        
    except Exception as e:
        logger.error(f"Chat error: {e}", extra={'request_id': g.request_id})
        return jsonify({'error': 'Internal server error'}), 500


@app.route('/v1/models', methods=['GET'])
@require_api_key
def list_models():
    """List available models"""
    return jsonify({
        'models': [
            {
                'id': 'gpt-4',
                'name': 'GPT-4',
                'provider': 'openai',
                'max_tokens': 8192,
                'cost_per_1k_tokens': 0.03
            },
            {
                'id': 'claude',
                'name': 'Claude 3',
                'provider': 'anthropic',
                'max_tokens': 100000,
                'cost_per_1k_tokens': 0.015
            },
            {
                'id': 'llama',
                'name': 'Llama 3',
                'provider': 'meta',
                'max_tokens': 8192,
                'cost_per_1k_tokens': 0.001
            }
        ]
    })


# =============================================================================
# Helper Functions
# =============================================================================

def _generate_cache_key(prompt: str, model: str, max_tokens: int, temperature: float) -> str:
    """Generate deterministic cache key for request"""
    key_string = f"{model}:{max_tokens}:{temperature}:{prompt}"
    return f"llm:cache:{hashlib.sha256(key_string.encode()).hexdigest()}"


def _route_to_model(model: str, prompt: str = None, messages: list = None, 
                    max_tokens: int = 1000, temperature: float = 0.7) -> str:
    """
    Route request to appropriate model provider
    
    TODO: Implement actual model integrations:
    - OpenAI API for GPT-4
    - Anthropic API for Claude
    - Local/vLLM for Llama
    """
    # Placeholder implementation - replace with actual model calls
    logger.info(f"Routing to model: {model}", extra={'request_id': g.request_id})
    
    # Simulate model response
    if model == 'gpt-4':
        # TODO: Call OpenAI API
        return f"[GPT-4 Response] This is a placeholder response for: {prompt or messages[-1]['content']}"
    
    elif model == 'claude':
        # TODO: Call Anthropic API
        return f"[Claude Response] This is a placeholder response for: {prompt or messages[-1]['content']}"
    
    elif model == 'llama':
        # TODO: Call local Llama instance
        return f"[Llama Response] This is a placeholder response for: {prompt or messages[-1]['content']}"
    
    else:
        raise ValueError(f"Unknown model: {model}")


# =============================================================================
# Error Handlers
# =============================================================================

@app.errorhandler(429)
def ratelimit_handler(e):
    """Handle rate limit exceeded"""
    logger.warning(f"Rate limit exceeded", extra={
        'request_id': getattr(g, 'request_id', 'unknown'),
        'client_ip': request.remote_addr
    })
    return jsonify({
        'error': 'Rate limit exceeded',
        'retry_after': e.description
    }), 429


@app.errorhandler(500)
def internal_error(e):
    """Handle internal server errors"""
    logger.error(f"Internal server error: {e}")
    return jsonify({'error': 'Internal server error'}), 500


# =============================================================================
# Main Entry Point
# =============================================================================

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8000))
    debug = Config.ENVIRONMENT == 'development'
    
    logger.info(f"Starting LLM Platform on port {port}")
    logger.info(f"Environment: {Config.ENVIRONMENT}")
    
    app.run(host='0.0.0.0', port=port, debug=debug)
