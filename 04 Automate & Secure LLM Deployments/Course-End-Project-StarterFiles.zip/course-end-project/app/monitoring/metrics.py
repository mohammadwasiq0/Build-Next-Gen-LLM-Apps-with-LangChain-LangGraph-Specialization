"""
TechUnicorn LLM Platform - Metrics Collector
Prometheus-compatible metrics for monitoring and alerting
"""

import time
import threading
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


@dataclass
class MetricValue:
    """Container for metric values"""
    value: float
    labels: Dict[str, str] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class MetricsCollector:
    """
    Collects and exports application metrics in Prometheus format.
    
    Metrics collected:
    - Request counts and latencies
    - Token usage and costs
    - Cache hit/miss rates
    - Error rates by type
    - Model-specific performance
    """
    
    def __init__(self, prefix: str = 'llm_platform'):
        """
        Initialize metrics collector.
        
        Args:
            prefix: Prefix for all metric names
        """
        self.prefix = prefix
        self._lock = threading.Lock()
        
        # Counters
        self._request_count = defaultdict(int)
        self._error_count = defaultdict(int)
        self._cache_hits = 0
        self._cache_misses = 0
        self._token_usage = defaultdict(lambda: {'input': 0, 'output': 0})
        
        # Histograms (store raw values for percentile calculation)
        self._request_latencies: List[MetricValue] = []
        self._model_latencies: Dict[str, List[float]] = defaultdict(list)
        
        # Gauges
        self._active_requests = 0
        self._last_request_time = 0
        
        # Cost tracking
        self._cost_by_model = defaultdict(float)
        
        # Model pricing (per 1K tokens)
        self.MODEL_PRICING = {
            'gpt-4': {'input': 0.03, 'output': 0.06},
            'gpt-3.5-turbo': {'input': 0.001, 'output': 0.002},
            'claude': {'input': 0.008, 'output': 0.024},
            'llama': {'input': 0.0001, 'output': 0.0001}
        }
    
    # =========================================================================
    # Recording Methods
    # =========================================================================
    
    def record_request(
        self,
        endpoint: str,
        method: str,
        status_code: int,
        duration: float,
        model: str = None
    ):
        """
        Record an HTTP request.
        
        Args:
            endpoint: API endpoint path
            method: HTTP method
            status_code: Response status code
            duration: Request duration in seconds
            model: LLM model used (if applicable)
        """
        with self._lock:
            # Increment request counter
            labels = f'{method}_{endpoint}_{status_code}'
            self._request_count[labels] += 1
            
            # Record latency
            self._request_latencies.append(MetricValue(
                value=duration,
                labels={'endpoint': endpoint, 'method': method, 'status': str(status_code)}
            ))
            
            # Keep latency list bounded
            if len(self._request_latencies) > 10000:
                self._request_latencies = self._request_latencies[-5000:]
            
            # Model-specific latency
            if model:
                self._model_latencies[model].append(duration)
                if len(self._model_latencies[model]) > 1000:
                    self._model_latencies[model] = self._model_latencies[model][-500:]
            
            # Track errors
            if status_code >= 400:
                error_type = 'client_error' if status_code < 500 else 'server_error'
                self._error_count[f'{error_type}_{endpoint}'] += 1
            
            self._last_request_time = time.time()
    
    def record_token_usage(self, model: str, input_tokens: int, output_tokens: int):
        """
        Record token usage for cost tracking.
        
        Args:
            model: Model identifier
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
        """
        with self._lock:
            self._token_usage[model]['input'] += input_tokens
            self._token_usage[model]['output'] += output_tokens
            
            # Calculate and record cost
            pricing = self.MODEL_PRICING.get(model, {'input': 0.01, 'output': 0.01})
            cost = (input_tokens / 1000 * pricing['input'] + 
                    output_tokens / 1000 * pricing['output'])
            self._cost_by_model[model] += cost
    
    def record_cache_hit(self):
        """Record a cache hit"""
        with self._lock:
            self._cache_hits += 1
    
    def record_cache_miss(self):
        """Record a cache miss"""
        with self._lock:
            self._cache_misses += 1
    
    def increment_active_requests(self):
        """Increment active request gauge"""
        with self._lock:
            self._active_requests += 1
    
    def decrement_active_requests(self):
        """Decrement active request gauge"""
        with self._lock:
            self._active_requests = max(0, self._active_requests - 1)
    
    # =========================================================================
    # Query Methods
    # =========================================================================
    
    def get_request_count(self, endpoint: str = None) -> int:
        """Get total request count, optionally filtered by endpoint"""
        with self._lock:
            if endpoint:
                return sum(v for k, v in self._request_count.items() if endpoint in k)
            return sum(self._request_count.values())
    
    def get_error_rate(self, window_seconds: int = 300) -> float:
        """Calculate error rate over time window"""
        with self._lock:
            total = sum(self._request_count.values())
            errors = sum(self._error_count.values())
            return errors / max(total, 1)
    
    def get_cache_hit_rate(self) -> float:
        """Calculate cache hit rate"""
        with self._lock:
            total = self._cache_hits + self._cache_misses
            return self._cache_hits / max(total, 1)
    
    def get_latency_percentiles(self, percentiles: List[int] = None) -> Dict[str, float]:
        """
        Calculate latency percentiles.
        
        Args:
            percentiles: List of percentiles to calculate (default: [50, 90, 95, 99])
        """
        percentiles = percentiles or [50, 90, 95, 99]
        
        with self._lock:
            if not self._request_latencies:
                return {f'p{p}': 0 for p in percentiles}
            
            values = sorted([m.value for m in self._request_latencies])
            result = {}
            
            for p in percentiles:
                index = int(len(values) * p / 100)
                result[f'p{p}'] = values[min(index, len(values) - 1)]
            
            return result
    
    def get_total_cost(self) -> float:
        """Get total cost across all models"""
        with self._lock:
            return sum(self._cost_by_model.values())
    
    def get_cost_by_model(self) -> Dict[str, float]:
        """Get cost breakdown by model"""
        with self._lock:
            return dict(self._cost_by_model)
    
    # =========================================================================
    # Export Methods
    # =========================================================================
    
    def get_prometheus_metrics(self) -> str:
        """
        Export all metrics in Prometheus text format.
        
        Returns:
            Prometheus-formatted metrics string
        """
        lines = []
        
        with self._lock:
            # Request count
            lines.append(f'# HELP {self.prefix}_requests_total Total number of requests')
            lines.append(f'# TYPE {self.prefix}_requests_total counter')
            for labels, count in self._request_count.items():
                parts = labels.split('_')
                if len(parts) >= 3:
                    method, endpoint, status = parts[0], '_'.join(parts[1:-1]), parts[-1]
                    lines.append(
                        f'{self.prefix}_requests_total{{method="{method}",endpoint="{endpoint}",status="{status}"}} {count}'
                    )
            
            # Error count
            lines.append(f'# HELP {self.prefix}_errors_total Total number of errors')
            lines.append(f'# TYPE {self.prefix}_errors_total counter')
            for labels, count in self._error_count.items():
                lines.append(f'{self.prefix}_errors_total{{type="{labels}"}} {count}')
            
            # Latency percentiles
            percentiles = self.get_latency_percentiles()
            lines.append(f'# HELP {self.prefix}_request_duration_seconds Request duration')
            lines.append(f'# TYPE {self.prefix}_request_duration_seconds summary')
            for percentile, value in percentiles.items():
                lines.append(f'{self.prefix}_request_duration_seconds{{quantile="{percentile}"}} {value:.6f}')
            
            # Cache metrics
            total_cache = self._cache_hits + self._cache_misses
            lines.append(f'# HELP {self.prefix}_cache_hits_total Cache hit count')
            lines.append(f'# TYPE {self.prefix}_cache_hits_total counter')
            lines.append(f'{self.prefix}_cache_hits_total {self._cache_hits}')
            lines.append(f'{self.prefix}_cache_misses_total {self._cache_misses}')
            lines.append(f'{self.prefix}_cache_hit_rate {self._cache_hits / max(total_cache, 1):.4f}')
            
            # Token usage
            lines.append(f'# HELP {self.prefix}_tokens_total Token usage by model')
            lines.append(f'# TYPE {self.prefix}_tokens_total counter')
            for model, usage in self._token_usage.items():
                lines.append(f'{self.prefix}_tokens_total{{model="{model}",type="input"}} {usage["input"]}')
                lines.append(f'{self.prefix}_tokens_total{{model="{model}",type="output"}} {usage["output"]}')
            
            # Cost tracking
            lines.append(f'# HELP {self.prefix}_cost_dollars Total cost in dollars')
            lines.append(f'# TYPE {self.prefix}_cost_dollars counter')
            for model, cost in self._cost_by_model.items():
                lines.append(f'{self.prefix}_cost_dollars{{model="{model}"}} {cost:.6f}')
            lines.append(f'{self.prefix}_cost_dollars_total {sum(self._cost_by_model.values()):.6f}')
            
            # Active requests gauge
            lines.append(f'# HELP {self.prefix}_active_requests Current active requests')
            lines.append(f'# TYPE {self.prefix}_active_requests gauge')
            lines.append(f'{self.prefix}_active_requests {self._active_requests}')
        
        return '\n'.join(lines)
    
    def get_summary(self) -> Dict:
        """Get summary of all metrics"""
        return {
            'total_requests': self.get_request_count(),
            'error_rate': self.get_error_rate(),
            'cache_hit_rate': self.get_cache_hit_rate(),
            'latency_percentiles': self.get_latency_percentiles(),
            'total_cost': self.get_total_cost(),
            'cost_by_model': self.get_cost_by_model(),
            'active_requests': self._active_requests
        }
    
    def reset(self):
        """Reset all metrics (useful for testing)"""
        with self._lock:
            self._request_count.clear()
            self._error_count.clear()
            self._cache_hits = 0
            self._cache_misses = 0
            self._token_usage.clear()
            self._request_latencies.clear()
            self._model_latencies.clear()
            self._cost_by_model.clear()
            self._active_requests = 0


# =============================================================================
# Singleton instance
# =============================================================================

_metrics_instance = None

def get_metrics() -> MetricsCollector:
    """Get singleton metrics collector"""
    global _metrics_instance
    if _metrics_instance is None:
        _metrics_instance = MetricsCollector()
    return _metrics_instance
