"""
TechUnicorn LLM Platform - Prompt Injection Validator
Detects and prevents prompt injection attacks against LLM endpoints
"""

import re
import logging
from typing import Tuple, List, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of prompt validation"""
    is_safe: bool
    risk_score: float
    flags: List[str]
    details: Dict[str, Any]


class PromptValidator:
    """
    Validates prompts for injection attacks and malicious content.
    
    Detection categories:
    1. Direct injection attempts (ignore previous, system override)
    2. Jailbreak patterns (DAN, roleplay bypasses)
    3. Data exfiltration attempts (reveal system prompt, dump data)
    4. Code injection (eval, exec, SQL)
    5. Sensitive data patterns (SSN, credit cards, API keys)
    """
    
    # Risk threshold - prompts above this are blocked
    DEFAULT_RISK_THRESHOLD = 0.7
    
    # ==========================================================================
    # Injection Pattern Definitions
    # ==========================================================================
    
    INJECTION_PATTERNS = {
        'system_override': {
            'patterns': [
                r'ignore\s+(all\s+)?(previous|prior|above)\s+(instructions?|prompts?|rules?)',
                r'disregard\s+(all\s+)?(previous|prior|above)',
                r'forget\s+(all\s+)?(previous|prior|above|everything)',
                r'override\s+(system|safety|security)',
                r'bypass\s+(safety|security|restrictions?|filters?)',
                r'disable\s+(safety|security|filters?)',
                r'turn\s+off\s+(safety|security|filters?)',
                r'you\s+are\s+now\s+(in\s+)?(developer|admin|unrestricted)\s+mode',
                r'entering?\s+(developer|admin|unrestricted|jailbreak)\s+mode',
            ],
            'weight': 0.9,
            'category': 'injection'
        },
        'jailbreak': {
            'patterns': [
                r'\bDAN\b',  # "Do Anything Now"
                r'do\s+anything\s+now',
                r'act\s+as\s+(if\s+)?(you\s+)?(have\s+)?no\s+(restrictions?|limits?|rules?)',
                r'pretend\s+(you\s+)?(are|have)\s+no\s+(restrictions?|filters?|rules?)',
                r'roleplay\s+as\s+(an?\s+)?(evil|unrestricted|unfiltered)',
                r'you\s+can\s+do\s+anything',
                r'unlimited\s+mode',
                r'god\s+mode',
                r'sudo\s+mode',
            ],
            'weight': 0.85,
            'category': 'jailbreak'
        },
        'data_exfiltration': {
            'patterns': [
                r'reveal\s+(your\s+)?(system\s+)?prompt',
                r'show\s+(me\s+)?(your\s+)?(system\s+)?prompt',
                r'what\s+(is|are)\s+(your\s+)?(system\s+)?(prompt|instructions?)',
                r'print\s+(your\s+)?(system\s+)?prompt',
                r'dump\s+(all\s+)?(data|information|context)',
                r'export\s+(all\s+)?(data|information|users?)',
                r'list\s+all\s+(users?|accounts?|credentials?)',
                r'show\s+(me\s+)?(all\s+)?(api\s+)?keys?',
            ],
            'weight': 0.8,
            'category': 'exfiltration'
        },
        'code_injection': {
            'patterns': [
                r'\beval\s*\(',
                r'\bexec\s*\(',
                r'__import__',
                r'subprocess\.',
                r'os\.system',
                r'os\.popen',
                r';\s*(DROP|DELETE|INSERT|UPDATE)\s+',  # SQL injection
                r'UNION\s+SELECT',
                r"'\s*OR\s+'1'\s*=\s*'1",
                r'<script[^>]*>',  # XSS
                r'javascript:',
            ],
            'weight': 0.95,
            'category': 'code_injection'
        },
        'social_engineering': {
            'patterns': [
                r'(my|the)\s+(ceo|boss|manager|supervisor)\s+(said|told|asked|wants)',
                r'this\s+is\s+(an?\s+)?(urgent|emergency)',
                r'(legal|compliance)\s+(requires?|demands?)',
                r'you\s+must\s+(help|assist|comply)\s+(or|otherwise)',
                r'(lawsuit|legal\s+action)\s+if\s+you\s+don\'?t',
            ],
            'weight': 0.5,
            'category': 'social_engineering'
        },
        'encoding_bypass': {
            'patterns': [
                r'base64[:\s]',
                r'hex[:\s]',
                r'rot13[:\s]',
                r'decode\s+(this|the\s+following)',
                r'convert\s+from\s+(base64|hex|binary)',
            ],
            'weight': 0.6,
            'category': 'encoding_bypass'
        }
    }
    
    # Sensitive data patterns
    SENSITIVE_PATTERNS = {
        'ssn': {
            'pattern': r'\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b',
            'name': 'Social Security Number',
            'weight': 0.3
        },
        'credit_card': {
            'pattern': r'\b(?:\d{4}[-\s]?){3}\d{4}\b',
            'name': 'Credit Card Number',
            'weight': 0.3
        },
        'api_key': {
            'pattern': r'\b(sk-|pk-|api[_-]?key)[a-zA-Z0-9]{20,}\b',
            'name': 'API Key',
            'weight': 0.4
        },
        'aws_key': {
            'pattern': r'\bAKIA[A-Z0-9]{16}\b',
            'name': 'AWS Access Key',
            'weight': 0.5
        },
        'password': {
            'pattern': r'password\s*[=:]\s*["\']?[^\s"\']+',
            'name': 'Password Pattern',
            'weight': 0.4
        }
    }
    
    def __init__(self, risk_threshold: float = None):
        """
        Initialize the validator.
        
        Args:
            risk_threshold: Score above which prompts are blocked (0-1)
        """
        self.risk_threshold = risk_threshold or self.DEFAULT_RISK_THRESHOLD
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Pre-compile regex patterns for performance"""
        self._compiled_injection = {}
        for name, config in self.INJECTION_PATTERNS.items():
            self._compiled_injection[name] = {
                'patterns': [re.compile(p, re.IGNORECASE) for p in config['patterns']],
                'weight': config['weight'],
                'category': config['category']
            }
        
        self._compiled_sensitive = {}
        for name, config in self.SENSITIVE_PATTERNS.items():
            self._compiled_sensitive[name] = {
                'pattern': re.compile(config['pattern'], re.IGNORECASE),
                'name': config['name'],
                'weight': config['weight']
            }
    
    def validate(self, prompt: str) -> Tuple[bool, float, List[str]]:
        """
        Validate a prompt for injection attacks.
        
        Args:
            prompt: The user's prompt text
            
        Returns:
            Tuple of (is_safe, risk_score, list_of_flags)
        """
        result = self.validate_detailed(prompt)
        return result.is_safe, result.risk_score, result.flags
    
    def validate_detailed(self, prompt: str) -> ValidationResult:
        """
        Detailed validation with full results.
        
        Args:
            prompt: The user's prompt text
            
        Returns:
            ValidationResult with detailed analysis
        """
        flags = []
        risk_scores = []
        details = {
            'injection_matches': [],
            'sensitive_matches': [],
            'length': len(prompt),
            'word_count': len(prompt.split())
        }
        
        # Check injection patterns
        for name, config in self._compiled_injection.items():
            for pattern in config['patterns']:
                matches = pattern.findall(prompt)
                if matches:
                    flags.append(f"{config['category']}:{name}")
                    risk_scores.append(config['weight'])
                    details['injection_matches'].append({
                        'pattern': name,
                        'category': config['category'],
                        'matches': matches[:3]  # Limit stored matches
                    })
                    break  # Only count each category once
        
        # Check sensitive data patterns
        for name, config in self._compiled_sensitive.items():
            if config['pattern'].search(prompt):
                flags.append(f"sensitive_data:{name}")
                risk_scores.append(config['weight'])
                details['sensitive_matches'].append(config['name'])
        
        # Calculate composite risk score
        if risk_scores:
            # Use max score + weighted average of others
            risk_score = max(risk_scores)
            if len(risk_scores) > 1:
                other_scores = [s for s in risk_scores if s != risk_score]
                risk_score = min(1.0, risk_score + 0.1 * sum(other_scores))
        else:
            risk_score = 0.0
        
        # Additional heuristics
        risk_score = self._apply_heuristics(prompt, risk_score, flags, details)
        
        is_safe = risk_score < self.risk_threshold
        
        # Log high-risk prompts
        if risk_score >= 0.5:
            logger.warning(f"High-risk prompt detected: score={risk_score:.2f}, flags={flags}")
        
        return ValidationResult(
            is_safe=is_safe,
            risk_score=round(risk_score, 3),
            flags=flags,
            details=details
        )
    
    def _apply_heuristics(self, prompt: str, base_score: float, 
                          flags: List[str], details: Dict) -> float:
        """Apply additional heuristic checks"""
        score = base_score
        
        # Very long prompts might be hiding injection
        if len(prompt) > 10000:
            score = min(1.0, score + 0.1)
            flags.append('heuristic:very_long_prompt')
        
        # High ratio of special characters
        special_chars = len(re.findall(r'[^\w\s]', prompt))
        if special_chars / max(len(prompt), 1) > 0.3:
            score = min(1.0, score + 0.1)
            flags.append('heuristic:high_special_char_ratio')
        
        # Multiple newlines (often used to hide injection)
        if prompt.count('\n') > 50:
            score = min(1.0, score + 0.1)
            flags.append('heuristic:excessive_newlines')
        
        # Unicode tricks
        if any(ord(c) > 127 for c in prompt):
            # Check for homoglyph attacks
            confusables = re.findall(r'[а-яА-Я]', prompt)  # Cyrillic in Latin context
            if confusables and re.search(r'[a-zA-Z]', prompt):
                score = min(1.0, score + 0.2)
                flags.append('heuristic:unicode_homoglyph')
        
        return score
    
    def get_explanation(self, flags: List[str]) -> str:
        """Get human-readable explanation of flags"""
        explanations = {
            'injection:system_override': 'Attempted to override system instructions',
            'injection:jailbreak': 'Attempted jailbreak/bypass technique detected',
            'exfiltration:data_exfiltration': 'Attempted to extract system information',
            'code_injection:code_injection': 'Potential code injection detected',
            'social_engineering:social_engineering': 'Social engineering pattern detected',
            'encoding_bypass:encoding_bypass': 'Potential encoding-based bypass attempt'
        }
        
        return '; '.join(
            explanations.get(f, f) for f in flags
            if not f.startswith('heuristic:')
        )


# =============================================================================
# Convenience functions
# =============================================================================

_default_validator = None

def get_validator() -> PromptValidator:
    """Get singleton validator instance"""
    global _default_validator
    if _default_validator is None:
        _default_validator = PromptValidator()
    return _default_validator


def validate_prompt(prompt: str) -> Tuple[bool, float, List[str]]:
    """Convenience function for prompt validation"""
    return get_validator().validate(prompt)
