"""
TechUnicorn LLM Platform - Input Sanitizer
Sanitizes and normalizes user input before LLM processing
"""

import re
import html
import unicodedata
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


class InputSanitizer:
    """
    Sanitizes user input to prevent injection and normalize content.
    
    Features:
    - HTML entity decoding and stripping
    - Unicode normalization
    - Control character removal
    - Whitespace normalization
    - URL sanitization
    - PII redaction (optional)
    """
    
    # Maximum allowed prompt length
    MAX_LENGTH = 32000
    
    # Characters to strip
    CONTROL_CHARS = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]')
    
    # Patterns for content normalization
    MULTIPLE_SPACES = re.compile(r' {2,}')
    MULTIPLE_NEWLINES = re.compile(r'\n{3,}')
    
    # PII patterns for optional redaction
    PII_PATTERNS = {
        'email': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
        'phone': re.compile(r'\b(?:\+1[-.\s]?)?\(?[0-9]{3}\)?[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}\b'),
        'ssn': re.compile(r'\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b'),
        'credit_card': re.compile(r'\b(?:\d{4}[-\s]?){3}\d{4}\b'),
        'ip_address': re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b'),
    }
    
    def __init__(
        self,
        max_length: int = None,
        strip_html: bool = True,
        normalize_unicode: bool = True,
        normalize_whitespace: bool = True,
        redact_pii: bool = False,
        custom_filters: List[callable] = None
    ):
        """
        Initialize sanitizer with options.
        
        Args:
            max_length: Maximum allowed input length
            strip_html: Remove HTML tags and decode entities
            normalize_unicode: Normalize unicode to NFC form
            normalize_whitespace: Collapse multiple spaces/newlines
            redact_pii: Replace PII with placeholders
            custom_filters: Additional filter functions
        """
        self.max_length = max_length or self.MAX_LENGTH
        self.strip_html = strip_html
        self.normalize_unicode = normalize_unicode
        self.normalize_whitespace = normalize_whitespace
        self.redact_pii = redact_pii
        self.custom_filters = custom_filters or []
    
    def sanitize(self, text: str) -> str:
        """
        Apply all sanitization steps to input text.
        
        Args:
            text: Raw user input
            
        Returns:
            Sanitized text
        """
        if not text:
            return ""
        
        # Truncate to max length
        if len(text) > self.max_length:
            logger.warning(f"Input truncated from {len(text)} to {self.max_length}")
            text = text[:self.max_length]
        
        # Remove control characters
        text = self.CONTROL_CHARS.sub('', text)
        
        # Normalize unicode
        if self.normalize_unicode:
            text = self._normalize_unicode(text)
        
        # Strip HTML
        if self.strip_html:
            text = self._strip_html(text)
        
        # Normalize whitespace
        if self.normalize_whitespace:
            text = self._normalize_whitespace(text)
        
        # Redact PII if enabled
        if self.redact_pii:
            text = self._redact_pii(text)
        
        # Apply custom filters
        for filter_func in self.custom_filters:
            try:
                text = filter_func(text)
            except Exception as e:
                logger.error(f"Custom filter error: {e}")
        
        return text.strip()
    
    def _normalize_unicode(self, text: str) -> str:
        """
        Normalize unicode to NFC form and handle confusables.
        
        NFC (Canonical Decomposition, followed by Canonical Composition)
        ensures consistent representation of characters.
        """
        # Normalize to NFC
        text = unicodedata.normalize('NFC', text)
        
        # Replace common confusables (homoglyphs)
        confusable_map = {
            'а': 'a', 'е': 'e', 'о': 'o', 'р': 'p', 'с': 'c', 'х': 'x',  # Cyrillic
            'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H',
            'О': 'O', 'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X',
            '⁰': '0', '¹': '1', '²': '2', '³': '3',  # Superscripts
            '\u200b': '',  # Zero-width space
            '\u200c': '',  # Zero-width non-joiner
            '\u200d': '',  # Zero-width joiner
            '\ufeff': '',  # BOM
        }
        
        for confusable, replacement in confusable_map.items():
            text = text.replace(confusable, replacement)
        
        return text
    
    def _strip_html(self, text: str) -> str:
        """Remove HTML tags and decode entities"""
        # Decode HTML entities
        text = html.unescape(text)
        
        # Remove script and style elements entirely
        text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
        text = re.sub(r'<style[^>]*>.*?</style>', '', text, flags=re.DOTALL | re.IGNORECASE)
        
        # Remove all HTML tags
        text = re.sub(r'<[^>]+>', '', text)
        
        return text
    
    def _normalize_whitespace(self, text: str) -> str:
        """Normalize spaces and newlines"""
        # Replace tabs with spaces
        text = text.replace('\t', ' ')
        
        # Collapse multiple spaces
        text = self.MULTIPLE_SPACES.sub(' ', text)
        
        # Collapse multiple newlines (keep max 2)
        text = self.MULTIPLE_NEWLINES.sub('\n\n', text)
        
        # Trim whitespace from each line
        lines = [line.strip() for line in text.split('\n')]
        text = '\n'.join(lines)
        
        return text
    
    def _redact_pii(self, text: str) -> str:
        """Replace PII with placeholders"""
        redactions = {}
        
        for pii_type, pattern in self.PII_PATTERNS.items():
            matches = pattern.findall(text)
            for match in matches:
                placeholder = f'[REDACTED_{pii_type.upper()}]'
                text = text.replace(match, placeholder)
                redactions[match] = placeholder
        
        if redactions:
            logger.info(f"Redacted {len(redactions)} PII instances")
        
        return text
    
    def validate_length(self, text: str) -> bool:
        """Check if text is within length limits"""
        return len(text) <= self.max_length
    
    def get_stats(self, text: str) -> Dict[str, Any]:
        """Get statistics about the input"""
        return {
            'length': len(text),
            'word_count': len(text.split()),
            'line_count': text.count('\n') + 1,
            'has_html': bool(re.search(r'<[^>]+>', text)),
            'has_urls': bool(re.search(r'https?://', text)),
            'has_code': bool(re.search(r'```|def |class |function |import ', text)),
            'encoding_issues': len([c for c in text if ord(c) > 127 and not unicodedata.category(c).startswith('L')])
        }


class ContentFilter:
    """Additional content filtering utilities"""
    
    @staticmethod
    def filter_urls(text: str, allow_list: List[str] = None) -> str:
        """
        Filter or annotate URLs in text.
        
        Args:
            text: Input text
            allow_list: List of allowed domains
        """
        url_pattern = re.compile(r'https?://[^\s<>"{}|\\^`\[\]]+')
        
        def check_url(match):
            url = match.group()
            if allow_list:
                domain = re.search(r'https?://([^/]+)', url)
                if domain and any(allowed in domain.group(1) for allowed in allow_list):
                    return url
                return '[URL_FILTERED]'
            return url
        
        return url_pattern.sub(check_url, text)
    
    @staticmethod
    def filter_code_blocks(text: str, allow_languages: List[str] = None) -> str:
        """
        Filter or validate code blocks.
        
        Args:
            text: Input text
            allow_languages: List of allowed programming languages
        """
        code_block_pattern = re.compile(r'```(\w*)\n(.*?)```', re.DOTALL)
        
        def check_code_block(match):
            language = match.group(1).lower()
            code = match.group(2)
            
            if allow_languages and language and language not in allow_languages:
                return f'```{language}\n[CODE_FILTERED: {language} not allowed]\n```'
            
            return match.group()
        
        return code_block_pattern.sub(check_code_block, text)


# =============================================================================
# Convenience functions
# =============================================================================

_default_sanitizer = None

def get_sanitizer() -> InputSanitizer:
    """Get singleton sanitizer instance"""
    global _default_sanitizer
    if _default_sanitizer is None:
        _default_sanitizer = InputSanitizer()
    return _default_sanitizer


def sanitize_input(text: str) -> str:
    """Convenience function for input sanitization"""
    return get_sanitizer().sanitize(text)
