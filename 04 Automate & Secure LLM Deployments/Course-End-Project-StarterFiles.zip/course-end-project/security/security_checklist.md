# LLM Platform Security Checklist

Use this checklist to verify security controls before production deployment.

---

## Pre-Deployment Checklist

### Authentication & Authorization
- [ ] API keys are stored in Secrets Manager (not in code/config)
- [ ] JWT tokens have appropriate expiration (≤ 1 hour)
- [ ] RBAC roles are properly configured
- [ ] Service accounts have minimal required permissions
- [ ] API key rotation process is documented

### Network Security
- [ ] TLS 1.3 enforced for all connections
- [ ] Network policies restrict pod-to-pod traffic
- [ ] Load balancer has WAF enabled
- [ ] VPC security groups follow least-privilege
- [ ] No public IPs on backend services

### Container Security
- [ ] Base images are from trusted sources
- [ ] Images are scanned for vulnerabilities (Trivy)
- [ ] No CRITICAL/HIGH vulnerabilities
- [ ] Containers run as non-root user
- [ ] Read-only root filesystem enabled
- [ ] Resource limits are set

### LLM-Specific Security
- [ ] Prompt injection validator is enabled
- [ ] Input sanitization is active
- [ ] PII detection/redaction is configured
- [ ] Rate limiting is enforced
- [ ] Output filtering prevents data leakage

### Data Protection
- [ ] Encryption at rest enabled (AES-256)
- [ ] Encryption in transit enabled (TLS)
- [ ] Sensitive data is not logged
- [ ] PII handling complies with GDPR
- [ ] Data retention policies are configured

### Monitoring & Logging
- [ ] All API requests are logged
- [ ] Audit logs capture user actions
- [ ] Log retention meets compliance requirements
- [ ] Alerts configured for security events
- [ ] Dashboards show security metrics

### Infrastructure
- [ ] Terraform state is encrypted
- [ ] State backend has versioning enabled
- [ ] Infrastructure changes require approval
- [ ] Backup procedures are tested
- [ ] DR plan is documented

### CI/CD Security
- [ ] Secrets are not in repository
- [ ] Pipeline uses secure runners
- [ ] Image scanning in pipeline
- [ ] Signed commits (optional)
- [ ] Branch protection enabled

---

## Compliance Verification

### SOC 2
- [ ] Access controls documented (CC6)
- [ ] Change management process (CC8)
- [ ] Incident response plan (CC7)
- [ ] System monitoring active (CC7)

### GDPR
- [ ] Privacy policy updated
- [ ] Data processing records maintained
- [ ] Subject access request process defined
- [ ] Breach notification procedure documented

### PCI-DSS (if applicable)
- [ ] Network segmentation verified
- [ ] Encryption requirements met
- [ ] Access controls implemented
- [ ] Logging requirements satisfied

---

## Post-Deployment Verification

- [ ] Health check endpoints responding
- [ ] Security headers present in responses
- [ ] Rate limiting working correctly
- [ ] Prompt injection tests pass
- [ ] Monitoring dashboards functional
- [ ] Alerts are firing correctly
- [ ] Incident runbook is accessible

---

## Sign-off

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Security Lead | | | |
| Platform Lead | | | |
| Compliance | | | |
