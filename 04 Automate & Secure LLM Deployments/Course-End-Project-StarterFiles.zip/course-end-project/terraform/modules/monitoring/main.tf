# =============================================================================
# Monitoring Module - CloudWatch, SNS Alarms
# =============================================================================

# Log Group for application logs
resource "aws_cloudwatch_log_group" "app" {
  name              = "/aws/eks/${var.cluster_name}/app"
  retention_in_days = var.log_retention_days
  tags              = var.tags
}

# Log Group for cluster logs
resource "aws_cloudwatch_log_group" "cluster" {
  name              = "/aws/eks/${var.cluster_name}/cluster"
  retention_in_days = var.log_retention_days
  tags              = var.tags
}

# SNS Topic for alarms
resource "aws_sns_topic" "alarms" {
  count = var.enable_alarms ? 1 : 0
  name  = "${var.name_prefix}-alarms"
  tags  = var.tags
}

resource "aws_sns_topic_subscription" "email" {
  count     = var.enable_alarms && var.alarm_email != "" ? 1 : 0
  topic_arn = aws_sns_topic.alarms[0].arn
  protocol  = "email"
  endpoint  = var.alarm_email
}

# CloudWatch Alarms
resource "aws_cloudwatch_metric_alarm" "high_cpu" {
  count               = var.enable_alarms ? 1 : 0
  alarm_name          = "${var.name_prefix}-high-cpu"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 300
  statistic           = "Average"
  threshold           = 80
  alarm_description   = "CPU utilization above 80%"
  alarm_actions       = [aws_sns_topic.alarms[0].arn]
  tags                = var.tags
}

resource "aws_cloudwatch_metric_alarm" "high_memory" {
  count               = var.enable_alarms ? 1 : 0
  alarm_name          = "${var.name_prefix}-high-memory"
  comparison_operator = "GreaterThanThreshold"
  evaluation_periods  = 2
  metric_name         = "MemoryUtilization"
  namespace           = "CWAgent"
  period              = 300
  statistic           = "Average"
  threshold           = 85
  alarm_description   = "Memory utilization above 85%"
  alarm_actions       = [aws_sns_topic.alarms[0].arn]
  tags                = var.tags
}

# Cost Budget (optional)
resource "aws_budgets_budget" "monthly" {
  count        = var.enable_cost_allocation ? 1 : 0
  name         = "${var.name_prefix}-monthly-budget"
  budget_type  = "COST"
  limit_amount = "500000"
  limit_unit   = "USD"
  time_unit    = "MONTHLY"

  notification {
    comparison_operator        = "GREATER_THAN"
    threshold                  = 80
    threshold_type             = "PERCENTAGE"
    notification_type          = "FORECASTED"
    subscriber_email_addresses = var.alarm_email != "" ? [var.alarm_email] : []
  }
}

# Variables
variable "name_prefix" { type = string }
variable "cluster_name" { type = string }
variable "log_retention_days" { type = number; default = 30 }
variable "enable_alarms" { type = bool; default = true }
variable "alarm_email" { type = string; default = "" }
variable "enable_cost_allocation" { type = bool; default = false }
variable "tags" { type = map(string); default = {} }

# Outputs
output "log_group_name" { value = aws_cloudwatch_log_group.app.name }
output "alarm_topic_arn" { value = var.enable_alarms ? aws_sns_topic.alarms[0].arn : "" }
