# =============================================================================
# ECR Module - Container Registry
# =============================================================================

resource "aws_ecr_repository" "main" {
  for_each = toset(var.repositories)

  name                 = "${var.name_prefix}-${each.value}"
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = var.scan_on_push
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = var.tags
}

resource "aws_ecr_lifecycle_policy" "main" {
  for_each   = toset(var.repositories)
  repository = aws_ecr_repository.main[each.key].name

  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep last ${var.max_image_count} images"
      selection = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = var.max_image_count
      }
      action = { type = "expire" }
    }]
  })
}

resource "aws_ecr_repository_policy" "main" {
  for_each   = length(var.allowed_principals) > 0 ? toset(var.repositories) : toset([])
  repository = aws_ecr_repository.main[each.key].name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "AllowPull"
      Effect    = "Allow"
      Principal = { AWS = var.allowed_principals }
      Action = [
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage",
        "ecr:BatchCheckLayerAvailability"
      ]
    }]
  })
}

# Variables
variable "name_prefix" { type = string }
variable "repositories" { type = list(string) }
variable "scan_on_push" { type = bool; default = true }
variable "max_image_count" { type = number; default = 30 }
variable "allowed_principals" { type = list(string); default = [] }
variable "tags" { type = map(string); default = {} }

# Outputs
output "repository_urls" {
  value = { for k, v in aws_ecr_repository.main : k => v.repository_url }
}
output "registry_id" {
  value = length(aws_ecr_repository.main) > 0 ? values(aws_ecr_repository.main)[0].registry_id : ""
}
