# =============================================================================
# TechUnicorn LLM Platform - Terraform Outputs
# Export values for use by other configurations and CI/CD
# =============================================================================

# =============================================================================
# VPC Outputs
# =============================================================================

output "vpc_id" {
  description = "ID of the VPC"
  value       = module.networking.vpc_id
}

output "private_subnet_ids" {
  description = "IDs of private subnets"
  value       = module.networking.private_subnet_ids
}

output "public_subnet_ids" {
  description = "IDs of public subnets"
  value       = module.networking.public_subnet_ids
}

# =============================================================================
# EKS Outputs
# =============================================================================

output "cluster_name" {
  description = "Name of the EKS cluster"
  value       = module.eks.cluster_name
}

output "cluster_endpoint" {
  description = "Endpoint for the EKS cluster API server"
  value       = module.eks.cluster_endpoint
  sensitive   = true
}

output "cluster_certificate_authority_data" {
  description = "Base64 encoded certificate data for cluster authentication"
  value       = module.eks.cluster_certificate_authority_data
  sensitive   = true
}

output "cluster_security_group_id" {
  description = "Security group ID attached to the EKS cluster"
  value       = module.eks.cluster_security_group_id
}

output "node_role_arn" {
  description = "ARN of the EKS node IAM role"
  value       = module.eks.node_role_arn
}

# =============================================================================
# ECR Outputs
# =============================================================================

output "ecr_repository_urls" {
  description = "URLs of the ECR repositories"
  value       = module.ecr.repository_urls
}

output "ecr_registry_id" {
  description = "Registry ID for ECR"
  value       = module.ecr.registry_id
}

# =============================================================================
# Redis Outputs
# =============================================================================

output "redis_endpoint" {
  description = "Primary endpoint for Redis cluster"
  value       = aws_elasticache_replication_group.redis.primary_endpoint_address
}

output "redis_port" {
  description = "Port for Redis cluster"
  value       = aws_elasticache_replication_group.redis.port
}

output "redis_connection_string" {
  description = "Full Redis connection string"
  value       = "redis://${aws_elasticache_replication_group.redis.primary_endpoint_address}:${aws_elasticache_replication_group.redis.port}"
  sensitive   = true
}

# =============================================================================
# Secrets Manager Outputs
# =============================================================================

output "secrets_manager_arn" {
  description = "ARN of the Secrets Manager secret for API keys"
  value       = aws_secretsmanager_secret.llm_api_keys.arn
}

output "secrets_manager_name" {
  description = "Name of the Secrets Manager secret"
  value       = aws_secretsmanager_secret.llm_api_keys.name
}

# =============================================================================
# Monitoring Outputs
# =============================================================================

output "cloudwatch_log_group" {
  description = "CloudWatch log group name"
  value       = module.monitoring.log_group_name
}

output "sns_alarm_topic_arn" {
  description = "ARN of SNS topic for alarms"
  value       = module.monitoring.alarm_topic_arn
}

# =============================================================================
# kubectl Configuration
# =============================================================================

output "kubectl_config_command" {
  description = "Command to configure kubectl"
  value       = "aws eks update-kubeconfig --name ${module.eks.cluster_name} --region ${data.aws_region.current.name}"
}

# =============================================================================
# Summary
# =============================================================================

output "deployment_summary" {
  description = "Summary of deployed resources"
  value = {
    environment    = var.environment
    region         = data.aws_region.current.name
    cluster_name   = module.eks.cluster_name
    vpc_id         = module.networking.vpc_id
    ecr_repos      = keys(module.ecr.repository_urls)
    redis_endpoint = aws_elasticache_replication_group.redis.primary_endpoint_address
  }
}
