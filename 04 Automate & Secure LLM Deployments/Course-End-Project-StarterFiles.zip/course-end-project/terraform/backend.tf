# =============================================================================
# TechUnicorn LLM Platform - Terraform Backend Configuration
# Remote state storage in S3 with DynamoDB locking
# =============================================================================

# NOTE: Uncomment and configure for production use
# The bucket and DynamoDB table must be created before running terraform init

# terraform {
#   backend "s3" {
#     bucket         = "techunicorn-terraform-state"
#     key            = "llm-platform/terraform.tfstate"
#     region         = "us-east-1"
#     encrypt        = true
#     dynamodb_table = "terraform-state-lock"
#     
#     # Optional: Use assume role for cross-account access
#     # role_arn = "arn:aws:iam::ACCOUNT_ID:role/TerraformRole"
#   }
# }

# =============================================================================
# Bootstrap Resources (run once to create backend)
# =============================================================================
# 
# resource "aws_s3_bucket" "terraform_state" {
#   bucket = "techunicorn-terraform-state"
#   
#   lifecycle {
#     prevent_destroy = true
#   }
# }
# 
# resource "aws_s3_bucket_versioning" "terraform_state" {
#   bucket = aws_s3_bucket.terraform_state.id
#   versioning_configuration {
#     status = "Enabled"
#   }
# }
# 
# resource "aws_s3_bucket_server_side_encryption_configuration" "terraform_state" {
#   bucket = aws_s3_bucket.terraform_state.id
#   
#   rule {
#     apply_server_side_encryption_by_default {
#       sse_algorithm = "aws:kms"
#     }
#   }
# }
# 
# resource "aws_dynamodb_table" "terraform_locks" {
#   name         = "terraform-state-lock"
#   billing_mode = "PAY_PER_REQUEST"
#   hash_key     = "LockID"
#   
#   attribute {
#     name = "LockID"
#     type = "S"
#   }
# }
