# =============================================================================
# TechUnicorn LLM Platform - Production Environment
# terraform apply -var-file=environments/prod.tfvars
# =============================================================================

environment  = "production"
aws_region   = "us-east-1"
project_name = "techunicorn-llm"
owner        = "platform-team"
cost_center  = "llm-platform-prod"

# Networking - Full production VPC
vpc_cidr             = "10.100.0.0/16"
public_subnet_cidrs  = ["10.100.1.0/24", "10.100.2.0/24", "10.100.3.0/24"]
private_subnet_cidrs = ["10.100.11.0/24", "10.100.12.0/24", "10.100.13.0/24"]
enable_nat_gateway   = true

# EKS - Production cluster with HA
kubernetes_version = "1.28"

node_groups = {
  general = {
    instance_types = ["m5.xlarge", "m5.2xlarge"]
    capacity_type  = "ON_DEMAND"
    disk_size      = 100
    min_size       = 3
    max_size       = 20
    desired_size   = 5
    labels         = { "workload" = "general", "environment" = "production" }
    taints         = []
  }
  llm-ondemand = {
    instance_types = ["g4dn.2xlarge", "g4dn.4xlarge"]
    capacity_type  = "ON_DEMAND"
    disk_size      = 200
    min_size       = 2
    max_size       = 10
    desired_size   = 3
    labels         = { "workload" = "llm", "gpu" = "true", "tier" = "premium" }
    taints = [{
      key    = "nvidia.com/gpu"
      value  = "true"
      effect = "NO_SCHEDULE"
    }]
  }
  llm-spot = {
    instance_types = ["g4dn.xlarge", "g4dn.2xlarge"]
    capacity_type  = "SPOT"
    disk_size      = 150
    min_size       = 0
    max_size       = 15
    desired_size   = 5
    labels         = { "workload" = "llm", "gpu" = "true", "tier" = "standard" }
    taints = [{
      key    = "nvidia.com/gpu"
      value  = "true"
      effect = "NO_SCHEDULE"
    }]
  }
}

# Redis - Production cluster with replication
redis_node_type = "cache.r6g.large"

# Monitoring - Extended retention
log_retention_days = 90
alarm_email        = "platform-alerts@techunicorn.ai"

# Security - Restricted access
allowed_cidr_blocks = []  # Configure with actual VPN/office IPs

# Cost Optimization
enable_spot_instances = true
monthly_budget_limit  = 300000  # $300K target (under $500K budget)
