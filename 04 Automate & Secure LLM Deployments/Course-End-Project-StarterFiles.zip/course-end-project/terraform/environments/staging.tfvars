# =============================================================================
# TechUnicorn LLM Platform - Staging Environment
# terraform apply -var-file=environments/staging.tfvars
# =============================================================================

environment  = "staging"
aws_region   = "us-east-1"
project_name = "techunicorn-llm"
owner        = "platform-team"
cost_center  = "llm-platform-staging"

# Networking
vpc_cidr             = "10.1.0.0/16"
public_subnet_cidrs  = ["10.1.1.0/24", "10.1.2.0/24", "10.1.3.0/24"]
private_subnet_cidrs = ["10.1.11.0/24", "10.1.12.0/24", "10.1.13.0/24"]
enable_nat_gateway   = true

# EKS - Production-like cluster
kubernetes_version = "1.28"

node_groups = {
  general = {
    instance_types = ["t3.large"]
    capacity_type  = "ON_DEMAND"
    disk_size      = 50
    min_size       = 2
    max_size       = 6
    desired_size   = 3
    labels         = { "workload" = "general", "environment" = "staging" }
    taints         = []
  }
  llm = {
    instance_types = ["g4dn.xlarge"]
    capacity_type  = "SPOT"
    disk_size      = 100
    min_size       = 0
    max_size       = 2
    desired_size   = 1
    labels         = { "workload" = "llm", "gpu" = "true", "environment" = "staging" }
    taints = [{
      key    = "nvidia.com/gpu"
      value  = "true"
      effect = "NO_SCHEDULE"
    }]
  }
}

# Redis - Medium instance
redis_node_type = "cache.t3.medium"

# Monitoring
log_retention_days = 14
alarm_email        = ""  # Set staging alerts email

# Security
allowed_cidr_blocks = ["0.0.0.0/0"]  # Restrict to VPN in real staging

# Cost Optimization
enable_spot_instances = true
monthly_budget_limit  = 50000  # $50K for staging
