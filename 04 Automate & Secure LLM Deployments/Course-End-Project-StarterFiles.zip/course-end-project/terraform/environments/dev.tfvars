# =============================================================================
# TechUnicorn LLM Platform - Development Environment
# terraform apply -var-file=environments/dev.tfvars
# =============================================================================

environment  = "dev"
aws_region   = "us-east-1"
project_name = "techunicorn-llm"
owner        = "dev-team"
cost_center  = "llm-platform-dev"

# Networking - Smaller CIDR for dev
vpc_cidr             = "10.0.0.0/16"
public_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24"]
private_subnet_cidrs = ["10.0.11.0/24", "10.0.12.0/24"]
enable_nat_gateway   = true

# EKS - Minimal cluster for dev
kubernetes_version = "1.28"

node_groups = {
  general = {
    instance_types = ["t3.medium"]
    capacity_type  = "SPOT"  # Use spot for cost savings in dev
    disk_size      = 30
    min_size       = 1
    max_size       = 3
    desired_size   = 2
    labels         = { "workload" = "general", "environment" = "dev" }
    taints         = []
  }
}

# Redis - Smaller instance for dev
redis_node_type = "cache.t3.micro"

# Monitoring
log_retention_days = 7
alarm_email        = ""  # Set your email for dev alerts

# Security
allowed_cidr_blocks = ["0.0.0.0/0"]  # Restrict in real dev environment

# Cost Optimization
enable_spot_instances = true
monthly_budget_limit  = 1000  # $1000 for dev
