# =============================================================================
# TechUnicorn LLM Platform - Main Terraform Configuration
# Root module orchestrating all infrastructure components
# =============================================================================

terraform {
  required_version = ">= 1.0.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.23"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.11"
    }
  }
}

# =============================================================================
# Local Values
# =============================================================================

locals {
  name_prefix = "${var.project_name}-${var.environment}"
  
  common_tags = {
    Project     = var.project_name
    Environment = var.environment
    ManagedBy   = "terraform"
    Owner       = var.owner
    CostCenter  = var.cost_center
  }
  
  # EKS cluster name
  cluster_name = "${local.name_prefix}-eks"
}

# =============================================================================
# Data Sources
# =============================================================================

data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_caller_identity" "current" {}

data "aws_region" "current" {}

# =============================================================================
# Networking Module
# =============================================================================

module "networking" {
  source = "./modules/networking"

  name_prefix         = local.name_prefix
  vpc_cidr            = var.vpc_cidr
  availability_zones  = slice(data.aws_availability_zones.available.names, 0, 3)
  
  public_subnet_cidrs  = var.public_subnet_cidrs
  private_subnet_cidrs = var.private_subnet_cidrs
  
  enable_nat_gateway   = var.enable_nat_gateway
  single_nat_gateway   = var.environment != "production"
  
  cluster_name = local.cluster_name
  
  tags = local.common_tags
}

# =============================================================================
# EKS Cluster Module
# =============================================================================

module "eks" {
  source = "./modules/eks"

  cluster_name    = local.cluster_name
  cluster_version = var.kubernetes_version
  
  vpc_id          = module.networking.vpc_id
  subnet_ids      = module.networking.private_subnet_ids
  
  # Node groups configuration
  node_groups = var.node_groups
  
  # Enable IRSA (IAM Roles for Service Accounts)
  enable_irsa = true
  
  # Cluster addons
  cluster_addons = {
    coredns = {
      most_recent = true
    }
    kube-proxy = {
      most_recent = true
    }
    vpc-cni = {
      most_recent = true
    }
  }
  
  tags = local.common_tags
}

# =============================================================================
# ECR Repository Module
# =============================================================================

module "ecr" {
  source = "./modules/ecr"

  name_prefix = local.name_prefix
  
  repositories = [
    "llm-platform-api",
    "llm-platform-worker"
  ]
  
  # Image scanning
  scan_on_push = true
  
  # Lifecycle policy - keep last 30 images
  max_image_count = 30
  
  # Allow EKS nodes to pull images
  allowed_principals = [module.eks.node_role_arn]
  
  tags = local.common_tags
}

# =============================================================================
# Monitoring Module (CloudWatch)
# =============================================================================

module "monitoring" {
  source = "./modules/monitoring"

  name_prefix  = local.name_prefix
  cluster_name = local.cluster_name
  
  # Log retention
  log_retention_days = var.log_retention_days
  
  # Alarms
  enable_alarms = true
  alarm_email   = var.alarm_email
  
  # Cost allocation
  enable_cost_allocation = true
  
  tags = local.common_tags
}

# =============================================================================
# Secrets Manager
# =============================================================================

resource "aws_secretsmanager_secret" "llm_api_keys" {
  name        = "${local.name_prefix}/llm-api-keys"
  description = "API keys for LLM providers"
  
  recovery_window_in_days = var.environment == "production" ? 30 : 0
  
  tags = local.common_tags
}

resource "aws_secretsmanager_secret_version" "llm_api_keys" {
  secret_id = aws_secretsmanager_secret.llm_api_keys.id
  
  # Placeholder - update with actual values
  secret_string = jsonencode({
    OPENAI_API_KEY    = "placeholder-update-manually"
    ANTHROPIC_API_KEY = "placeholder-update-manually"
    API_KEY           = "placeholder-update-manually"
  })
  
  lifecycle {
    ignore_changes = [secret_string]
  }
}

# =============================================================================
# ElastiCache (Redis) for Caching
# =============================================================================

resource "aws_elasticache_subnet_group" "redis" {
  name       = "${local.name_prefix}-redis"
  subnet_ids = module.networking.private_subnet_ids
  
  tags = local.common_tags
}

resource "aws_security_group" "redis" {
  name        = "${local.name_prefix}-redis-sg"
  description = "Security group for Redis cluster"
  vpc_id      = module.networking.vpc_id

  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [module.eks.cluster_security_group_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-redis-sg"
  })
}

resource "aws_elasticache_replication_group" "redis" {
  replication_group_id       = "${local.name_prefix}-redis"
  description                = "Redis cluster for LLM Platform caching"
  
  engine                     = "redis"
  engine_version             = "7.0"
  node_type                  = var.redis_node_type
  num_cache_clusters         = var.environment == "production" ? 2 : 1
  port                       = 6379
  
  subnet_group_name          = aws_elasticache_subnet_group.redis.name
  security_group_ids         = [aws_security_group.redis.id]
  
  automatic_failover_enabled = var.environment == "production"
  multi_az_enabled           = var.environment == "production"
  
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  
  snapshot_retention_limit   = var.environment == "production" ? 7 : 0
  
  tags = local.common_tags
}
