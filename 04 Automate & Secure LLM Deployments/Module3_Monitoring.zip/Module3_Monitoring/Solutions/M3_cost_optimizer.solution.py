"""
=============================================================================
GlobalAI LLM Platform - SOLUTION: Complete Cost Optimization System
=============================================================================
This is the SOLUTION file demonstrating:
1. Semantic caching with similarity search
2. Intelligent model routing based on query complexity
3. Request batching for efficiency
4. Real-time cost tracking and budgeting
5. Prometheus metrics integration
=============================================================================
"""

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
import re
from collections import defaultdict
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# =============================================================================
# Model Configuration
# =============================================================================

class ModelTier(Enum):
    """Model tiers with associated costs and capabilities."""
    FAST = "fast"          # Small models for simple queries
    STANDARD = "standard"  # Medium models for typical queries
    PREMIUM = "premium"    # Large models for complex queries


@dataclass
class ModelConfig:
    """Configuration for each model tier."""
    name: str
    tier: ModelTier
    cost_per_1k_input_tokens: float
    cost_per_1k_output_tokens: float
    max_context_length: int
    avg_latency_ms: float
    capabilities: List[str]


# SOLUTION: Model configurations with real pricing
MODEL_CONFIGS = {
    "llama-3.1-8b": ModelConfig(
        name="llama-3.1-8b",
        tier=ModelTier.FAST,
        cost_per_1k_input_tokens=0.0001,
        cost_per_1k_output_tokens=0.0002,
        max_context_length=8192,
        avg_latency_ms=150,
        capabilities=["simple_qa", "classification", "extraction"]
    ),
    "llama-3.1-70b": ModelConfig(
        name="llama-3.1-70b",
        tier=ModelTier.STANDARD,
        cost_per_1k_input_tokens=0.001,
        cost_per_1k_output_tokens=0.002,
        max_context_length=8192,
        avg_latency_ms=500,
        capabilities=["complex_qa", "reasoning", "analysis", "coding"]
    ),
    "gpt-4-turbo": ModelConfig(
        name="gpt-4-turbo",
        tier=ModelTier.PREMIUM,
        cost_per_1k_input_tokens=0.01,
        cost_per_1k_output_tokens=0.03,
        max_context_length=128000,
        avg_latency_ms=1000,
        capabilities=["expert_reasoning", "creative", "long_context", "multimodal"]
    ),
    "claude-3-sonnet": ModelConfig(
        name="claude-3-sonnet",
        tier=ModelTier.STANDARD,
        cost_per_1k_input_tokens=0.003,
        cost_per_1k_output_tokens=0.015,
        max_context_length=200000,
        avg_latency_ms=600,
        capabilities=["complex_qa", "reasoning", "analysis", "long_context"]
    ),
}


# =============================================================================
# SOLUTION: Semantic Cache with Similarity Search
# =============================================================================

@dataclass
class CacheEntry:
    """Cache entry with metadata."""
    prompt_hash: str
    prompt_embedding: Optional[List[float]]
    response: str
    model_used: str
    created_at: datetime
    access_count: int = 0
    last_accessed: datetime = None
    ttl_seconds: int = 3600
    token_count: int = 0
    cost_saved: float = 0.0


class SemanticCache:
    """
    SOLUTION: Advanced semantic caching with multiple strategies.
    
    Features:
    - Exact match caching (hash-based)
    - Semantic similarity caching (embedding-based)
    - TTL-based expiration
    - LRU eviction
    - Cost tracking
    """
    
    def __init__(
        self,
        max_entries: int = 10000,
        similarity_threshold: float = 0.95,
        default_ttl_seconds: int = 3600,
        enable_semantic: bool = True
    ):
        """
        Initialize the semantic cache.
        
        Args:
            max_entries: Maximum cache entries before eviction
            similarity_threshold: Minimum similarity for semantic match
            default_ttl_seconds: Default TTL for cache entries
            enable_semantic: Enable semantic similarity matching
        """
        self.max_entries = max_entries
        self.similarity_threshold = similarity_threshold
        self.default_ttl = default_ttl_seconds
        self.enable_semantic = enable_semantic
        
        # Storage
        self._exact_cache: Dict[str, CacheEntry] = {}
        self._embeddings: List[Tuple[str, List[float]]] = []
        
        # Metrics
        self._hits = 0
        self._misses = 0
        self._semantic_hits = 0
        self._cost_saved = 0.0
    
    def _hash_prompt(self, prompt: str) -> str:
        """Generate hash for exact matching."""
        normalized = prompt.lower().strip()
        return hashlib.sha256(normalized.encode()).hexdigest()
    
    def _compute_embedding(self, text: str) -> List[float]:
        """
        Compute embedding for semantic similarity.
        
        In production, use a proper embedding model like:
        - sentence-transformers
        - OpenAI embeddings
        - Cohere embeddings
        
        This is a simplified version using TF-IDF-like features.
        """
        # Simple feature extraction for demo
        # Replace with actual embedding model in production
        words = text.lower().split()
        word_freq = defaultdict(int)
        for word in words:
            word_freq[word] += 1
        
        # Create fixed-size feature vector
        features = []
        feature_words = ["what", "how", "why", "when", "where", "who",
                        "account", "balance", "transaction", "payment",
                        "help", "explain", "analyze", "compare", "summarize"]
        
        for fw in feature_words:
            features.append(word_freq.get(fw, 0) / max(len(words), 1))
        
        # Add length features
        features.append(len(words) / 100)
        features.append(len(text) / 1000)
        
        # Normalize
        norm = np.linalg.norm(features)
        if norm > 0:
            features = [f / norm for f in features]
        
        return features
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        dot_product = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot_product / (norm_a * norm_b)
    
    def get(self, prompt: str) -> Optional[Tuple[str, str, bool]]:
        """
        Get cached response for a prompt.
        
        Returns:
            Tuple of (response, model_used, is_semantic_match) or None
        """
        prompt_hash = self._hash_prompt(prompt)
        
        # Try exact match first
        if prompt_hash in self._exact_cache:
            entry = self._exact_cache[prompt_hash]
            
            # Check TTL
            if datetime.utcnow() - entry.created_at < timedelta(seconds=entry.ttl_seconds):
                entry.access_count += 1
                entry.last_accessed = datetime.utcnow()
                self._hits += 1
                self._cost_saved += entry.cost_saved
                
                logger.info(f"Cache HIT (exact): {prompt_hash[:16]}...")
                return entry.response, entry.model_used, False
            else:
                # Expired, remove
                del self._exact_cache[prompt_hash]
        
        # Try semantic match
        if self.enable_semantic and self._embeddings:
            query_embedding = self._compute_embedding(prompt)
            
            best_match = None
            best_similarity = 0.0
            
            for hash_key, embedding in self._embeddings:
                similarity = self._cosine_similarity(query_embedding, embedding)
                if similarity > best_similarity:
                    best_similarity = similarity
                    best_match = hash_key
            
            if best_similarity >= self.similarity_threshold and best_match in self._exact_cache:
                entry = self._exact_cache[best_match]
                
                # Check TTL
                if datetime.utcnow() - entry.created_at < timedelta(seconds=entry.ttl_seconds):
                    entry.access_count += 1
                    entry.last_accessed = datetime.utcnow()
                    self._hits += 1
                    self._semantic_hits += 1
                    self._cost_saved += entry.cost_saved
                    
                    logger.info(f"Cache HIT (semantic, sim={best_similarity:.3f}): {best_match[:16]}...")
                    return entry.response, entry.model_used, True
        
        self._misses += 1
        return None
    
    def set(
        self,
        prompt: str,
        response: str,
        model_used: str,
        token_count: int = 0,
        cost: float = 0.0,
        ttl_seconds: int = None
    ):
        """Store a response in the cache."""
        prompt_hash = self._hash_prompt(prompt)
        embedding = self._compute_embedding(prompt) if self.enable_semantic else None
        
        entry = CacheEntry(
            prompt_hash=prompt_hash,
            prompt_embedding=embedding,
            response=response,
            model_used=model_used,
            created_at=datetime.utcnow(),
            last_accessed=datetime.utcnow(),
            ttl_seconds=ttl_seconds or self.default_ttl,
            token_count=token_count,
            cost_saved=cost
        )
        
        # Evict if necessary
        if len(self._exact_cache) >= self.max_entries:
            self._evict_lru()
        
        self._exact_cache[prompt_hash] = entry
        
        if embedding:
            self._embeddings.append((prompt_hash, embedding))
        
        logger.info(f"Cache SET: {prompt_hash[:16]}... (model={model_used})")
    
    def _evict_lru(self):
        """Evict least recently used entries."""
        if not self._exact_cache:
            return
        
        # Find LRU entry
        lru_hash = min(
            self._exact_cache.keys(),
            key=lambda k: self._exact_cache[k].last_accessed or self._exact_cache[k].created_at
        )
        
        del self._exact_cache[lru_hash]
        self._embeddings = [(h, e) for h, e in self._embeddings if h != lru_hash]
        
        logger.debug(f"Evicted LRU entry: {lru_hash[:16]}...")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total = self._hits + self._misses
        hit_rate = self._hits / total if total > 0 else 0.0
        
        return {
            "total_entries": len(self._exact_cache),
            "max_entries": self.max_entries,
            "hits": self._hits,
            "misses": self._misses,
            "semantic_hits": self._semantic_hits,
            "hit_rate": hit_rate,
            "total_cost_saved": self._cost_saved
        }
    
    def clear(self):
        """Clear all cache entries."""
        self._exact_cache.clear()
        self._embeddings.clear()
        logger.info("Cache cleared")


# =============================================================================
# SOLUTION: Intelligent Model Router
# =============================================================================

@dataclass
class RoutingDecision:
    """Result of routing decision."""
    model: str
    tier: ModelTier
    confidence: float
    reasoning: str
    estimated_cost: float
    estimated_latency_ms: float


class ModelRouter:
    """
    SOLUTION: Intelligent model routing based on query complexity.
    
    Features:
    - Rule-based complexity detection
    - Cost-aware routing
    - Latency-aware routing
    - Fallback handling
    """
    
    # Patterns for simple queries (route to fast model)
    SIMPLE_PATTERNS = [
        r"^(what|when|where|who)\s+is\s+",
        r"^(yes|no)\s+or\s+",
        r"balance|status|check",
        r"^list\s+(my|the|all)",
        r"^show\s+(me\s+)?(my|the)",
        r"^get\s+(my|the)",
        r"current\s+(balance|status|time)",
        r"^(hi|hello|hey|thanks|thank you)",
    ]
    
    # Patterns for complex queries (route to premium model)
    COMPLEX_PATTERNS = [
        r"analyze\s+.{20,}",
        r"compare\s+.{20,}\s+(and|with|versus|vs)",
        r"explain\s+(in detail|thoroughly|comprehensively)",
        r"(step.by.step|detailed)\s+(analysis|explanation|guide)",
        r"(summarize|review)\s+(this|the)\s+(document|report|article)",
        r"(write|create|generate)\s+(a|an)\s+(report|analysis|review)",
        r"(investment|financial|legal)\s+(advice|analysis|recommendation)",
        r"(over|across)\s+(the\s+)?(last|past|next)\s+\d+\s+(months?|years?|quarters?)",
        r"(predict|forecast|project)",
        r"(optimize|improve|enhance)\s+.{10,}",
    ]
    
    # Keywords that indicate complexity
    COMPLEXITY_KEYWORDS = {
        "high": ["analyze", "compare", "comprehensive", "detailed", "investment",
                "forecast", "strategy", "optimize", "evaluate", "synthesize"],
        "medium": ["explain", "describe", "summarize", "review", "calculate",
                  "recommend", "suggest", "plan", "report"],
        "low": ["what", "when", "where", "who", "is", "are", "show", "list",
               "get", "check", "status", "balance", "current"]
    }
    
    def __init__(
        self,
        models: Dict[str, ModelConfig] = None,
        cost_weight: float = 0.4,
        latency_weight: float = 0.3,
        quality_weight: float = 0.3,
        default_model: str = "llama-3.1-70b"
    ):
        """
        Initialize the model router.
        
        Args:
            models: Available model configurations
            cost_weight: Weight for cost in routing decision
            latency_weight: Weight for latency in routing decision
            quality_weight: Weight for quality in routing decision
            default_model: Default model when routing is uncertain
        """
        self.models = models or MODEL_CONFIGS
        self.cost_weight = cost_weight
        self.latency_weight = latency_weight
        self.quality_weight = quality_weight
        self.default_model = default_model
        
        # Compile patterns
        self._simple_patterns = [re.compile(p, re.IGNORECASE) for p in self.SIMPLE_PATTERNS]
        self._complex_patterns = [re.compile(p, re.IGNORECASE) for p in self.COMPLEX_PATTERNS]
    
    def route(
        self,
        prompt: str,
        max_cost: float = None,
        max_latency_ms: float = None,
        required_capabilities: List[str] = None
    ) -> RoutingDecision:
        """
        Route a prompt to the optimal model.
        
        Args:
            prompt: The user prompt
            max_cost: Maximum acceptable cost
            max_latency_ms: Maximum acceptable latency
            required_capabilities: Required model capabilities
            
        Returns:
            RoutingDecision with selected model and reasoning
        """
        # Analyze prompt complexity
        complexity_score = self._analyze_complexity(prompt)
        
        # Determine target tier
        if complexity_score < 0.3:
            target_tier = ModelTier.FAST
        elif complexity_score < 0.7:
            target_tier = ModelTier.STANDARD
        else:
            target_tier = ModelTier.PREMIUM
        
        # Filter models by constraints
        eligible_models = []
        for name, config in self.models.items():
            # Check latency constraint
            if max_latency_ms and config.avg_latency_ms > max_latency_ms:
                continue
            
            # Check capability requirements
            if required_capabilities:
                if not all(cap in config.capabilities for cap in required_capabilities):
                    continue
            
            eligible_models.append((name, config))
        
        if not eligible_models:
            # Fallback to default
            config = self.models[self.default_model]
            return RoutingDecision(
                model=self.default_model,
                tier=config.tier,
                confidence=0.5,
                reasoning="No eligible models found, using default",
                estimated_cost=self._estimate_cost(prompt, config),
                estimated_latency_ms=config.avg_latency_ms
            )
        
        # Score each eligible model
        best_model = None
        best_score = -1
        best_reasoning = ""
        
        for name, config in eligible_models:
            score, reasoning = self._score_model(
                config, target_tier, complexity_score, prompt, max_cost
            )
            
            if score > best_score:
                best_score = score
                best_model = (name, config)
                best_reasoning = reasoning
        
        name, config = best_model
        
        return RoutingDecision(
            model=name,
            tier=config.tier,
            confidence=min(best_score, 1.0),
            reasoning=best_reasoning,
            estimated_cost=self._estimate_cost(prompt, config),
            estimated_latency_ms=config.avg_latency_ms
        )
    
    def _analyze_complexity(self, prompt: str) -> float:
        """
        Analyze prompt complexity on a 0-1 scale.
        
        0 = simple, 1 = complex
        """
        score = 0.5  # Start neutral
        
        # Check simple patterns
        for pattern in self._simple_patterns:
            if pattern.search(prompt):
                score -= 0.15
        
        # Check complex patterns
        for pattern in self._complex_patterns:
            if pattern.search(prompt):
                score += 0.2
        
        # Check keywords
        prompt_lower = prompt.lower()
        
        for keyword in self.COMPLEXITY_KEYWORDS["high"]:
            if keyword in prompt_lower:
                score += 0.1
        
        for keyword in self.COMPLEXITY_KEYWORDS["low"]:
            if keyword in prompt_lower:
                score -= 0.05
        
        # Length factor
        word_count = len(prompt.split())
        if word_count > 100:
            score += 0.2
        elif word_count > 50:
            score += 0.1
        elif word_count < 10:
            score -= 0.1
        
        # Clamp to 0-1
        return max(0.0, min(1.0, score))
    
    def _score_model(
        self,
        config: ModelConfig,
        target_tier: ModelTier,
        complexity: float,
        prompt: str,
        max_cost: float
    ) -> Tuple[float, str]:
        """Score a model for the given request."""
        score = 0.0
        reasons = []
        
        # Tier matching
        tier_match = 1.0 if config.tier == target_tier else 0.5
        score += tier_match * self.quality_weight
        
        if config.tier == target_tier:
            reasons.append(f"Tier matches complexity ({target_tier.value})")
        
        # Cost scoring (lower is better)
        estimated_cost = self._estimate_cost(prompt, config)
        if max_cost and estimated_cost <= max_cost:
            cost_score = 1.0 - (estimated_cost / max_cost)
        else:
            cost_score = 0.5
        score += cost_score * self.cost_weight
        
        if cost_score > 0.7:
            reasons.append(f"Cost efficient (${estimated_cost:.4f})")
        
        # Latency scoring (lower is better, normalized to 2000ms max)
        latency_score = 1.0 - min(config.avg_latency_ms / 2000, 1.0)
        score += latency_score * self.latency_weight
        
        if config.avg_latency_ms < 300:
            reasons.append(f"Fast response ({config.avg_latency_ms}ms)")
        
        return score, "; ".join(reasons)
    
    def _estimate_cost(self, prompt: str, config: ModelConfig) -> float:
        """Estimate cost for processing a prompt."""
        # Rough token estimation (4 chars per token)
        input_tokens = len(prompt) / 4
        # Assume output is similar length to input
        output_tokens = input_tokens * 1.5
        
        input_cost = (input_tokens / 1000) * config.cost_per_1k_input_tokens
        output_cost = (output_tokens / 1000) * config.cost_per_1k_output_tokens
        
        return input_cost + output_cost


# =============================================================================
# SOLUTION: Cost Optimizer Orchestrator
# =============================================================================

@dataclass
class OptimizationResult:
    """Result of cost optimization."""
    model_used: str
    cache_hit: bool
    semantic_match: bool
    original_cost: float
    actual_cost: float
    cost_saved: float
    latency_ms: float
    routing_decision: Optional[RoutingDecision] = None


class CostOptimizer:
    """
    SOLUTION: Complete cost optimization system combining caching and routing.
    
    Features:
    - Semantic caching
    - Intelligent model routing
    - Request batching
    - Real-time cost tracking
    - Budget enforcement
    """
    
    def __init__(
        self,
        cache_enabled: bool = True,
        routing_enabled: bool = True,
        daily_budget: float = 10000.0,
        alert_threshold: float = 0.8
    ):
        """
        Initialize the cost optimizer.
        
        Args:
            cache_enabled: Enable semantic caching
            routing_enabled: Enable model routing
            daily_budget: Daily budget in USD
            alert_threshold: Alert when budget utilization exceeds this
        """
        self.cache_enabled = cache_enabled
        self.routing_enabled = routing_enabled
        self.daily_budget = daily_budget
        self.alert_threshold = alert_threshold
        
        # Initialize components
        self.cache = SemanticCache(
            max_entries=10000,
            similarity_threshold=0.92,
            default_ttl_seconds=3600
        ) if cache_enabled else None
        
        self.router = ModelRouter() if routing_enabled else None
        
        # Cost tracking
        self._daily_cost = 0.0
        self._daily_cost_reset = datetime.utcnow().date()
        self._total_cost_saved = 0.0
        self._request_count = 0
        
        # Metrics for Prometheus
        self._metrics = {
            "requests_total": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "cost_saved_total": 0.0,
            "model_requests": defaultdict(int),
            "routing_decisions": defaultdict(int)
        }
    
    async def process_request(
        self,
        prompt: str,
        max_cost: float = None,
        max_latency_ms: float = None,
        required_capabilities: List[str] = None,
        force_model: str = None
    ) -> OptimizationResult:
        """
        Process a request with cost optimization.
        
        Args:
            prompt: The user prompt
            max_cost: Maximum acceptable cost
            max_latency_ms: Maximum acceptable latency
            required_capabilities: Required model capabilities
            force_model: Force use of specific model (bypass routing)
            
        Returns:
            OptimizationResult with optimization details
        """
        start_time = time.time()
        self._request_count += 1
        self._metrics["requests_total"] += 1
        
        # Reset daily cost if needed
        self._check_daily_reset()
        
        # Try cache first
        if self.cache_enabled and self.cache:
            cache_result = self.cache.get(prompt)
            
            if cache_result:
                response, model_used, is_semantic = cache_result
                
                # Calculate cost that would have been incurred
                config = MODEL_CONFIGS.get(model_used, MODEL_CONFIGS["llama-3.1-70b"])
                original_cost = self._estimate_cost(prompt, config)
                
                self._metrics["cache_hits"] += 1
                
                latency = (time.time() - start_time) * 1000
                
                return OptimizationResult(
                    model_used=model_used,
                    cache_hit=True,
                    semantic_match=is_semantic,
                    original_cost=original_cost,
                    actual_cost=0.0,
                    cost_saved=original_cost,
                    latency_ms=latency
                )
            else:
                self._metrics["cache_misses"] += 1
        
        # Route to optimal model
        if force_model:
            config = MODEL_CONFIGS.get(force_model, MODEL_CONFIGS["llama-3.1-70b"])
            routing_decision = RoutingDecision(
                model=force_model,
                tier=config.tier,
                confidence=1.0,
                reasoning="Forced model selection",
                estimated_cost=self._estimate_cost(prompt, config),
                estimated_latency_ms=config.avg_latency_ms
            )
        elif self.routing_enabled and self.router:
            routing_decision = self.router.route(
                prompt=prompt,
                max_cost=max_cost,
                max_latency_ms=max_latency_ms,
                required_capabilities=required_capabilities
            )
        else:
            # Default model
            config = MODEL_CONFIGS["llama-3.1-70b"]
            routing_decision = RoutingDecision(
                model="llama-3.1-70b",
                tier=ModelTier.STANDARD,
                confidence=1.0,
                reasoning="Default model",
                estimated_cost=self._estimate_cost(prompt, config),
                estimated_latency_ms=config.avg_latency_ms
            )
        
        # Track routing decision
        self._metrics["routing_decisions"][routing_decision.tier.value] += 1
        self._metrics["model_requests"][routing_decision.model] += 1
        
        # Check budget
        if self._daily_cost + routing_decision.estimated_cost > self.daily_budget:
            logger.warning(f"Budget exceeded! Daily: ${self._daily_cost:.2f}, Budget: ${self.daily_budget:.2f}")
            # In production, you might want to reject or downgrade the request
        
        # Calculate premium model cost for comparison
        premium_config = MODEL_CONFIGS["gpt-4-turbo"]
        premium_cost = self._estimate_cost(prompt, premium_config)
        
        # Actual cost is the routed model cost
        actual_cost = routing_decision.estimated_cost
        cost_saved = max(0, premium_cost - actual_cost)
        
        # Update tracking
        self._daily_cost += actual_cost
        self._total_cost_saved += cost_saved
        self._metrics["cost_saved_total"] += cost_saved
        
        # Alert if approaching budget
        utilization = self._daily_cost / self.daily_budget
        if utilization > self.alert_threshold:
            logger.warning(f"Budget alert: {utilization*100:.1f}% utilized")
        
        latency = (time.time() - start_time) * 1000
        
        return OptimizationResult(
            model_used=routing_decision.model,
            cache_hit=False,
            semantic_match=False,
            original_cost=premium_cost,
            actual_cost=actual_cost,
            cost_saved=cost_saved,
            latency_ms=latency,
            routing_decision=routing_decision
        )
    
    def cache_response(
        self,
        prompt: str,
        response: str,
        model_used: str,
        token_count: int = 0,
        cost: float = 0.0
    ):
        """Cache a response for future use."""
        if self.cache_enabled and self.cache:
            self.cache.set(
                prompt=prompt,
                response=response,
                model_used=model_used,
                token_count=token_count,
                cost=cost
            )
    
    def _estimate_cost(self, prompt: str, config: ModelConfig) -> float:
        """Estimate cost for a prompt."""
        input_tokens = len(prompt) / 4
        output_tokens = input_tokens * 1.5
        
        input_cost = (input_tokens / 1000) * config.cost_per_1k_input_tokens
        output_cost = (output_tokens / 1000) * config.cost_per_1k_output_tokens
        
        return input_cost + output_cost
    
    def _check_daily_reset(self):
        """Reset daily cost tracking if day has changed."""
        today = datetime.utcnow().date()
        if today != self._daily_cost_reset:
            logger.info(f"Daily cost reset. Previous day total: ${self._daily_cost:.2f}")
            self._daily_cost = 0.0
            self._daily_cost_reset = today
    
    def get_stats(self) -> Dict[str, Any]:
        """Get optimizer statistics."""
        cache_stats = self.cache.get_stats() if self.cache else {}
        
        return {
            "request_count": self._request_count,
            "daily_cost": self._daily_cost,
            "daily_budget": self.daily_budget,
            "budget_utilization": self._daily_cost / self.daily_budget,
            "total_cost_saved": self._total_cost_saved,
            "cache_stats": cache_stats,
            "routing_stats": dict(self._metrics["routing_decisions"]),
            "model_usage": dict(self._metrics["model_requests"])
        }
    
    def get_prometheus_metrics(self) -> str:
        """Generate Prometheus metrics output."""
        lines = []
        
        # Request metrics
        lines.append(f"llm_optimizer_requests_total {self._metrics['requests_total']}")
        lines.append(f"llm_optimizer_cache_hits_total {self._metrics['cache_hits']}")
        lines.append(f"llm_optimizer_cache_misses_total {self._metrics['cache_misses']}")
        
        # Cost metrics
        lines.append(f"llm_optimizer_cost_saved_total {self._metrics['cost_saved_total']:.4f}")
        lines.append(f"llm_optimizer_daily_cost {self._daily_cost:.4f}")
        lines.append(f"llm_optimizer_daily_budget {self.daily_budget:.4f}")
        
        # Cache hit rate
        total_cache = self._metrics['cache_hits'] + self._metrics['cache_misses']
        hit_rate = self._metrics['cache_hits'] / total_cache if total_cache > 0 else 0
        lines.append(f"llm_optimizer_cache_hit_rate {hit_rate:.4f}")
        
        # Model usage
        for model, count in self._metrics["model_requests"].items():
            lines.append(f'llm_optimizer_model_requests{{model="{model}"}} {count}')
        
        # Routing decisions
        for tier, count in self._metrics["routing_decisions"].items():
            lines.append(f'llm_optimizer_routing_decisions{{tier="{tier}"}} {count}')
        
        return "\n".join(lines)


# =============================================================================
# Usage Example
# =============================================================================

async def main():
    """Demonstrate the cost optimizer."""
    
    # Initialize optimizer
    optimizer = CostOptimizer(
        cache_enabled=True,
        routing_enabled=True,
        daily_budget=1000.0,
        alert_threshold=0.8
    )
    
    # Test prompts of varying complexity
    test_prompts = [
        # Simple - should route to fast model
        "What is my account balance?",
        "Show me my last 5 transactions",
        "What time is it?",
        
        # Medium - should route to standard model
        "Explain the difference between checking and savings accounts",
        "Summarize my spending for last month",
        "What are my options for reducing my monthly expenses?",
        
        # Complex - should route to premium model
        "Analyze my spending patterns over the last 6 months and provide detailed recommendations for improving my savings rate, including specific budget allocations for each category",
        "Compare the top 5 mortgage options available to me based on my credit score, income, and the property value of $500,000, providing a comprehensive analysis of total costs over 30 years",
    ]
    
    print("=" * 70)
    print("COST OPTIMIZER DEMONSTRATION")
    print("=" * 70)
    
    # Process each prompt
    for prompt in test_prompts:
        result = await optimizer.process_request(prompt)
        
        print(f"\nPrompt: {prompt[:60]}...")
        print(f"  Model: {result.model_used}")
        print(f"  Cache Hit: {result.cache_hit}")
        print(f"  Original Cost: ${result.original_cost:.6f}")
        print(f"  Actual Cost: ${result.actual_cost:.6f}")
        print(f"  Cost Saved: ${result.cost_saved:.6f}")
        print(f"  Latency: {result.latency_ms:.2f}ms")
        
        if result.routing_decision:
            print(f"  Routing: {result.routing_decision.reasoning}")
        
        # Cache the response (simulating actual LLM response)
        optimizer.cache_response(
            prompt=prompt,
            response=f"[Simulated response for: {prompt[:30]}...]",
            model_used=result.model_used,
            cost=result.actual_cost
        )
    
    # Test cache hits by repeating a prompt
    print("\n" + "-" * 70)
    print("Testing cache hit with repeated prompt...")
    
    repeated_prompt = test_prompts[0]
    result = await optimizer.process_request(repeated_prompt)
    
    print(f"\nPrompt: {repeated_prompt}")
    print(f"  Cache Hit: {result.cache_hit} ✅")
    print(f"  Cost Saved: ${result.cost_saved:.6f}")
    
    # Print statistics
    print("\n" + "=" * 70)
    print("OPTIMIZER STATISTICS")
    print("=" * 70)
    
    stats = optimizer.get_stats()
    print(json.dumps(stats, indent=2, default=str))
    
    # Print Prometheus metrics
    print("\n" + "=" * 70)
    print("PROMETHEUS METRICS")
    print("=" * 70)
    print(optimizer.get_prometheus_metrics())


if __name__ == "__main__":
    asyncio.run(main())
