"""
GlobalAI LLM Platform - Cost Optimization Module
=================================================
Implements cost optimization strategies for LLM inference:
1. Semantic caching for response reuse
2. Intelligent model routing (cheaper model for simple queries)
3. Request batching
4. Resource utilization monitoring

Your task is to:
1. Configure cache TTL and similarity thresholds
2. Tune model routing rules
3. Integrate with your monitoring system
"""

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional, Tuple
import redis
from prometheus_client import Counter, Gauge, Histogram

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# =============================================================================
# Prometheus Metrics
# =============================================================================

CACHE_HITS = Counter(
    'llm_cache_hits_total',
    'Total number of cache hits',
    ['cache_type']
)

CACHE_MISSES = Counter(
    'llm_cache_misses_total', 
    'Total number of cache misses',
    ['cache_type']
)

COST_SAVED = Counter(
    'llm_cost_saved_dollars_total',
    'Total cost saved through optimization',
    ['optimization_type']
)

MODEL_REQUESTS = Counter(
    'llm_model_requests_total',
    'Requests by model',
    ['model', 'routing_reason']
)

CACHE_HIT_RATIO = Gauge(
    'llm_cache_hit_ratio',
    'Current cache hit ratio',
    ['cache_type']
)


# =============================================================================
# Configuration
# =============================================================================

class ModelTier(Enum):
    """Model tiers with different capabilities and costs"""
    FAST = "fast"       # GPT-3.5 / Llama-8B - $0.0005/1K tokens
    STANDARD = "standard"  # GPT-4 / Llama-70B - $0.03/1K tokens
    PREMIUM = "premium"    # GPT-4-Turbo / Claude-3 - $0.06/1K tokens


@dataclass
class ModelConfig:
    """Configuration for each model"""
    name: str
    tier: ModelTier
    cost_per_1k_input_tokens: float
    cost_per_1k_output_tokens: float
    max_context_length: int
    avg_latency_ms: float


# Model configurations
MODELS = {
    "llama-3.1-8b": ModelConfig(
        name="llama-3.1-8b",
        tier=ModelTier.FAST,
        cost_per_1k_input_tokens=0.0005,
        cost_per_1k_output_tokens=0.0015,
        max_context_length=8192,
        avg_latency_ms=200
    ),
    "llama-3.1-70b": ModelConfig(
        name="llama-3.1-70b",
        tier=ModelTier.STANDARD,
        cost_per_1k_input_tokens=0.003,
        cost_per_1k_output_tokens=0.015,
        max_context_length=8192,
        avg_latency_ms=800
    ),
    "gpt-4-turbo": ModelConfig(
        name="gpt-4-turbo",
        tier=ModelTier.PREMIUM,
        cost_per_1k_input_tokens=0.01,
        cost_per_1k_output_tokens=0.03,
        max_context_length=128000,
        avg_latency_ms=1200
    )
}


# =============================================================================
# Semantic Cache Implementation
# =============================================================================

class SemanticCache:
    """
    Cache for LLM responses based on semantic similarity.
    Uses exact match by default; can be extended for embedding-based similarity.
    """
    
    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        ttl_seconds: int = 3600,  # 1 hour default
        max_cache_size_mb: int = 1000
    ):
        self.redis_client = redis.from_url(redis_url)
        self.ttl_seconds = ttl_seconds
        self.max_cache_size_mb = max_cache_size_mb
        self.cache_prefix = "llm_cache:"
        
        # Stats
        self.hits = 0
        self.misses = 0
    
    def _generate_cache_key(self, prompt: str, model: str) -> str:
        """Generate deterministic cache key from prompt and model"""
        content = f"{model}:{prompt.strip().lower()}"
        return f"{self.cache_prefix}{hashlib.sha256(content.encode()).hexdigest()}"
    
    def get(self, prompt: str, model: str) -> Optional[Dict]:
        """
        Look up cached response for the given prompt.
        
        Returns:
            Cached response dict or None if not found
        """
        cache_key = self._generate_cache_key(prompt, model)
        
        try:
            cached = self.redis_client.get(cache_key)
            
            if cached:
                self.hits += 1
                CACHE_HITS.labels(cache_type="semantic").inc()
                self._update_hit_ratio()
                
                response = json.loads(cached)
                logger.info(f"Cache HIT for key {cache_key[:20]}...")
                return response
            else:
                self.misses += 1
                CACHE_MISSES.labels(cache_type="semantic").inc()
                self._update_hit_ratio()
                return None
                
        except Exception as e:
            logger.error(f"Cache lookup error: {e}")
            return None
    
    def set(self, prompt: str, model: str, response: Dict) -> bool:
        """
        Store response in cache.
        
        Args:
            prompt: User prompt
            model: Model used for inference
            response: Response to cache
            
        Returns:
            True if successfully cached
        """
        cache_key = self._generate_cache_key(prompt, model)
        
        try:
            cache_data = {
                "response": response,
                "model": model,
                "cached_at": datetime.utcnow().isoformat(),
                "prompt_hash": hashlib.md5(prompt.encode()).hexdigest()
            }
            
            self.redis_client.setex(
                cache_key,
                self.ttl_seconds,
                json.dumps(cache_data)
            )
            
            logger.info(f"Cached response for key {cache_key[:20]}...")
            return True
            
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False
    
    def _update_hit_ratio(self):
        """Update cache hit ratio metric"""
        total = self.hits + self.misses
        if total > 0:
            ratio = self.hits / total
            CACHE_HIT_RATIO.labels(cache_type="semantic").set(ratio)
    
    def get_stats(self) -> Dict:
        """Get cache statistics"""
        total = self.hits + self.misses
        return {
            "hits": self.hits,
            "misses": self.misses,
            "hit_ratio": self.hits / total if total > 0 else 0,
            "total_requests": total
        }


# =============================================================================
# Intelligent Model Router
# =============================================================================

class ModelRouter:
    """
    Routes requests to appropriate model based on complexity and cost.
    Uses heuristics to determine query complexity.
    """
    
    def __init__(self, default_model: str = "llama-3.1-8b"):
        self.default_model = default_model
        
        # Simple queries that can use fast model
        self.simple_patterns = [
            "what is",
            "who is",
            "when did",
            "where is",
            "how many",
            "define",
            "list",
            "summarize briefly"
        ]
        
        # Complex queries that need premium model
        self.complex_patterns = [
            "analyze",
            "compare and contrast",
            "explain in detail",
            "write a detailed",
            "create a comprehensive",
            "multi-step",
            "code review",
            "debug this"
        ]
    
    def route(
        self,
        prompt: str,
        requested_model: Optional[str] = None,
        user_tier: str = "standard"
    ) -> Tuple[str, str]:
        """
        Route request to appropriate model.
        
        Args:
            prompt: User prompt
            requested_model: Explicitly requested model (if any)
            user_tier: User's subscription tier
            
        Returns:
            Tuple of (model_name, routing_reason)
        """
        # Honor explicit model requests for premium users
        if requested_model and user_tier in ["professional", "enterprise"]:
            return requested_model, "explicit_request"
        
        # Analyze prompt complexity
        prompt_lower = prompt.lower()
        prompt_length = len(prompt)
        
        # Check for simple patterns
        is_simple = any(pattern in prompt_lower for pattern in self.simple_patterns)
        is_complex = any(pattern in prompt_lower for pattern in self.complex_patterns)
        
        # Length-based heuristics
        if prompt_length < 100 and is_simple and not is_complex:
            model = "llama-3.1-8b"
            reason = "simple_query"
        elif prompt_length > 2000 or is_complex:
            model = "llama-3.1-70b"
            reason = "complex_query"
        else:
            model = self.default_model
            reason = "default"
        
        # Log routing decision
        MODEL_REQUESTS.labels(model=model, routing_reason=reason).inc()
        logger.info(f"Routed to {model} (reason: {reason})")
        
        return model, reason
    
    def calculate_cost_savings(
        self,
        routed_model: str,
        original_model: str,
        input_tokens: int,
        output_tokens: int
    ) -> float:
        """Calculate cost savings from routing to a cheaper model"""
        if routed_model == original_model:
            return 0.0
        
        routed_config = MODELS.get(routed_model)
        original_config = MODELS.get(original_model, MODELS["llama-3.1-70b"])
        
        if not routed_config:
            return 0.0
        
        original_cost = (
            (input_tokens / 1000) * original_config.cost_per_1k_input_tokens +
            (output_tokens / 1000) * original_config.cost_per_1k_output_tokens
        )
        
        routed_cost = (
            (input_tokens / 1000) * routed_config.cost_per_1k_input_tokens +
            (output_tokens / 1000) * routed_config.cost_per_1k_output_tokens
        )
        
        savings = original_cost - routed_cost
        
        if savings > 0:
            COST_SAVED.labels(optimization_type="model_routing").inc(savings)
        
        return savings


# =============================================================================
# Cost Optimizer (Main Class)
# =============================================================================

class CostOptimizer:
    """
    Main cost optimization orchestrator.
    Combines caching, routing, and monitoring.
    """
    
    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        cache_enabled: bool = True,
        routing_enabled: bool = True
    ):
        self.cache = SemanticCache(redis_url) if cache_enabled else None
        self.router = ModelRouter() if routing_enabled else None
        
        # Cost tracking
        self.total_cost = 0.0
        self.total_savings = 0.0
        self.requests_processed = 0
    
    async def process_request(
        self,
        prompt: str,
        requested_model: Optional[str] = None,
        user_tier: str = "standard",
        skip_cache: bool = False
    ) -> Dict:
        """
        Process an LLM request with cost optimization.
        
        Args:
            prompt: User prompt
            requested_model: Explicitly requested model
            user_tier: User's subscription tier
            skip_cache: Force skip cache lookup
            
        Returns:
            Dict with model, response source, and cost info
        """
        start_time = time.time()
        self.requests_processed += 1
        
        # Step 1: Route to appropriate model
        if self.router:
            model, routing_reason = self.router.route(prompt, requested_model, user_tier)
        else:
            model = requested_model or "llama-3.1-8b"
            routing_reason = "default"
        
        # Step 2: Check cache
        if self.cache and not skip_cache:
            cached_response = self.cache.get(prompt, model)
            if cached_response:
                # Calculate savings from cache hit
                model_config = MODELS.get(model, MODELS["llama-3.1-8b"])
                estimated_tokens = len(prompt.split()) + 100  # rough estimate
                cache_savings = (
                    (estimated_tokens / 1000) * model_config.cost_per_1k_input_tokens +
                    (estimated_tokens / 1000) * model_config.cost_per_1k_output_tokens
                )
                
                self.total_savings += cache_savings
                COST_SAVED.labels(optimization_type="caching").inc(cache_savings)
                
                return {
                    "model": model,
                    "source": "cache",
                    "response": cached_response["response"],
                    "cost": 0.0,
                    "savings": cache_savings,
                    "latency_ms": (time.time() - start_time) * 1000
                }
        
        # Step 3: Call LLM (simulated here - replace with actual call)
        response = await self._call_llm(prompt, model)
        
        # Step 4: Calculate cost
        model_config = MODELS.get(model, MODELS["llama-3.1-8b"])
        cost = (
            (response["input_tokens"] / 1000) * model_config.cost_per_1k_input_tokens +
            (response["output_tokens"] / 1000) * model_config.cost_per_1k_output_tokens
        )
        self.total_cost += cost
        
        # Step 5: Cache the response
        if self.cache:
            self.cache.set(prompt, model, response)
        
        # Step 6: Calculate routing savings
        routing_savings = 0.0
        if self.router and routing_reason != "explicit_request":
            routing_savings = self.router.calculate_cost_savings(
                model,
                requested_model or "llama-3.1-70b",
                response["input_tokens"],
                response["output_tokens"]
            )
            self.total_savings += routing_savings
        
        return {
            "model": model,
            "source": "inference",
            "response": response,
            "cost": cost,
            "savings": routing_savings,
            "routing_reason": routing_reason,
            "latency_ms": (time.time() - start_time) * 1000
        }
    
    async def _call_llm(self, prompt: str, model: str) -> Dict:
        """
        Call the LLM model. Replace with actual implementation.
        """
        # Simulate API call latency
        model_config = MODELS.get(model, MODELS["llama-3.1-8b"])
        await asyncio.sleep(model_config.avg_latency_ms / 1000)
        
        # Simulated response
        return {
            "text": f"Response from {model} for: {prompt[:50]}...",
            "input_tokens": len(prompt.split()),
            "output_tokens": 50,
            "model": model
        }
    
    def get_stats(self) -> Dict:
        """Get optimization statistics"""
        return {
            "requests_processed": self.requests_processed,
            "total_cost": round(self.total_cost, 4),
            "total_savings": round(self.total_savings, 4),
            "savings_percentage": round(
                (self.total_savings / (self.total_cost + self.total_savings) * 100)
                if (self.total_cost + self.total_savings) > 0 else 0,
                2
            ),
            "cache_stats": self.cache.get_stats() if self.cache else None
        }


# =============================================================================
# Usage Example
# =============================================================================

async def main():
    """Demonstrate cost optimization"""
    
    optimizer = CostOptimizer(
        redis_url="redis://localhost:6379",
        cache_enabled=True,
        routing_enabled=True
    )
    
    # Test prompts
    test_prompts = [
        "What is the capital of France?",  # Simple - should route to fast model
        "Explain in detail the economic implications of quantum computing on financial markets",  # Complex
        "What is the capital of France?",  # Duplicate - should hit cache
        "List 5 countries in Europe",  # Simple
    ]
    
    print("=" * 60)
    print("Cost Optimization Demo")
    print("=" * 60)
    
    for prompt in test_prompts:
        result = await optimizer.process_request(prompt)
        print(f"\nPrompt: {prompt[:50]}...")
        print(f"  Model: {result['model']}")
        print(f"  Source: {result['source']}")
        print(f"  Cost: ${result['cost']:.6f}")
        print(f"  Savings: ${result['savings']:.6f}")
        print(f"  Latency: {result['latency_ms']:.0f}ms")
    
    print("\n" + "=" * 60)
    print("Final Statistics")
    print("=" * 60)
    
    stats = optimizer.get_stats()
    print(f"Total Requests: {stats['requests_processed']}")
    print(f"Total Cost: ${stats['total_cost']:.4f}")
    print(f"Total Savings: ${stats['total_savings']:.4f}")
    print(f"Savings Rate: {stats['savings_percentage']:.1f}%")
    
    if stats['cache_stats']:
        print(f"Cache Hit Ratio: {stats['cache_stats']['hit_ratio']:.1%}")


if __name__ == "__main__":
    asyncio.run(main())
