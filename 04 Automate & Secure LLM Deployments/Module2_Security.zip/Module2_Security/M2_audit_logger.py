"""
BankTech LLM Security - Audit Logging Module
=============================================
Comprehensive audit logging for LLM API interactions.
Designed for compliance with SOC 2, GDPR, and PCI-DSS requirements.

Your task is to:
1. Configure the logger for your environment
2. Integrate with your centralized logging system (ELK/CloudWatch)
3. Add custom fields required by your compliance framework
"""

import json
import logging
import hashlib
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum
import os


class EventType(Enum):
    """Types of auditable events"""
    API_REQUEST = "api_request"
    API_RESPONSE = "api_response"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    PROMPT_BLOCKED = "prompt_blocked"
    PII_DETECTED = "pii_detected"
    RATE_LIMIT = "rate_limit"
    ERROR = "error"
    SECURITY_ALERT = "security_alert"
    MODEL_INFERENCE = "model_inference"
    DATA_ACCESS = "data_access"


class Severity(Enum):
    """Event severity levels"""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class AuditEvent:
    """Structured audit event for compliance logging"""
    event_id: str
    timestamp: str
    event_type: str
    severity: str
    service_name: str
    environment: str
    
    # Request context
    request_id: str
    user_id: Optional[str]
    client_ip: Optional[str]
    user_agent: Optional[str]
    
    # API details
    endpoint: Optional[str]
    method: Optional[str]
    status_code: Optional[int]
    latency_ms: Optional[float]
    
    # LLM specific
    model_name: Optional[str]
    model_version: Optional[str]
    prompt_hash: Optional[str]  # Hash of prompt for privacy
    prompt_length: Optional[int]
    response_length: Optional[int]
    tokens_used: Optional[int]
    
    # Security context
    threat_detected: Optional[str]
    risk_level: Optional[str]
    blocked: bool
    
    # Additional metadata
    metadata: Dict[str, Any]


class ComplianceAuditLogger:
    """
    Centralized audit logger for LLM API compliance.
    
    Supports:
    - SOC 2 Type II audit requirements
    - GDPR Article 30 record-keeping
    - PCI-DSS logging requirements
    """
    
    def __init__(
        self,
        service_name: str = "banktech-llm",
        environment: str = "development",
        log_file: Optional[str] = None,
        enable_console: bool = True,
        enable_json: bool = True
    ):
        self.service_name = service_name
        self.environment = environment or os.getenv("ENVIRONMENT", "development")
        self.enable_json = enable_json
        
        # Configure logger
        self.logger = logging.getLogger(f"audit.{service_name}")
        self.logger.setLevel(logging.DEBUG)
        self.logger.handlers = []  # Clear existing handlers
        
        # JSON formatter for structured logging
        if enable_json:
            formatter = JsonFormatter()
        else:
            formatter = logging.Formatter(
                '%(asctime)s | %(levelname)s | %(message)s'
            )
        
        # Console handler
        if enable_console:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)
        
        # File handler
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
    
    def _generate_event_id(self) -> str:
        """Generate unique event ID"""
        return str(uuid.uuid4())
    
    def _get_timestamp(self) -> str:
        """Get ISO 8601 timestamp in UTC"""
        return datetime.now(timezone.utc).isoformat()
    
    def _hash_prompt(self, prompt: str) -> str:
        """
        Create SHA-256 hash of prompt for audit trail without storing actual content.
        This allows correlation without PII exposure.
        """
        return hashlib.sha256(prompt.encode()).hexdigest()[:16]
    
    def log_api_request(
        self,
        request_id: str,
        user_id: Optional[str],
        client_ip: str,
        endpoint: str,
        method: str,
        prompt: str,
        model_name: str,
        user_agent: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> str:
        """
        Log incoming API request.
        
        Returns:
            event_id for correlation with response
        """
        event = AuditEvent(
            event_id=self._generate_event_id(),
            timestamp=self._get_timestamp(),
            event_type=EventType.API_REQUEST.value,
            severity=Severity.INFO.value,
            service_name=self.service_name,
            environment=self.environment,
            request_id=request_id,
            user_id=user_id,
            client_ip=client_ip,
            user_agent=user_agent,
            endpoint=endpoint,
            method=method,
            status_code=None,
            latency_ms=None,
            model_name=model_name,
            model_version=None,
            prompt_hash=self._hash_prompt(prompt),
            prompt_length=len(prompt),
            response_length=None,
            tokens_used=None,
            threat_detected=None,
            risk_level=None,
            blocked=False,
            metadata=metadata or {}
        )
        
        self.logger.info(json.dumps(asdict(event)))
        return event.event_id
    
    def log_api_response(
        self,
        request_id: str,
        event_id: str,
        status_code: int,
        latency_ms: float,
        response_length: int,
        tokens_used: int,
        model_version: str,
        user_id: Optional[str] = None,
        metadata: Optional[Dict] = None
    ):
        """Log API response for request correlation"""
        event = AuditEvent(
            event_id=self._generate_event_id(),
            timestamp=self._get_timestamp(),
            event_type=EventType.API_RESPONSE.value,
            severity=Severity.INFO.value,
            service_name=self.service_name,
            environment=self.environment,
            request_id=request_id,
            user_id=user_id,
            client_ip=None,
            user_agent=None,
            endpoint=None,
            method=None,
            status_code=status_code,
            latency_ms=latency_ms,
            model_name=None,
            model_version=model_version,
            prompt_hash=None,
            prompt_length=None,
            response_length=response_length,
            tokens_used=tokens_used,
            threat_detected=None,
            risk_level=None,
            blocked=False,
            metadata={**(metadata or {}), "correlated_event_id": event_id}
        )
        
        self.logger.info(json.dumps(asdict(event)))
    
    def log_security_event(
        self,
        request_id: str,
        user_id: Optional[str],
        client_ip: str,
        threat_type: str,
        risk_level: str,
        blocked: bool,
        prompt_hash: str,
        details: str,
        metadata: Optional[Dict] = None
    ):
        """Log security-related events (prompt injection, PII detection, etc.)"""
        severity = Severity.CRITICAL if blocked else Severity.WARNING
        
        event = AuditEvent(
            event_id=self._generate_event_id(),
            timestamp=self._get_timestamp(),
            event_type=EventType.SECURITY_ALERT.value,
            severity=severity.value,
            service_name=self.service_name,
            environment=self.environment,
            request_id=request_id,
            user_id=user_id,
            client_ip=client_ip,
            user_agent=None,
            endpoint=None,
            method=None,
            status_code=403 if blocked else None,
            latency_ms=None,
            model_name=None,
            model_version=None,
            prompt_hash=prompt_hash,
            prompt_length=None,
            response_length=None,
            tokens_used=None,
            threat_detected=threat_type,
            risk_level=risk_level,
            blocked=blocked,
            metadata={**(metadata or {}), "details": details}
        )
        
        self.logger.warning(json.dumps(asdict(event)))
    
    def log_authentication(
        self,
        request_id: str,
        user_id: str,
        client_ip: str,
        success: bool,
        auth_method: str,
        failure_reason: Optional[str] = None
    ):
        """Log authentication attempts for compliance"""
        severity = Severity.INFO if success else Severity.WARNING
        
        event = AuditEvent(
            event_id=self._generate_event_id(),
            timestamp=self._get_timestamp(),
            event_type=EventType.AUTHENTICATION.value,
            severity=severity.value,
            service_name=self.service_name,
            environment=self.environment,
            request_id=request_id,
            user_id=user_id,
            client_ip=client_ip,
            user_agent=None,
            endpoint="/auth",
            method="POST",
            status_code=200 if success else 401,
            latency_ms=None,
            model_name=None,
            model_version=None,
            prompt_hash=None,
            prompt_length=None,
            response_length=None,
            tokens_used=None,
            threat_detected=None,
            risk_level=None,
            blocked=not success,
            metadata={
                "auth_method": auth_method,
                "success": success,
                "failure_reason": failure_reason
            }
        )
        
        self.logger.info(json.dumps(asdict(event)))
    
    def log_rate_limit(
        self,
        request_id: str,
        user_id: str,
        client_ip: str,
        limit_type: str,
        current_count: int,
        limit_threshold: int
    ):
        """Log rate limiting events"""
        event = AuditEvent(
            event_id=self._generate_event_id(),
            timestamp=self._get_timestamp(),
            event_type=EventType.RATE_LIMIT.value,
            severity=Severity.WARNING.value,
            service_name=self.service_name,
            environment=self.environment,
            request_id=request_id,
            user_id=user_id,
            client_ip=client_ip,
            user_agent=None,
            endpoint=None,
            method=None,
            status_code=429,
            latency_ms=None,
            model_name=None,
            model_version=None,
            prompt_hash=None,
            prompt_length=None,
            response_length=None,
            tokens_used=None,
            threat_detected=None,
            risk_level="medium",
            blocked=True,
            metadata={
                "limit_type": limit_type,
                "current_count": current_count,
                "limit_threshold": limit_threshold
            }
        )
        
        self.logger.warning(json.dumps(asdict(event)))


class JsonFormatter(logging.Formatter):
    """JSON formatter for structured logging"""
    
    def format(self, record):
        if isinstance(record.msg, str):
            try:
                # If message is already JSON, parse and re-format
                return record.msg
            except json.JSONDecodeError:
                pass
        
        log_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage()
        }
        
        return json.dumps(log_record)


# =============================================================================
# Usage Example
# =============================================================================

if __name__ == "__main__":
    # Initialize audit logger
    audit_logger = ComplianceAuditLogger(
        service_name="banktech-llm",
        environment="development",
        enable_console=True,
        enable_json=True
    )
    
    # Simulate API request logging
    request_id = str(uuid.uuid4())
    event_id = audit_logger.log_api_request(
        request_id=request_id,
        user_id="user-12345",
        client_ip="192.168.1.100",
        endpoint="/v1/inference",
        method="POST",
        prompt="What is my account balance?",
        model_name="llama-3.1-8b",
        user_agent="BankTech-Mobile/2.0"
    )
    
    # Simulate response logging
    audit_logger.log_api_response(
        request_id=request_id,
        event_id=event_id,
        status_code=200,
        latency_ms=245.5,
        response_length=150,
        tokens_used=45,
        model_version="v1.2.0",
        user_id="user-12345"
    )
    
    # Simulate security event
    audit_logger.log_security_event(
        request_id=str(uuid.uuid4()),
        user_id="user-67890",
        client_ip="10.0.0.50",
        threat_type="prompt_injection",
        risk_level="critical",
        blocked=True,
        prompt_hash="abc123def456",
        details="Detected instruction override attempt"
    )
    
    print("\n✅ Audit logging demonstration complete")
    print("In production, these logs would be sent to ELK Stack or CloudWatch")
