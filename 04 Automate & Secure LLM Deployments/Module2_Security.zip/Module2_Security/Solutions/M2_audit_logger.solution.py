"""
=============================================================================
BankTech LLM Security - SOLUTION: Complete Compliance Audit Logging System
=============================================================================
This is the SOLUTION file demonstrating:
1. Comprehensive audit event capture
2. SOC2, GDPR, PCI-DSS compliance fields
3. Tamper-evident logging with checksums
4. Async batch logging for performance
5. Log rotation and retention management
=============================================================================
"""

import json
import hashlib
import logging
import os
import gzip
import asyncio
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from enum import Enum
from pathlib import Path
import threading
from queue import Queue
import uuid


class EventType(Enum):
    """Types of audit events."""
    API_REQUEST = "api_request"
    API_RESPONSE = "api_response"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    RATE_LIMIT = "rate_limit"
    SECURITY_ALERT = "security_alert"
    DATA_ACCESS = "data_access"
    CONFIGURATION_CHANGE = "configuration_change"
    USER_ACTION = "user_action"
    SYSTEM_EVENT = "system_event"
    COMPLIANCE_CHECK = "compliance_check"
    PII_ACCESS = "pii_access"
    MODEL_INFERENCE = "model_inference"


class Severity(Enum):
    """Event severity levels."""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class ComplianceFramework(Enum):
    """Supported compliance frameworks."""
    SOC2 = "SOC2"
    GDPR = "GDPR"
    PCI_DSS = "PCI_DSS"
    HIPAA = "HIPAA"
    ISO27001 = "ISO27001"


@dataclass
class AuditEvent:
    """
    SOLUTION: Comprehensive audit event with all compliance fields.
    """
    # Core fields
    event_id: str
    timestamp: str
    event_type: str
    severity: str
    
    # Request context
    request_id: Optional[str] = None
    correlation_id: Optional[str] = None
    session_id: Optional[str] = None
    
    # User context
    user_id: Optional[str] = None
    consumer_id: Optional[str] = None
    client_ip: Optional[str] = None
    user_agent: Optional[str] = None
    
    # API context
    endpoint: Optional[str] = None
    method: Optional[str] = None
    status_code: Optional[int] = None
    response_time_ms: Optional[float] = None
    
    # LLM-specific fields
    model_id: Optional[str] = None
    model_version: Optional[str] = None
    prompt_hash: Optional[str] = None
    prompt_length: Optional[int] = None
    response_hash: Optional[str] = None
    response_length: Optional[int] = None
    token_count_input: Optional[int] = None
    token_count_output: Optional[int] = None
    
    # Security fields
    authentication_method: Optional[str] = None
    authorization_scope: Optional[List[str]] = None
    security_flags: Optional[List[str]] = None
    threat_level: Optional[str] = None
    pii_detected: Optional[bool] = None
    pii_types: Optional[List[str]] = None
    
    # Compliance fields
    compliance_frameworks: Optional[List[str]] = None
    data_classification: Optional[str] = None
    retention_days: Optional[int] = None
    legal_hold: bool = False
    
    # Additional context
    resource_id: Optional[str] = None
    action: Optional[str] = None
    outcome: Optional[str] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    
    # Integrity
    previous_hash: Optional[str] = None
    event_hash: Optional[str] = None
    
    def __post_init__(self):
        """Calculate event hash after initialization."""
        if not self.event_hash:
            self.event_hash = self._calculate_hash()
    
    def _calculate_hash(self) -> str:
        """Calculate tamper-evident hash of the event."""
        hash_data = {
            "event_id": self.event_id,
            "timestamp": self.timestamp,
            "event_type": self.event_type,
            "user_id": self.user_id,
            "request_id": self.request_id,
            "previous_hash": self.previous_hash
        }
        hash_string = json.dumps(hash_data, sort_keys=True)
        return hashlib.sha256(hash_string.encode()).hexdigest()


class ComplianceAuditLogger:
    """
    SOLUTION: Production-grade compliance audit logging system.
    
    Features:
    - Async batch logging for high throughput
    - Tamper-evident chain of events
    - Automatic log rotation and compression
    - Multi-destination output (file, stdout, remote)
    - Compliance-specific event enrichment
    """
    
    def __init__(
        self,
        log_dir: str = "/var/log/banktech/audit",
        service_name: str = "llm-api",
        environment: str = "production",
        batch_size: int = 100,
        flush_interval_seconds: float = 5.0,
        retention_days: int = 2555,  # ~7 years for compliance
        enable_compression: bool = True,
        enable_chain_integrity: bool = True
    ):
        """
        Initialize the audit logger.
        
        Args:
            log_dir: Directory for audit logs
            service_name: Name of the service
            environment: Deployment environment
            batch_size: Number of events to batch before writing
            flush_interval_seconds: Max time between flushes
            retention_days: Days to retain logs (7 years default for SOC2)
            enable_compression: Compress rotated logs
            enable_chain_integrity: Enable tamper-evident chaining
        """
        self.log_dir = Path(log_dir)
        self.service_name = service_name
        self.environment = environment
        self.batch_size = batch_size
        self.flush_interval = flush_interval_seconds
        self.retention_days = retention_days
        self.enable_compression = enable_compression
        self.enable_chain_integrity = enable_chain_integrity
        
        # Create log directory
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize state
        self._event_queue: Queue = Queue()
        self._last_hash: Optional[str] = None
        self._event_count: int = 0
        self._current_log_file: Optional[Path] = None
        self._lock = threading.Lock()
        
        # Start background worker
        self._running = True
        self._worker_thread = threading.Thread(target=self._background_worker, daemon=True)
        self._worker_thread.start()
        
        # Configure standard logger for fallback
        self._setup_standard_logger()
        
        # Log initialization
        self.log_system_event("audit_logger_initialized", {
            "log_dir": str(self.log_dir),
            "batch_size": batch_size,
            "retention_days": retention_days
        })
    
    def _setup_standard_logger(self):
        """Set up standard Python logger as fallback."""
        self.logger = logging.getLogger(f"audit.{self.service_name}")
        self.logger.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(
            logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        )
        self.logger.addHandler(console_handler)
    
    def _get_current_log_file(self) -> Path:
        """Get the current log file path (rotates daily)."""
        date_str = datetime.utcnow().strftime("%Y-%m-%d")
        return self.log_dir / f"audit-{self.service_name}-{date_str}.jsonl"
    
    def _background_worker(self):
        """Background worker for batch writing."""
        batch: List[AuditEvent] = []
        last_flush = datetime.utcnow()
        
        while self._running:
            try:
                # Get event with timeout
                try:
                    event = self._event_queue.get(timeout=1.0)
                    batch.append(event)
                except:
                    pass
                
                # Check if we should flush
                should_flush = (
                    len(batch) >= self.batch_size or
                    (datetime.utcnow() - last_flush).total_seconds() >= self.flush_interval
                )
                
                if should_flush and batch:
                    self._write_batch(batch)
                    batch = []
                    last_flush = datetime.utcnow()
                    
            except Exception as e:
                self.logger.error(f"Error in audit worker: {e}")
        
        # Final flush on shutdown
        if batch:
            self._write_batch(batch)
    
    def _write_batch(self, batch: List[AuditEvent]):
        """Write a batch of events to the log file."""
        log_file = self._get_current_log_file()
        
        with self._lock:
            try:
                with open(log_file, 'a') as f:
                    for event in batch:
                        f.write(json.dumps(asdict(event)) + '\n')
                
                self._event_count += len(batch)
                self._current_log_file = log_file
                
            except Exception as e:
                self.logger.error(f"Failed to write audit batch: {e}")
                # Fallback to standard logger
                for event in batch:
                    self.logger.info(json.dumps(asdict(event)))
    
    def _create_event(
        self,
        event_type: EventType,
        severity: Severity,
        **kwargs
    ) -> AuditEvent:
        """Create an audit event with common fields populated."""
        event_id = str(uuid.uuid4())
        timestamp = datetime.utcnow().isoformat() + "Z"
        
        # Chain integrity
        previous_hash = None
        if self.enable_chain_integrity:
            previous_hash = self._last_hash
        
        event = AuditEvent(
            event_id=event_id,
            timestamp=timestamp,
            event_type=event_type.value,
            severity=severity.value,
            previous_hash=previous_hash,
            **kwargs
        )
        
        # Update chain
        if self.enable_chain_integrity:
            self._last_hash = event.event_hash
        
        return event
    
    def _enqueue_event(self, event: AuditEvent):
        """Add event to the queue for batch processing."""
        self._event_queue.put(event)
    
    # =========================================================================
    # SOLUTION: Public Logging Methods
    # =========================================================================
    
    def log_api_request(
        self,
        request_id: str,
        user_id: str,
        endpoint: str,
        method: str,
        prompt: str,
        client_ip: str,
        user_agent: str = None,
        model_id: str = None,
        consumer_id: str = None,
        session_id: str = None,
        metadata: Dict[str, Any] = None
    ):
        """
        Log an incoming API request.
        
        This captures all required fields for SOC2 access logging
        and GDPR data subject request tracking.
        """
        # Hash prompt for privacy (never log actual prompt)
        prompt_hash = hashlib.sha256(prompt.encode()).hexdigest()
        
        event = self._create_event(
            event_type=EventType.API_REQUEST,
            severity=Severity.INFO,
            request_id=request_id,
            user_id=user_id,
            consumer_id=consumer_id,
            session_id=session_id,
            endpoint=endpoint,
            method=method,
            prompt_hash=prompt_hash,
            prompt_length=len(prompt),
            client_ip=self._mask_ip(client_ip),  # GDPR: mask last octet
            user_agent=user_agent,
            model_id=model_id,
            compliance_frameworks=[
                ComplianceFramework.SOC2.value,
                ComplianceFramework.GDPR.value,
                ComplianceFramework.PCI_DSS.value
            ],
            action="api_call_initiated",
            metadata=metadata
        )
        
        self._enqueue_event(event)
    
    def log_api_response(
        self,
        request_id: str,
        user_id: str,
        status_code: int,
        response_time_ms: float,
        response: str = None,
        token_count_input: int = None,
        token_count_output: int = None,
        pii_detected: bool = False,
        pii_types: List[str] = None,
        error_code: str = None,
        error_message: str = None,
        metadata: Dict[str, Any] = None
    ):
        """
        Log an API response.
        
        Captures response metadata for performance monitoring
        and PII detection results for compliance.
        """
        # Hash response for integrity verification
        response_hash = None
        response_length = None
        if response:
            response_hash = hashlib.sha256(response.encode()).hexdigest()
            response_length = len(response)
        
        # Determine severity based on status
        if status_code >= 500:
            severity = Severity.ERROR
        elif status_code >= 400:
            severity = Severity.WARNING
        else:
            severity = Severity.INFO
        
        event = self._create_event(
            event_type=EventType.API_RESPONSE,
            severity=severity,
            request_id=request_id,
            user_id=user_id,
            status_code=status_code,
            response_time_ms=response_time_ms,
            response_hash=response_hash,
            response_length=response_length,
            token_count_input=token_count_input,
            token_count_output=token_count_output,
            pii_detected=pii_detected,
            pii_types=pii_types,
            error_code=error_code,
            error_message=error_message,
            action="api_call_completed",
            outcome="success" if status_code < 400 else "failure",
            compliance_frameworks=[
                ComplianceFramework.SOC2.value,
                ComplianceFramework.GDPR.value
            ],
            metadata=metadata
        )
        
        self._enqueue_event(event)
    
    def log_authentication(
        self,
        request_id: str,
        user_id: str,
        authentication_method: str,
        success: bool,
        client_ip: str,
        failure_reason: str = None,
        mfa_used: bool = False,
        token_expiry: str = None,
        metadata: Dict[str, Any] = None
    ):
        """
        Log authentication attempts.
        
        Required for SOC2 CC6.1 (Logical Access Controls)
        and PCI-DSS Requirement 8 (User Authentication).
        """
        event = self._create_event(
            event_type=EventType.AUTHENTICATION,
            severity=Severity.WARNING if not success else Severity.INFO,
            request_id=request_id,
            user_id=user_id,
            authentication_method=authentication_method,
            client_ip=self._mask_ip(client_ip),
            action="authentication_attempt",
            outcome="success" if success else "failure",
            error_message=failure_reason,
            compliance_frameworks=[
                ComplianceFramework.SOC2.value,
                ComplianceFramework.PCI_DSS.value
            ],
            metadata={
                **(metadata or {}),
                "mfa_used": mfa_used,
                "token_expiry": token_expiry
            }
        )
        
        self._enqueue_event(event)
        
        # Alert on repeated failures
        if not success:
            self.logger.warning(
                f"Authentication failure for user {user_id} from {self._mask_ip(client_ip)}"
            )
    
    def log_security_event(
        self,
        request_id: str,
        event_name: str,
        threat_level: str,
        user_id: str = None,
        client_ip: str = None,
        security_flags: List[str] = None,
        blocked: bool = False,
        details: Dict[str, Any] = None
    ):
        """
        Log security-related events.
        
        Captures prompt injection attempts, rate limit violations,
        and other security incidents.
        """
        severity_map = {
            "NONE": Severity.DEBUG,
            "LOW": Severity.INFO,
            "MEDIUM": Severity.WARNING,
            "HIGH": Severity.ERROR,
            "CRITICAL": Severity.CRITICAL
        }
        
        event = self._create_event(
            event_type=EventType.SECURITY_ALERT,
            severity=severity_map.get(threat_level, Severity.WARNING),
            request_id=request_id,
            user_id=user_id,
            client_ip=self._mask_ip(client_ip) if client_ip else None,
            threat_level=threat_level,
            security_flags=security_flags,
            action=event_name,
            outcome="blocked" if blocked else "allowed",
            compliance_frameworks=[
                ComplianceFramework.SOC2.value,
                ComplianceFramework.PCI_DSS.value
            ],
            metadata=details
        )
        
        self._enqueue_event(event)
        
        # Immediate alert for critical threats
        if threat_level in ["HIGH", "CRITICAL"]:
            self.logger.critical(
                f"Security alert: {event_name} - {threat_level} - User: {user_id}"
            )
    
    def log_rate_limit(
        self,
        request_id: str,
        user_id: str,
        consumer_id: str,
        limit_type: str,
        limit_value: int,
        current_value: int,
        exceeded: bool,
        reset_time: str = None
    ):
        """
        Log rate limiting events.
        
        Important for usage tracking and abuse prevention.
        """
        event = self._create_event(
            event_type=EventType.RATE_LIMIT,
            severity=Severity.WARNING if exceeded else Severity.INFO,
            request_id=request_id,
            user_id=user_id,
            consumer_id=consumer_id,
            action="rate_limit_check",
            outcome="exceeded" if exceeded else "within_limit",
            metadata={
                "limit_type": limit_type,
                "limit_value": limit_value,
                "current_value": current_value,
                "reset_time": reset_time,
                "utilization_percent": (current_value / limit_value * 100) if limit_value > 0 else 0
            }
        )
        
        self._enqueue_event(event)
    
    def log_pii_access(
        self,
        request_id: str,
        user_id: str,
        pii_types: List[str],
        action: str,
        data_subject_id: str = None,
        purpose: str = None,
        legal_basis: str = None
    ):
        """
        Log PII access events.
        
        Required for GDPR Article 30 (Records of Processing)
        and data subject access requests.
        """
        event = self._create_event(
            event_type=EventType.PII_ACCESS,
            severity=Severity.INFO,
            request_id=request_id,
            user_id=user_id,
            pii_detected=True,
            pii_types=pii_types,
            action=action,
            data_classification="PII",
            compliance_frameworks=[
                ComplianceFramework.GDPR.value,
                ComplianceFramework.PCI_DSS.value
            ],
            metadata={
                "data_subject_id": data_subject_id,
                "purpose": purpose,
                "legal_basis": legal_basis
            }
        )
        
        self._enqueue_event(event)
    
    def log_model_inference(
        self,
        request_id: str,
        user_id: str,
        model_id: str,
        model_version: str,
        token_count_input: int,
        token_count_output: int,
        inference_time_ms: float,
        cache_hit: bool = False,
        cost_usd: float = None
    ):
        """
        Log model inference events.
        
        Captures usage metrics for billing and performance monitoring.
        """
        event = self._create_event(
            event_type=EventType.MODEL_INFERENCE,
            severity=Severity.INFO,
            request_id=request_id,
            user_id=user_id,
            model_id=model_id,
            model_version=model_version,
            token_count_input=token_count_input,
            token_count_output=token_count_output,
            response_time_ms=inference_time_ms,
            action="model_inference",
            outcome="success",
            metadata={
                "cache_hit": cache_hit,
                "cost_usd": cost_usd,
                "tokens_per_second": (token_count_output / (inference_time_ms / 1000)) 
                    if inference_time_ms > 0 else 0
            }
        )
        
        self._enqueue_event(event)
    
    def log_system_event(
        self,
        event_name: str,
        details: Dict[str, Any] = None,
        severity: Severity = Severity.INFO
    ):
        """Log system-level events."""
        event = self._create_event(
            event_type=EventType.SYSTEM_EVENT,
            severity=severity,
            action=event_name,
            metadata={
                "service_name": self.service_name,
                "environment": self.environment,
                **(details or {})
            }
        )
        
        self._enqueue_event(event)
    
    # =========================================================================
    # Helper Methods
    # =========================================================================
    
    def _mask_ip(self, ip: str) -> str:
        """
        Mask IP address for GDPR compliance.
        Replaces last octet with 0.
        """
        if not ip:
            return None
        parts = ip.split('.')
        if len(parts) == 4:
            parts[-1] = '0'
            return '.'.join(parts)
        return ip
    
    def rotate_logs(self):
        """Rotate and compress old log files."""
        if not self.enable_compression:
            return
        
        cutoff = datetime.utcnow() - timedelta(days=1)
        
        for log_file in self.log_dir.glob("audit-*.jsonl"):
            # Skip current file
            if log_file == self._current_log_file:
                continue
            
            # Check if file should be compressed
            try:
                file_date = datetime.strptime(
                    log_file.stem.split('-')[-1], 
                    "%Y-%m-%d"
                )
                if file_date.date() < cutoff.date():
                    # Compress
                    compressed_path = log_file.with_suffix('.jsonl.gz')
                    with open(log_file, 'rb') as f_in:
                        with gzip.open(compressed_path, 'wb') as f_out:
                            f_out.writelines(f_in)
                    log_file.unlink()
                    self.logger.info(f"Compressed {log_file} to {compressed_path}")
            except Exception as e:
                self.logger.error(f"Error rotating {log_file}: {e}")
    
    def cleanup_old_logs(self):
        """Remove logs older than retention period."""
        cutoff = datetime.utcnow() - timedelta(days=self.retention_days)
        
        for log_file in self.log_dir.glob("audit-*"):
            try:
                # Extract date from filename
                date_str = log_file.stem.split('-')[-1].replace('.jsonl', '')
                file_date = datetime.strptime(date_str, "%Y-%m-%d")
                
                if file_date < cutoff:
                    log_file.unlink()
                    self.logger.info(f"Deleted expired log: {log_file}")
            except Exception as e:
                self.logger.error(f"Error cleaning up {log_file}: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get logger statistics."""
        return {
            "total_events_logged": self._event_count,
            "queue_size": self._event_queue.qsize(),
            "current_log_file": str(self._current_log_file),
            "log_directory": str(self.log_dir),
            "retention_days": self.retention_days
        }
    
    def flush(self):
        """Force flush all pending events."""
        while not self._event_queue.empty():
            try:
                self._event_queue.get_nowait()
            except:
                break
    
    def shutdown(self):
        """Gracefully shutdown the logger."""
        self._running = False
        self._worker_thread.join(timeout=10)
        self.log_system_event("audit_logger_shutdown")
        self.flush()


# =============================================================================
# Usage Example
# =============================================================================

if __name__ == "__main__":
    # Initialize logger
    logger = ComplianceAuditLogger(
        log_dir="/tmp/audit_logs",
        service_name="llm-api",
        environment="development"
    )
    
    # Simulate a complete API request flow
    request_id = str(uuid.uuid4())
    user_id = "user_12345"
    
    # 1. Log authentication
    logger.log_authentication(
        request_id=request_id,
        user_id=user_id,
        authentication_method="jwt",
        success=True,
        client_ip="192.168.1.100",
        mfa_used=False
    )
    
    # 2. Log API request
    logger.log_api_request(
        request_id=request_id,
        user_id=user_id,
        endpoint="/v1/inference",
        method="POST",
        prompt="What is my account balance?",
        client_ip="192.168.1.100",
        model_id="llama-3.1-70b",
        consumer_id="enterprise-tier"
    )
    
    # 3. Log security check
    logger.log_security_event(
        request_id=request_id,
        event_name="prompt_validation",
        threat_level="NONE",
        user_id=user_id,
        security_flags=[],
        blocked=False
    )
    
    # 4. Log model inference
    logger.log_model_inference(
        request_id=request_id,
        user_id=user_id,
        model_id="llama-3.1-70b",
        model_version="v1.0.0",
        token_count_input=25,
        token_count_output=150,
        inference_time_ms=450.5,
        cache_hit=False,
        cost_usd=0.0015
    )
    
    # 5. Log API response
    logger.log_api_response(
        request_id=request_id,
        user_id=user_id,
        status_code=200,
        response_time_ms=523.7,
        token_count_input=25,
        token_count_output=150,
        pii_detected=False
    )
    
    # Wait for batch to flush
    import time
    time.sleep(6)
    
    # Print stats
    print("\nLogger Statistics:")
    print(json.dumps(logger.get_stats(), indent=2))
    
    # Shutdown
    logger.shutdown()
    print("\nAudit logger shutdown complete.")
