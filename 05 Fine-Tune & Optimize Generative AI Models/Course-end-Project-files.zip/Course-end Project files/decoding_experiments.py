"""
Decoding Experiments - Step 1
Course: Fine-Tune & Optimize Generative AI Models
Project: Building and Optimizing a Domain-Specific Generative AI Assistant

This script implements multiple decoding strategies to understand how parameters
like temperature, top-k, top-p, and beam search affect output quality for domain-specific tasks.
"""

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM, AutoModelForCausalLM
import torch
import json
import os
from datetime import datetime
from typing import List, Dict, Tuple

class DecodingExperiments:
    """
    Experiment with different decoding strategies for domain-specific text generation.
    """
    
    def __init__(self, model_name: str = "google/flan-t5-small"):
        """
        Initialize the model and tokenizer.
        
        Args:
            model_name: HuggingFace model identifier
        """
        print(f"Loading model: {model_name}")
        self.model_name = model_name
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        # Load appropriate model type
        if "t5" in model_name.lower():
            self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
            self.model_type = "seq2seq"
        else:
            self.model = AutoModelForCausalLM.from_pretrained(model_name)
            self.model_type = "causal"
        
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model.to(self.device)
        print(f"✓ Model loaded on {self.device}")
    
    def generate_with_strategy(
        self,
        prompt: str,
        strategy_name: str,
        max_length: int = 150,
        temperature: float = 1.0,
        top_k: int = 50,
        top_p: float = 1.0,
        do_sample: bool = True,
        num_beams: int = 1,
        num_return_sequences: int = 1
    ) -> Tuple[List[str], Dict]:
        """
        Generate text using specified decoding parameters.
        
        Args:
            prompt: Input text prompt
            strategy_name: Name of decoding strategy (for logging)
            max_length: Maximum length of generated text
            temperature: Controls randomness (0=deterministic, >1=creative)
            top_k: Keep only top k tokens with highest probability
            top_p: Nucleus sampling - cumulative probability threshold
            do_sample: Whether to use sampling (False = greedy)
            num_beams: Number of beams for beam search
            num_return_sequences: Number of sequences to generate
            
        Returns:
            Tuple of (generated texts, metadata dict)
        """
        print(f"\n{'='*70}")
        print(f"Strategy: {strategy_name}")
        print(f"Parameters:")
        print(f"  temperature={temperature}, top_k={top_k}, top_p={top_p}")
        print(f"  do_sample={do_sample}, num_beams={num_beams}")
        print(f"{'='*70}")
        
        # Tokenize input
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        # Generate with specified parameters
        start_time = datetime.now()
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_length=max_length,
                temperature=temperature if do_sample else 1.0,
                top_k=top_k if do_sample else 50,
                top_p=top_p if do_sample else 1.0,
                do_sample=do_sample,
                num_beams=num_beams,
                num_return_sequences=num_return_sequences,
                pad_token_id=self.tokenizer.eos_token_id,
                early_stopping=True if num_beams > 1 else False
            )
        generation_time = (datetime.now() - start_time).total_seconds()
        
        # Decode outputs
        generated_texts = [
            self.tokenizer.decode(output, skip_special_tokens=True)
            for output in outputs
        ]
        
        # Create metadata
        metadata = {
            "strategy": strategy_name,
            "parameters": {
                "temperature": temperature,
                "top_k": top_k,
                "top_p": top_p,
                "do_sample": do_sample,
                "num_beams": num_beams
            },
            "generation_time_seconds": generation_time,
            "output_length_tokens": len(outputs[0])
        }
        
        return generated_texts, metadata
    
    def run_all_experiments(self, test_prompts: List[str], domain: str = "healthcare") -> Dict:
        """
        Run all decoding strategies on a list of domain-specific prompts.
        
        Args:
            test_prompts: List of domain-specific test prompts
            domain: Domain name (for documentation)
            
        Returns:
            Dictionary containing all experimental results
        """
        results = {
            "model": self.model_name,
            "domain": domain,
            "timestamp": datetime.now().isoformat(),
            "experiments": []
        }
        
        strategies = [
            {
                "name": "Greedy Decoding",
                "description": "Deterministic, always picks highest probability token",
                "params": {"temperature": 1.0, "do_sample": False, "num_beams": 1},
                "use_case": "Factual outputs, medical dosages, legal terms"
            },
            {
                "name": "High Creativity",
                "description": "High temperature for diverse, creative outputs",
                "params": {"temperature": 1.2, "top_p": 0.95, "do_sample": True, "num_beams": 1},
                "use_case": "Educational explanations, creative content"
            },
            {
                "name": "Controlled Creativity",
                "description": "Balanced approach with moderate temperature",
                "params": {"temperature": 0.7, "top_k": 50, "do_sample": True, "num_beams": 1},
                "use_case": "General assistant responses, summaries"
            },
            {
                "name": "Beam Search",
                "description": "Multiple hypotheses for more coherent outputs",
                "params": {"temperature": 1.0, "do_sample": False, "num_beams": 4},
                "use_case": "Long-form content, structured responses"
            },
            {
                "name": "Custom Configuration",
                "description": "Domain-optimized parameters",
                "params": {"temperature": 0.8, "top_k": 40, "top_p": 0.9, "do_sample": True, "num_beams": 1},
                "use_case": "Domain-specific, adjust based on your needs"
            }
        ]
        
        for strategy in strategies:
            print(f"\n{'='*70}")
            print(f"TESTING STRATEGY: {strategy['name']}")
            print(f"Description: {strategy['description']}")
            print(f"Best for: {strategy['use_case']}")
            print(f"{'='*70}")
            
            for prompt in test_prompts:
                generated_texts, metadata = self.generate_with_strategy(
                    prompt=prompt,
                    strategy_name=strategy['name'],
                    **strategy['params']
                )
                
                # Store results
                experiment = {
                    "strategy": strategy['name'],
                    "description": strategy['description'],
                    "use_case": strategy['use_case'],
                    "parameters": strategy['params'],
                    "prompt": prompt,
                    "generated_outputs": generated_texts,
                    "metadata": metadata
                }
                results["experiments"].append(experiment)
                
                # Print output
                print(f"\nPrompt: {prompt}")
                print(f"Output: {generated_texts[0]}")
                print(f"Generation time: {metadata['generation_time_seconds']:.3f}s")
        
        return results
    
    def save_results(self, results: Dict, output_dir: str = "results/decoding_outputs"):
        """
        Save experimental results to JSON file.
        
        Args:
            results: Dictionary containing experiment results
            output_dir: Directory to save results
        """
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"decoding_experiments_{results['domain']}_{timestamp}.json"
        filepath = os.path.join(output_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        print(f"\n{'='*70}")
        print(f" Results saved to: {filepath}")
        print(f"{'='*70}")
    
    def generate_comparison_table(self, results: Dict) -> str:
        """
        Generate a markdown comparison table from results.
        
        Args:
            results: Experimental results dictionary
            
        Returns:
            Markdown formatted comparison table
        """
        table = "# Decoding Strategy Comparison\n\n"
        table += f"**Model:** {results['model']}\n"
        table += f"**Domain:** {results['domain']}\n"
        table += f"**Date:** {results['timestamp']}\n\n"
        
        table += "| Strategy | Use Case | Temperature | Top-k | Top-p | Beams | Avg Time (s) |\n"
        table += "|----------|----------|-------------|-------|-------|-------|-------------|\n"
        
        strategy_stats = {}
        for exp in results['experiments']:
            strategy = exp['strategy']
            if strategy not in strategy_stats:
                strategy_stats[strategy] = {
                    'use_case': exp['use_case'],
                    'params': exp['parameters'],
                    'times': []
                }
            strategy_stats[strategy]['times'].append(exp['metadata']['generation_time_seconds'])
        
        for strategy, stats in strategy_stats.items():
            params = stats['params']
            avg_time = sum(stats['times']) / len(stats['times'])
            table += f"| {strategy} | {stats['use_case'][:30]} | "
            table += f"{params.get('temperature', 'N/A')} | "
            table += f"{params.get('top_k', 'N/A')} | "
            table += f"{params.get('top_p', 'N/A')} | "
            table += f"{params.get('num_beams', 1)} | "
            table += f"{avg_time:.3f} |\n"
        
        table += "\n## Analysis Guidelines\n\n"
        table += "For each strategy, document:\n"
        table += "- **Consistency:** Is output repetitive or appropriately varied?\n"
        table += "- **Accuracy:** Any hallucinations or incorrect information?\n"
        table += "- **Tone:** Too casual/formal for the domain?\n"
        table += "- **Terminology:** Correct domain-specific terms?\n\n"
        
        table += "## Recommendations\n\n"
        table += "_[Add your analysis here]_\n\n"
        table += "**Best for factual outputs:** Greedy Decoding\n"
        table += "**Best for creative content:** High Creativity\n"
        table += "**Best for balanced responses:** Controlled Creativity\n"
        table += "**Best for long-form coherence:** Beam Search\n"
        
        return table


def get_domain_prompts(domain: str) -> List[str]:
    """
    Get sample prompts for different domains.
    
    Args:
        domain: Domain name (healthcare, finance, legal, education)
        
    Returns:
        List of domain-specific test prompts
    """
    prompts = {
        "healthcare": [
            "Summarize this patient case: 55-year-old female with hypertension and diabetes presenting with fatigue.",
            "Explain what metformin is used for in simple terms.",
            "What are the common side effects of ibuprofen?",
            "Generate a patient education handout about managing high blood pressure.",
            "Describe the symptoms of Type 2 diabetes."
        ],
        "finance": [
            "Analyze the impact of rising interest rates on mortgage markets.",
            "Explain compound interest to a high school student.",
            "Summarize key risks in cryptocurrency investments.",
            "What factors should investors consider in a recession?",
            "Explain the difference between stocks and bonds."
        ],
        "legal": [
            "Draft a simple confidentiality clause for a software development contract.",
            "Explain intellectual property rights in simple terms.",
            "What is the difference between copyright and trademark?",
            "Summarize key terms of a commercial lease agreement.",
            "Explain what a power of attorney document does."
        ],
        "education": [
            "Create a lesson plan introduction for teaching photosynthesis to 8th graders.",
            "Explain the Pythagorean theorem with a real-world example.",
            "Generate practice questions for algebra I students on linear equations.",
            "How would you explain gravity to a 10-year-old?",
            "Create a study guide summary for the water cycle."
        ]
    }
    
    return prompts.get(domain.lower(), prompts["healthcare"])


def main():
    """
    Main execution function.
    """
    print("="*70)
    print("DECODING EXPERIMENTS - STEP 1")
    print("Project: Building and Optimizing a Domain-Specific AI Assistant")
    print("="*70)
    
    # Configuration
    DOMAIN = "healthcare"  # Change to: healthcare, finance, legal, or education
    MODEL_NAME = "google/flan-t5-small"  # or google/flan-t5-base, gpt2, etc.
    
    print(f"\nConfiguration:")
    print(f"  Domain: {DOMAIN}")
    print(f"  Model: {MODEL_NAME}")
    print(f"\nNote: You can change these in the main() function")
    
    # Get domain-specific prompts
    test_prompts = get_domain_prompts(DOMAIN)
    print(f"\nTest prompts ({len(test_prompts)} total):")
    for i, prompt in enumerate(test_prompts, 1):
        print(f"  {i}. {prompt[:70]}...")
    
    # Initialize experiments
    print(f"\n{'='*70}")
    print("INITIALIZING MODEL")
    print(f"{'='*70}")
    experiments = DecodingExperiments(model_name=MODEL_NAME)
    
    # Run all experiments
    results = experiments.run_all_experiments(test_prompts, domain=DOMAIN)
    
    # Save results
    experiments.save_results(results)
    
    # Generate comparison table
    comparison_table = experiments.generate_comparison_table(results)
    output_dir = "results/decoding_outputs"
    os.makedirs(output_dir, exist_ok=True)
    table_file = os.path.join(output_dir, f"comparison_table_{DOMAIN}.md")
    with open(table_file, 'w', encoding='utf-8') as f:
        f.write(comparison_table)
    print(f"✓ Comparison table saved to: {table_file}")
    
    # Print summary
    print(f"\n{'='*70}")
    print("EXPERIMENT COMPLETE")
    print(f"{'='*70}")
    print(f"\nTotal experiments run: {len(results['experiments'])}")
    print(f"Strategies tested: 5")
    print(f"Prompts per strategy: {len(test_prompts)}")
    print(f"\nNext steps:")
    print("1. Review outputs in results/decoding_outputs/")
    print("2. Fill in the analysis section of comparison_table.md")
    print("3. Select optimal decoding strategy for your domain")
    print("4. Proceed to Step 2: Evaluation Pipeline")


if __name__ == "__main__":
    main()
