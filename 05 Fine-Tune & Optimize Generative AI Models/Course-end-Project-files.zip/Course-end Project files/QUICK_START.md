

##  Quick Setup (5 minutes)

### Step 1: Extract Project Files
```bash
unzip fine-tuning-project.zip
cd fine-tuning-project
```

### Step 2: Run Setup Script
```bash
# Make script executable (Linux/Mac)
chmod +x setup.sh

# Run setup
bash setup.sh
```

### Step 3: Activate Virtual Environment
```bash
# Linux/Mac
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### Step 4: Verify Installation
```bash
python -c "import torch; print(f'PyTorch: {torch.__version__}')"
python -c "import transformers; print(f'Transformers: {transformers.__version__}')"
python -c "import peft; print(f'PEFT: {peft.__version__}')"
```



##  Implementation Order (Recommended)

### Setup and Training
1. Environment setup and configuration
   - Run setup script
   - Review `config.yaml`
   - Explore sample data
   - Read through utility modules

2. Implement `peft_training.py`
   - Start with configuration loading
   - Implement model initialization
   - Add dataset preparation
   - Configure trainer
   - Test training on small dataset

3. Run full training
   - Execute training on full dataset
   - Monitor training progress
   - Save checkpoints

### Evaluation and Experiments
4. Implement `evaluation_pipeline.py`
   - Load trained model
   - Generate predictions
   - Calculate metrics
   - Create evaluation report

5. Implement `decoding_experiments.py`
   - Implement all decoding strategies
   - Run experiments on test prompts
   - Analyze and compare outputs

6. Documentation and submission
   - Write analysis report
   - Clean up code
   - Add documentation
   - Prepare submission

##  Implementation Tips

### Training (Most Important!)
```python
# Start with this template in peft_training.py

def main():
    # 1. Load config
    config = load_config(args.config)
    
    # 2. Setup logging
    setup_logging(config['training']['output_dir'])
    
    # 3. Load model and tokenizer
    model, tokenizer = prepare_model_and_tokenizer(config)
    
    # 4. Prepare datasets
    datasets = prepare_datasets(config, tokenizer)
    
    # 5. Create trainer
    trainer = create_trainer(model, tokenizer, datasets, config)
    
    # 6. Train
    train(trainer)
    
    # 7. Evaluate
    evaluate(trainer)
    
    # 8. Save
    save_model(trainer, config['training']['output_dir'])
```

### Key Utility Functions to Use

**From `utils/model_utils.py`:**
```python
from utils.model_utils import ModelLoader

loader = ModelLoader(config)
model, tokenizer = loader.load_model_for_training()
```

**From `utils/data_preprocessing.py`:**
```python
from utils.data_preprocessing import DataPreprocessor

preprocessor = DataPreprocessor(tokenizer, max_length=512)
datasets = preprocessor.prepare_datasets(
    train_file="data/train.json",
    validation_file="data/validation.json",
    test_file="data/test.json"
)
```

**From `utils/metrics.py`:**
```python
from utils.metrics import MetricsCalculator

calculator = MetricsCalculator()
metrics = calculator.compute_all_metrics(predictions, references)
```

## Configuration Quick Reference

### Essential Settings in `config.yaml`

**For Low-End Hardware:**
```yaml
training:
  per_device_train_batch_size: 2
  per_device_eval_batch_size: 2
  gradient_accumulation_steps: 8
  gradient_checkpointing: true
  fp16: true  # If supported
```

**For High-End Hardware:**
```yaml
training:
  per_device_train_batch_size: 8
  per_device_eval_batch_size: 8
  gradient_accumulation_steps: 2
  gradient_checkpointing: false
  bf16: true  # For A100/H100
```

**LoRA Parameters:**
```yaml
lora:
  r: 8           # Rank (8-16 typical)
  lora_alpha: 16 # Alpha (16-32 typical)
  lora_dropout: 0.05
```

##  Common Issues and Solutions

### Issue 1: CUDA Out of Memory
```yaml
# Solution: Reduce batch size in config.yaml
per_device_train_batch_size: 1
gradient_accumulation_steps: 16
gradient_checkpointing: true
```

### Issue 2: Import Errors
```bash
# Solution: Ensure virtual environment is activated
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Reinstall if needed
pip install -r requirements.txt
```

### Issue 3: Slow Training
```python
# Solution: Check GPU usage
import torch
print(torch.cuda.is_available())
print(torch.cuda.get_device_name(0))

# Enable mixed precision in config.yaml
fp16: true  # or bf16: true
```

### Issue 4: Model Not Loading
```python
# Solution: Check paths
import os
print(os.path.exists("models/checkpoint-XXX"))

# Verify checkpoint structure
ls models/checkpoint-XXX/
```

## Expected Outputs

After completing the project, you should have:

```
outputs/
├── logs/
│   ├── training.log
│   └── tensorboard/
├── evaluation/
│   ├── metrics.json
│   ├── predictions.txt
│   └── evaluation_report.txt
└── experiments/
    ├── decoding_comparison.json
    └── strategy_analysis.txt

models/
├── checkpoint-500/
├── checkpoint-1000/
└── final_model/
    ├── adapter_config.json
    ├── adapter_model.bin
    └── ...
```


