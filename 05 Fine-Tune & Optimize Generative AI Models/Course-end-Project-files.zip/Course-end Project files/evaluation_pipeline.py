"""
Evaluation Pipeline for Domain-Specific AI Assistant
Implements BLEU, ROUGE, BERTScore, and qualitative assessment
Author: Course-end Project
"""

import json
import numpy as np
from datetime import datetime
import os
from collections import defaultdict

# Import evaluation libraries
try:
    from evaluate import load
    import nltk
    from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
    from rouge_score import rouge_scorer
    from bert_score import score as bert_score
except ImportError as e:
    print(f"Missing required library: {e}")
    print("Install with: pip install evaluate nltk rouge-score bert-score")

class EvaluationPipeline:
    """
    Comprehensive evaluation pipeline combining automated metrics and qualitative assessment
    """
    
    def __init__(self, domain="healthcare"):
        """
        Initialize evaluation pipeline
        
        Args:
            domain: Target domain for evaluation
        """
        self.domain = domain
        self.results = []
        
        # Initialize scorers
        print("Initializing evaluation metrics...")
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
        self.smoothing = SmoothingFunction().method1
        
        # Download NLTK data if needed
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            print("Downloading NLTK punkt tokenizer...")
            nltk.download('punkt', quiet=True)
        
        print("Evaluation pipeline initialized ✓")
    
    def load_evaluation_dataset(self, filepath):
        """
        Load evaluation dataset from JSON file
        
        Expected format:
        {
            "examples": [
                {
                    "prompt": "...",
                    "reference": "...",
                    "key_facts": ["fact1", "fact2"],
                    "domain_terms": ["term1", "term2"]
                }
            ]
        }
        """
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        print(f"Loaded {len(data['examples'])} evaluation examples")
        return data['examples']
    
    def calculate_bleu(self, reference, hypothesis):
        """
        Calculate BLEU score (n-gram overlap)
        
        Returns:
            dict with BLEU-1, BLEU-2, BLEU-3, BLEU-4 scores
        """
        # Tokenize
        reference_tokens = [nltk.word_tokenize(reference.lower())]
        hypothesis_tokens = nltk.word_tokenize(hypothesis.lower())
        
        # Calculate BLEU scores with different n-gram weights
        bleu_scores = {}
        weights_list = [
            (1, 0, 0, 0),  # BLEU-1
            (0.5, 0.5, 0, 0),  # BLEU-2
            (0.33, 0.33, 0.33, 0),  # BLEU-3
            (0.25, 0.25, 0.25, 0.25)  # BLEU-4
        ]
        
        for i, weights in enumerate(weights_list, 1):
            score = sentence_bleu(
                reference_tokens,
                hypothesis_tokens,
                weights=weights,
                smoothing_function=self.smoothing
            )
            bleu_scores[f'bleu_{i}'] = round(score, 4)
        
        return bleu_scores
    
    def calculate_rouge(self, reference, hypothesis):
        """
        Calculate ROUGE scores (recall-oriented)
        
        Returns:
            dict with ROUGE-1, ROUGE-2, ROUGE-L scores
        """
        scores = self.rouge_scorer.score(reference, hypothesis)
        
        rouge_scores = {}
        for metric, values in scores.items():
            rouge_scores[f'{metric}_precision'] = round(values.precision, 4)
            rouge_scores[f'{metric}_recall'] = round(values.recall, 4)
            rouge_scores[f'{metric}_fmeasure'] = round(values.fmeasure, 4)
        
        return rouge_scores
    
    def calculate_bertscore(self, references, hypotheses):
        """
        Calculate BERTScore (semantic similarity)
        Note: Processes in batch for efficiency
        
        Returns:
            list of dicts with precision, recall, F1
        """
        if not references or not hypotheses:
            return []
        
        print("Computing BERTScore (this may take a moment)...", end=" ")
        P, R, F1 = bert_score(
            hypotheses,
            references,
            lang="en",
            verbose=False,
            device="cuda" if os.system("nvidia-smi > /dev/null 2>&1") == 0 else "cpu"
        )
        print("✓")
        
        bert_scores = []
        for p, r, f1 in zip(P, R, F1):
            bert_scores.append({
                'bertscore_precision': round(p.item(), 4),
                'bertscore_recall': round(r.item(), 4),
                'bertscore_f1': round(f1.item(), 4)
            })
        
        return bert_scores
    
    def qualitative_assessment(self, prompt, reference, hypothesis, key_facts=None, domain_terms=None):
        """
        Perform qualitative assessment
        Returns ratings and analysis
        
        Note: In production, this would involve human evaluators.
        This function provides a framework for structured assessment.
        """
        assessment = {
            "coherence": None,  # 1-5: Logical flow
            "factuality": None,  # 1-5: Accuracy
            "relevance": None,  # 1-5: Addresses prompt
            "terminology": None,  # 1-5: Appropriate domain terms
            "notes": []
        }
        
        # Automated checks (to be supplemented with human judgment)
        hypothesis_lower = hypothesis.lower()
        
        # Check for key facts
        if key_facts:
            facts_found = sum(1 for fact in key_facts if fact.lower() in hypothesis_lower)
            fact_coverage = facts_found / len(key_facts) if key_facts else 0
            assessment["fact_coverage"] = round(fact_coverage, 2)
            
            if fact_coverage < 0.5:
                assessment["notes"].append("Missing critical key facts")
        
        # Check for domain terminology
        if domain_terms:
            terms_found = sum(1 for term in domain_terms if term.lower() in hypothesis_lower)
            term_coverage = terms_found / len(domain_terms) if domain_terms else 0
            assessment["term_coverage"] = round(term_coverage, 2)
            
            if term_coverage < 0.3:
                assessment["notes"].append("Insufficient domain-specific terminology")
        
        # Check for common hallucination patterns
        hallucination_indicators = [
            "according to studies",
            "research shows",
            "experts say",
            "it is proven that"
        ]
        if any(indicator in hypothesis_lower for indicator in hallucination_indicators):
            assessment["notes"].append("Possible unsupported claims - verify factuality")
        
        # Check length appropriateness
        ref_length = len(reference.split())
        hyp_length = len(hypothesis.split())
        length_ratio = hyp_length / ref_length if ref_length > 0 else 0
        
        if length_ratio < 0.3:
            assessment["notes"].append("Response too brief - may lack detail")
        elif length_ratio > 3.0:
            assessment["notes"].append("Response too verbose - may include unnecessary information")
        
        # Placeholder for human ratings (to be filled manually)
        assessment["human_ratings_required"] = {
            "coherence": "Rate 1-5: Does output flow logically?",
            "factuality": "Rate 1-5: Is information accurate?",
            "relevance": "Rate 1-5: Does it address the prompt?",
            "professionalism": "Rate 1-5: Is tone appropriate for domain?"
        }
        
        return assessment
    
    def evaluate_outputs(self, eval_dataset, outputs_by_strategy):
        """
        Evaluate outputs from different decoding strategies
        
        Args:
            eval_dataset: List of evaluation examples
            outputs_by_strategy: Dict mapping strategy names to list of outputs
        
        Returns:
            Comprehensive evaluation results
        """
        print("\n" + "="*100)
        print("RUNNING EVALUATION PIPELINE")
        print("="*100)
        
        results = {}
        
        for strategy_name, outputs in outputs_by_strategy.items():
            print(f"\nEvaluating strategy: {strategy_name}")
            print("-" * 80)
            
            strategy_results = []
            references = []
            hypotheses = []
            
            for idx, (example, output) in enumerate(zip(eval_dataset, outputs)):
                reference = example['reference']
                references.append(reference)
                hypotheses.append(output)
                
                # Calculate automated metrics
                bleu_scores = self.calculate_bleu(reference, output)
                rouge_scores = self.calculate_rouge(reference, output)
                
                # Qualitative assessment
                qualitative = self.qualitative_assessment(
                    prompt=example['prompt'],
                    reference=reference,
                    hypothesis=output,
                    key_facts=example.get('key_facts'),
                    domain_terms=example.get('domain_terms')
                )
                
                result = {
                    "example_id": idx + 1,
                    "prompt": example['prompt'],
                    "reference": reference,
                    "hypothesis": output,
                    "bleu": bleu_scores,
                    "rouge": rouge_scores,
                    "qualitative": qualitative
                }
                
                strategy_results.append(result)
                
                print(f"  Example {idx + 1}/{len(eval_dataset)} processed", end="\r")
            
            # Calculate BERTScore in batch
            bert_scores = self.calculate_bertscore(references, hypotheses)
            
            # Add BERTScore to results
            for result, bert_score in zip(strategy_results, bert_scores):
                result['bertscore'] = bert_score
            
            # Calculate aggregate metrics
            aggregate = self.calculate_aggregate_metrics(strategy_results)
            
            results[strategy_name] = {
                "detailed_results": strategy_results,
                "aggregate_metrics": aggregate
            }
            
            print(f"  Strategy {strategy_name} evaluated ✓")
        
        return results
    
    def calculate_aggregate_metrics(self, strategy_results):
        """
        Calculate aggregate metrics across all examples
        """
        aggregate = {
            "bleu_4_avg": np.mean([r['bleu']['bleu_4'] for r in strategy_results]),
            "rouge1_f_avg": np.mean([r['rouge']['rouge1_fmeasure'] for r in strategy_results]),
            "rouge2_f_avg": np.mean([r['rouge']['rouge2_fmeasure'] for r in strategy_results]),
            "rougeL_f_avg": np.mean([r['rouge']['rougeL_fmeasure'] for r in strategy_results]),
            "bertscore_f1_avg": np.mean([r['bertscore']['bertscore_f1'] for r in strategy_results]),
        }
        
        # Calculate qualitative metrics if available
        fact_coverages = [r['qualitative'].get('fact_coverage', 0) for r in strategy_results]
        term_coverages = [r['qualitative'].get('term_coverage', 0) for r in strategy_results]
        
        if fact_coverages:
            aggregate["avg_fact_coverage"] = np.mean(fact_coverages)
        if term_coverages:
            aggregate["avg_term_coverage"] = np.mean(term_coverages)
        
        # Round all values
        for key in aggregate:
            aggregate[key] = round(aggregate[key], 4)
        
        return aggregate
    
    def compare_strategies(self, evaluation_results):
        """
        Compare strategies and identify best performers
        """
        print("\n" + "="*100)
        print("STRATEGY COMPARISON")
        print("="*100)
        
        strategies = list(evaluation_results.keys())
        
        # Print aggregate metrics table
        print("\nAGGREGATE METRICS:")
        print("-" * 100)
        print(f"{'Strategy':<30} {'BLEU-4':>10} {'ROUGE-L':>10} {'BERTScore':>12} {'Fact Cov':>10} {'Term Cov':>10}")
        print("-" * 100)
        
        for strategy in strategies:
            agg = evaluation_results[strategy]['aggregate_metrics']
            print(f"{strategy:<30} "
                  f"{agg['bleu_4_avg']:>10.4f} "
                  f"{agg['rougeL_f_avg']:>10.4f} "
                  f"{agg['bertscore_f1_avg']:>12.4f} "
                  f"{agg.get('avg_fact_coverage', 0):>10.4f} "
                  f"{agg.get('avg_term_coverage', 0):>10.4f}")
        
        print("-" * 100)
        
        # Identify best performers
        print("\n\nBEST PERFORMERS BY METRIC:")
        print("-" * 100)
        
        metrics_to_check = {
            'BLEU-4': ('bleu_4_avg', True),
            'ROUGE-L F-measure': ('rougeL_f_avg', True),
            'BERTScore F1': ('bertscore_f1_avg', True),
            'Fact Coverage': ('avg_fact_coverage', True),
            'Term Coverage': ('avg_term_coverage', True)
        }
        
        for metric_name, (metric_key, higher_better) in metrics_to_check.items():
            scores = {s: evaluation_results[s]['aggregate_metrics'].get(metric_key, 0) 
                     for s in strategies}
            
            if higher_better:
                best_strategy = max(scores, key=scores.get)
            else:
                best_strategy = min(scores, key=scores.get)
            
            print(f"  {metric_name:<25}: {best_strategy:<30} (score: {scores[best_strategy]:.4f})")
        
        print()
    
    def analyze_metric_reliability(self, evaluation_results, strategy_name, example_indices=None):
        """
        Analyze cases where automated metrics may be misleading
        """
        print("\n" + "="*100)
        print(f"METRIC RELIABILITY ANALYSIS FOR: {strategy_name}")
        print("="*100)
        
        if strategy_name not in evaluation_results:
            print(f"Strategy '{strategy_name}' not found in results")
            return
        
        detailed_results = evaluation_results[strategy_name]['detailed_results']
        
        if example_indices is None:
            example_indices = range(len(detailed_results))
        
        print("\nExamining potential metric-quality mismatches...\n")
        
        for idx in example_indices:
            if idx >= len(detailed_results):
                continue
            
            result = detailed_results[idx]
            
            print(f"Example {result['example_id']}:")
            print(f"Prompt: {result['prompt'][:80]}...")
            print()
            print(f"Output: {result['hypothesis'][:150]}...")
            print()
            print(f"Metrics:")
            print(f"  BLEU-4: {result['bleu']['bleu_4']:.4f}")
            print(f"  ROUGE-L F1: {result['rouge']['rougeL_fmeasure']:.4f}")
            print(f"  BERTScore F1: {result['bertscore']['bertscore_f1']:.4f}")
            print()
            
            # Identify potential issues
            qual = result['qualitative']
            if qual['notes']:
                print(f"Quality Issues Detected:")
                for note in qual['notes']:
                    print(f"  ⚠ {note}")
            
            # Check for high metric but low quality indicators
            high_bleu = result['bleu']['bleu_4'] > 0.5
            high_rouge = result['rouge']['rougeL_fmeasure'] > 0.5
            low_fact_coverage = qual.get('fact_coverage', 1.0) < 0.5
            
            if (high_bleu or high_rouge) and low_fact_coverage:
                print(f"  ⚠ HIGH METRIC BUT LOW FACT COVERAGE - Possible false positive")
            
            # Check for low metric but potentially good output
            low_bleu = result['bleu']['bleu_4'] < 0.2
            high_bertscore = result['bertscore']['bertscore_f1'] > 0.85
            
            if low_bleu and high_bertscore:
                print(f"  LOW BLEU BUT HIGH BERTSCORE - May use different wording but convey same meaning")
            
            print("\n" + "-" * 100 + "\n")
    
    def create_blended_strategy(self):
        """
        Propose a blended evaluation strategy for production
        """
        print("\n" + "="*100)
        print("BLENDED EVALUATION STRATEGY FOR PRODUCTION")
        print("="*100)
        
        strategy = {
            "automated_metrics": {
                "primary": "BERTScore F1",
                "reason": "Better captures semantic similarity than n-gram overlap",
                "threshold": 0.85,
                "secondary": "ROUGE-L F-measure",
                "reason_secondary": "Good for measuring content coverage",
                "threshold_secondary": 0.50
            },
            "human_review_triggers": [
                "BERTScore F1 < 0.80 (potential quality issue)",
                "Fact coverage < 0.60 (missing critical information)",
                "Term coverage < 0.40 (insufficient domain terminology)",
                "Response length ratio outside 0.5-2.0 (too brief or verbose)",
                "Hallucination indicators detected"
            ],
            "sampling_strategy": {
                "automated_only": "80% of outputs (high-confidence cases)",
                "human_spot_check": "15% random sampling",
                "full_human_review": "5% (triggered by quality indicators)"
            },
            "domain_specific_checks": {
                "healthcare": [
                    "Medical terminology accuracy",
                    "Dosage information verification",
                    "Contraindication mentions",
                    "Appropriate disclaimers"
                ],
                "finance": [
                    "Numerical accuracy",
                    "Risk disclosures",
                    "Regulatory compliance",
                    "Citation of sources"
                ],
                "legal": [
                    "Jurisdiction specificity",
                    "Precedent citations",
                    "Disclaimer inclusion",
                    "Term precision"
                ]
            },
            "monitoring_in_production": {
                "real_time": [
                    "Average BERTScore (rolling 1-hour window)",
                    "Response time (latency)",
                    "Error rate"
                ],
                "daily": [
                    "Distribution of metric scores",
                    "Human review findings summary",
                    "User feedback aggregation"
                ],
                "weekly": [
                    "Trend analysis",
                    "A/B test results",
                    "Model drift detection"
                ]
            }
        }
        
        print(json.dumps(strategy, indent=2))
        print("\n" + "="*100)
        
        return strategy
    
    def save_results(self, evaluation_results, output_dir="results"):
        """
        Save evaluation results to file
        """
        os.makedirs(output_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{output_dir}/evaluation_results_{self.domain}_{timestamp}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump({
                "domain": self.domain,
                "timestamp": timestamp,
                "results": evaluation_results
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\nResults saved to: {filename}")
        return filename

def create_sample_evaluation_dataset(domain="healthcare"):
    """
    Create a sample evaluation dataset
    """
    datasets = {
        "healthcare": {
            "examples": [
                {
                    "prompt": "Explain Type 2 diabetes to a newly diagnosed patient",
                    "reference": "Type 2 diabetes is a chronic condition where your body doesn't use insulin properly, leading to high blood sugar. Managing it involves lifestyle changes like healthy eating, regular exercise, and often medication. You'll need to monitor your blood sugar regularly and work closely with your healthcare team.",
                    "key_facts": ["insulin resistance", "blood sugar management", "lifestyle changes", "monitoring"],
                    "domain_terms": ["insulin", "blood sugar", "glucose", "diabetes", "chronic condition"]
                },
                {
                    "prompt": "What are the early warning signs of a heart attack?",
                    "reference": "Early warning signs of a heart attack include chest discomfort or pain, pain in the arms, back, neck, jaw or stomach, shortness of breath, cold sweats, nausea, and lightheadedness. These symptoms can vary between individuals, and women may experience less typical symptoms. If you experience these signs, call emergency services immediately.",
                    "key_facts": ["chest pain", "shortness of breath", "call emergency services", "symptoms vary"],
                    "domain_terms": ["heart attack", "chest discomfort", "myocardial infarction", "cardiovascular", "emergency"]
                }
            ]
        },
        "finance": {
            "examples": [
                {
                    "prompt": "Explain compound interest to a beginner",
                    "reference": "Compound interest is interest calculated on both the initial principal and accumulated interest from previous periods. Unlike simple interest, your money grows faster because you earn interest on interest. For example, $1,000 at 5% annually becomes $1,050 after year one, then $1,102.50 after year two, and so on.",
                    "key_facts": ["interest on interest", "grows faster", "calculated on principal and accumulated interest"],
                    "domain_terms": ["compound interest", "principal", "interest rate", "accumulation", "growth"]
                }
            ]
        }
    }
    
    return datasets.get(domain, datasets["healthcare"])

def main():
    """
    Example usage of evaluation pipeline
    """
    print("="*100)
    print("EVALUATION PIPELINE DEMO")
    print("="*100)
    
    # Configuration
    DOMAIN = "healthcare"
    
    # Initialize pipeline
    pipeline = EvaluationPipeline(domain=DOMAIN)
    
    # Create or load evaluation dataset
    eval_dataset = create_sample_evaluation_dataset(DOMAIN)['examples']
    
    # Save dataset for future use
    os.makedirs("data", exist_ok=True)
    with open("data/evaluation_dataset.json", 'w') as f:
        json.dump({"examples": eval_dataset}, f, indent=2)
    print(f"\nSample evaluation dataset created: data/evaluation_dataset.json")
    
    # Example: Evaluate dummy outputs (replace with actual model outputs)
    outputs_by_strategy = {
        "greedy": [
            "Type 2 diabetes is when your body cannot use insulin correctly. You need to eat healthy and exercise.",
            "Heart attack symptoms include chest pain, shortness of breath, and arm pain. Call 911 immediately."
        ],
        "high_creativity": [
            "Type 2 diabetes, a metabolic disorder affecting millions worldwide, occurs when cells become resistant to insulin. Treatment involves comprehensive lifestyle modifications and pharmaceutical interventions.",
            "Cardiovascular emergencies like myocardial infarction present with various symptoms including thoracic discomfort, dyspnea, and radiating pain. Immediate emergency medical services are crucial."
        ]
    }
    
    # Run evaluation
    results = pipeline.evaluate_outputs(eval_dataset, outputs_by_strategy)
    
    # Compare strategies
    pipeline.compare_strategies(results)
    
    # Analyze specific examples
    pipeline.analyze_metric_reliability(results, "greedy", example_indices=[0])
    
    # Create blended strategy
    pipeline.create_blended_strategy()
    
    # Save results
    pipeline.save_results(results)
    
    print("\n" + "="*100)
    print("EVALUATION COMPLETE")
    print("="*100)

if __name__ == "__main__":
    main()
