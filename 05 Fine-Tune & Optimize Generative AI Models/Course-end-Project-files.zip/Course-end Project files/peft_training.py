"""
PEFT Training Script with LoRA
Course-end Project: Building and Optimizing a Domain-Specific Generative AI Assistant

This script implements parameter-efficient fine-tuning using LoRA (Low-Rank Adaptation)
to specialize a foundation model for domain-specific tasks.

Author: Student Name
Date: November 2025
"""

import os
import json
import time
import torch
from datetime import datetime
from pathlib import Path
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSeq2SeqLM,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    DataCollatorForLanguageModeling
)
from peft import (
    LoraConfig,
    get_peft_model,
    TaskType,
    PeftModel
)
import psutil
import GPUtil


class ResourceMonitor:
    """Monitor and track computational resources during training."""
    
    def __init__(self):
        self.start_time = None
        self.start_memory = None
        self.gpu_available = torch.cuda.is_available()
        
    def start_monitoring(self):
        """Begin monitoring resources."""
        self.start_time = time.time()
        
        if self.gpu_available:
            torch.cuda.reset_peak_memory_stats()
            self.start_memory = torch.cuda.memory_allocated() / (1024 ** 3)  # GB
            print(f"\n📊 GPU Memory at Start: {self.start_memory:.2f} GB")
        else:
            process = psutil.Process()
            self.start_memory = process.memory_info().rss / (1024 ** 3)  # GB
            print(f"\n📊 CPU Memory at Start: {self.start_memory:.2f} GB")
    
    def get_current_stats(self):
        """Get current resource usage statistics."""
        elapsed_time = time.time() - self.start_time
        
        if self.gpu_available:
            current_memory = torch.cuda.memory_allocated() / (1024 ** 3)
            peak_memory = torch.cuda.max_memory_allocated() / (1024 ** 3)
            
            return {
                "elapsed_time": elapsed_time,
                "current_memory_gb": current_memory,
                "peak_memory_gb": peak_memory,
                "memory_increase_gb": current_memory - self.start_memory
            }
        else:
            process = psutil.Process()
            current_memory = process.memory_info().rss / (1024 ** 3)
            
            return {
                "elapsed_time": elapsed_time,
                "current_memory_gb": current_memory,
                "memory_increase_gb": current_memory - self.start_memory
            }
    
    def print_summary(self, final_stats):
        """Print resource usage summary."""
        print("\n" + "="*70)
        print("📊 RESOURCE USAGE SUMMARY")
        print("="*70)
        print(f"Total Training Time: {final_stats['elapsed_time']/60:.2f} minutes")
        
        if self.gpu_available:
            print(f"Peak GPU Memory: {final_stats['peak_memory_gb']:.2f} GB")
            print(f"Memory Increase: {final_stats['memory_increase_gb']:.2f} GB")
        else:
            print(f"Peak CPU Memory: {final_stats['current_memory_gb']:.2f} GB")
            print(f"Memory Increase: {final_stats['memory_increase_gb']:.2f} GB")
        
        print("="*70 + "\n")


class PEFTTrainer:
    """
    Main class for PEFT training with LoRA.
    Handles model loading, LoRA configuration, training, and evaluation.
    """
    
    def __init__(
        self,
        model_name: str = "google/flan-t5-small",
        task_type: str = "SEQ_2_SEQ_LM",
        output_dir: str = "results/peft_model"
    ):
        """
        Initialize the PEFT trainer.
        
        Args:
            model_name: HuggingFace model identifier
            task_type: Type of task (SEQ_2_SEQ_LM or CAUSAL_LM)
            output_dir: Directory to save model checkpoints and results
        """
        self.model_name = model_name
        self.task_type = task_type
        self.output_dir = output_dir
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Create output directory
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.tokenizer = None
        self.model = None
        self.peft_model = None
        self.resource_monitor = ResourceMonitor()
        
        print(f"\n Initializing PEFT Trainer")
        print(f"Model: {model_name}")
        print(f"Task Type: {task_type}")
        print(f"Device: {self.device}")
        print(f"Output Directory: {output_dir}\n")
    
    def load_model_and_tokenizer(self):
        """Load the foundation model and tokenizer."""
        print(" Loading model and tokenizer...")
        
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        
        # Add padding token if needed
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load appropriate model based on task type
        if self.task_type == "SEQ_2_SEQ_LM":
            self.model = AutoModelForSeq2SeqLM.from_pretrained(
                self.model_name,
                device_map="auto" if torch.cuda.is_available() else None
            )
        else:  # CAUSAL_LM
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_name,
                device_map="auto" if torch.cuda.is_available() else None
            )
        
        # Print model parameter count
        total_params = sum(p.numel() for p in self.model.parameters())
        print(f" Model loaded successfully")
        print(f" Total Parameters: {total_params:,} ({total_params/1e6:.2f}M)\n")
        
        return total_params
    
    def configure_lora(
        self,
        r: int = 8,
        lora_alpha: int = 16,
        target_modules: list = None,
        lora_dropout: float = 0.1,
        bias: str = "none"
    ):
        """
        Configure LoRA parameters.
        
        Args:
            r: Rank of low-rank matrices (controls capacity)
            lora_alpha: Scaling factor for LoRA
            target_modules: Which modules to apply LoRA to
            lora_dropout: Dropout rate for regularization
            bias: Bias training strategy
        """
        print(" Configuring LoRA...")
        
        # Default target modules based on task type
        if target_modules is None:
            if self.task_type == "SEQ_2_SEQ_LM":
                target_modules = ["q", "v"]  # Query and Value projections
            else:
                target_modules = ["q_proj", "v_proj"]  # For GPT-style models
        
        # Create LoRA configuration
        if self.task_type == "SEQ_2_SEQ_LM":
            task_type_enum = TaskType.SEQ_2_SEQ_LM
        else:
            task_type_enum = TaskType.CAUSAL_LM
        
        lora_config = LoraConfig(
            r=r,
            lora_alpha=lora_alpha,
            target_modules=target_modules,
            lora_dropout=lora_dropout,
            bias=bias,
            task_type=task_type_enum
        )
        
        # Apply LoRA to the model
        self.peft_model = get_peft_model(self.model, lora_config)
        
        # Print trainable parameters
        trainable_params = sum(p.numel() for p in self.peft_model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.peft_model.parameters())
        trainable_percent = 100 * trainable_params / total_params
        
        print(f" LoRA configured successfully")
        print(f"\n PARAMETER EFFICIENCY:")
        print(f"   Total Parameters: {total_params:,} ({total_params/1e6:.2f}M)")
        print(f"   Trainable Parameters: {trainable_params:,} ({trainable_params/1e6:.2f}M)")
        print(f"   Trainable %: {trainable_percent:.4f}%")
        print(f"   Reduction: {100-trainable_percent:.2f}%\n")
        
        self.peft_model.print_trainable_parameters()
        print()
        
        return {
            "total_params": total_params,
            "trainable_params": trainable_params,
            "trainable_percent": trainable_percent
        }
    
    def prepare_dataset(self, train_file: str, eval_file: str, max_length: int = 512):
        """
        Load and prepare training and evaluation datasets.
        
        Args:
            train_file: Path to training data JSON file
            eval_file: Path to evaluation data JSON file
            max_length: Maximum sequence length
        """
        print(f" Loading datasets...")
        print(f"   Training data: {train_file}")
        print(f"   Evaluation data: {eval_file}")
        
        # Load JSON files
        with open(train_file, 'r') as f:
            train_data = json.load(f)
        
        with open(eval_file, 'r') as f:
            eval_data = json.load(f)
        
        print(f"   Training examples: {len(train_data)}")
        print(f"   Evaluation examples: {len(eval_data)}\n")
        
        # Convert to HuggingFace Dataset format
        train_dataset = Dataset.from_list(train_data)
        eval_dataset = Dataset.from_list(eval_data)
        
        # Tokenization function
        def preprocess_function(examples):
            # Format input with instruction
            if self.task_type == "SEQ_2_SEQ_LM":
                inputs = examples["instruction"]
                targets = examples["output"]
                
                model_inputs = self.tokenizer(
                    inputs,
                    max_length=max_length,
                    padding="max_length",
                    truncation=True
                )
                
                labels = self.tokenizer(
                    targets,
                    max_length=max_length,
                    padding="max_length",
                    truncation=True
                )
                
                model_inputs["labels"] = labels["input_ids"]
            else:  # CAUSAL_LM
                # Combine instruction and output for causal LM
                texts = [f"{inst} {out}" for inst, out in zip(examples["instruction"], examples["output"])]
                model_inputs = self.tokenizer(
                    texts,
                    max_length=max_length,
                    padding="max_length",
                    truncation=True
                )
                model_inputs["labels"] = model_inputs["input_ids"].copy()
            
            return model_inputs
        
        # Tokenize datasets
        print(" Tokenizing datasets...")
        tokenized_train = train_dataset.map(
            preprocess_function,
            batched=True,
            remove_columns=train_dataset.column_names
        )
        
        tokenized_eval = eval_dataset.map(
            preprocess_function,
            batched=True,
            remove_columns=eval_dataset.column_names
        )
        
        print(" Datasets prepared successfully\n")
        
        return tokenized_train, tokenized_eval
    
    def train(
        self,
        train_dataset,
        eval_dataset,
        num_epochs: int = 3,
        batch_size: int = 4,
        learning_rate: float = 3e-4,
        save_steps: int = 100,
        logging_steps: int = 10
    ):
        """
        Train the model with LoRA.
        
        Args:
            train_dataset: Tokenized training dataset
            eval_dataset: Tokenized evaluation dataset
            num_epochs: Number of training epochs
            batch_size: Training batch size
            learning_rate: Learning rate for optimization
            save_steps: Save checkpoint every N steps
            logging_steps: Log metrics every N steps
        """
        print("🏋️  Starting training...")
        print(f"   Epochs: {num_epochs}")
        print(f"   Batch Size: {batch_size}")
        print(f"   Learning Rate: {learning_rate}\n")
        
        # Start resource monitoring
        self.resource_monitor.start_monitoring()
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir=self.output_dir,
            num_train_epochs=num_epochs,
            per_device_train_batch_size=batch_size,
            per_device_eval_batch_size=batch_size,
            learning_rate=learning_rate,
            weight_decay=0.01,
            logging_dir=f"{self.output_dir}/logs",
            logging_steps=logging_steps,
            save_steps=save_steps,
            eval_strategy="epoch",
            save_strategy="epoch",
            load_best_model_at_end=True,
            metric_for_best_model="eval_loss",
            greater_is_better=False,
            report_to="none",  # Disable wandb, tensorboard
            fp16=torch.cuda.is_available(),  # Use mixed precision if GPU available
            gradient_accumulation_steps=2,
            warmup_steps=100,
            remove_unused_columns=False
        )
        
        # Data collator
        if self.task_type == "SEQ_2_SEQ_LM":
            data_collator = DataCollatorForSeq2Seq(
                self.tokenizer,
                model=self.peft_model,
                padding=True
            )
        else:
            data_collator = DataCollatorForLanguageModeling(
                self.tokenizer,
                mlm=False
            )
        
        # Create trainer
        trainer = Trainer(
            model=self.peft_model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=eval_dataset,
            data_collator=data_collator
        )
        
        # Train the model
        print(" Training in progress...\n")
        train_result = trainer.train()
        
        # Get resource statistics
        resource_stats = self.resource_monitor.get_current_stats()
        self.resource_monitor.print_summary(resource_stats)
        
        # Save the final model
        print(f"Saving model to {self.output_dir}")
        trainer.save_model()
        self.tokenizer.save_pretrained(self.output_dir)
        
        # Save training summary
        summary = {
            "model_name": self.model_name,
            "task_type": self.task_type,
            "training_completed": datetime.now().isoformat(),
            "num_epochs": num_epochs,
            "batch_size": batch_size,
            "learning_rate": learning_rate,
            "train_loss": train_result.training_loss,
            "resource_usage": resource_stats,
            "output_dir": self.output_dir
        }
        
        with open(f"{self.output_dir}/training_summary.json", 'w') as f:
            json.dump(summary, f, indent=2)
        
        print(f"\n Training completed successfully!")
        print(f" Final Training Loss: {train_result.training_loss:.4f}")
        print(f" Model saved to: {self.output_dir}\n")
        
        return trainer, train_result
    
    def evaluate_on_samples(self, test_prompts: list, max_length: int = 256):
        """
        Generate outputs for test prompts to evaluate quality.
        
        Args:
            test_prompts: List of test instructions
            max_length: Maximum generation length
        """
        print("\n Evaluating on test samples...")
        
        self.peft_model.eval()
        results = []
        
        for i, prompt in enumerate(test_prompts):
            print(f"\n--- Test {i+1}/{len(test_prompts)} ---")
            print(f"Input: {prompt}")
            
            # Tokenize input
            inputs = self.tokenizer(
                prompt,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=512
            ).to(self.device)
            
            # Generate output
            with torch.no_grad():
                outputs = self.peft_model.generate(
                    **inputs,
                    max_length=max_length,
                    num_beams=4,
                    temperature=0.7,
                    do_sample=True,
                    top_p=0.9
                )
            
            # Decode output
            generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
            print(f"Output: {generated_text}")
            
            results.append({
                "prompt": prompt,
                "generated": generated_text
            })
        
        # Save results
        with open(f"{self.output_dir}/sample_outputs.json", 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n Sample outputs saved to {self.output_dir}/sample_outputs.json")
        
        return results


def main():
    """
    Main training pipeline.
    Students should modify this section based on their domain and requirements.
    """
    
    # ============================================================
    # CONFIGURATION - MODIFY THESE SETTINGS
    # ============================================================
    
    # Model selection
    MODEL_NAME = "google/flan-t5-small"  # Options: flan-t5-small, flan-t5-base, gpt-neo-125M
    TASK_TYPE = "SEQ_2_SEQ_LM"  # Options: SEQ_2_SEQ_LM (for T5) or CAUSAL_LM (for GPT)
    
    # Data paths
    TRAIN_DATA = "data/train.json"
    EVAL_DATA = "data/eval.json"
    
    # LoRA configuration
    LORA_R = 8  # Rank (try 4, 8, 16)
    LORA_ALPHA = 16  # Alpha (typically 2*r)
    LORA_DROPOUT = 0.1
    TARGET_MODULES = ["q", "v"]  # For T5: ["q", "v"]; For GPT: ["q_proj", "v_proj"]
    
    # Training parameters
    NUM_EPOCHS = 3  # Number of training epochs
    BATCH_SIZE = 4  # Batch size (reduce if out of memory)
    LEARNING_RATE = 3e-4  # Learning rate
    MAX_LENGTH = 512  # Maximum sequence length
    
    # Output directory
    OUTPUT_DIR = "results/peft_model"
    
    # Test prompts for evaluation (customize for your domain)
    TEST_PROMPTS = [
        "Explain the concept of machine learning in simple terms.",
        "What are the benefits of using cloud computing?",
        "Describe the process of photosynthesis."
    ]
    
    # ============================================================
    # TRAINING PIPELINE
    # ============================================================
    
    print("\n" + "="*70)
    print(" PEFT TRAINING WITH LORA")
    print("="*70 + "\n")
    
    # Initialize trainer
    trainer = PEFTTrainer(
        model_name=MODEL_NAME,
        task_type=TASK_TYPE,
        output_dir=OUTPUT_DIR
    )
    
    # Load model and tokenizer
    total_params = trainer.load_model_and_tokenizer()
    
    # Configure LoRA
    param_stats = trainer.configure_lora(
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        target_modules=TARGET_MODULES,
        lora_dropout=LORA_DROPOUT
    )
    
    # Prepare datasets
    train_dataset, eval_dataset = trainer.prepare_dataset(
        train_file=TRAIN_DATA,
        eval_file=EVAL_DATA,
        max_length=MAX_LENGTH
    )
    
    # Train the model
    trained_model, train_result = trainer.train(
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        num_epochs=NUM_EPOCHS,
        batch_size=BATCH_SIZE,
        learning_rate=LEARNING_RATE
    )
    
    # Evaluate on test samples
    results = trainer.evaluate_on_samples(TEST_PROMPTS)
    
    # ============================================================
    # EFFICIENCY ANALYSIS
    # ============================================================
    
    print("\n" + "="*70)
    print(" EFFICIENCY ANALYSIS")
    print("="*70)
    
    # Calculate savings
    full_finetuning_params = total_params
    lora_trainable_params = param_stats["trainable_params"]
    param_reduction = 100 - param_stats["trainable_percent"]
    
    print(f"\n Parameter Efficiency:")
    print(f"   Full Fine-tuning: {full_finetuning_params:,} parameters")
    print(f"   LoRA Fine-tuning: {lora_trainable_params:,} parameters")
    print(f"   Reduction: {param_reduction:.2f}%")
    print(f"   Memory Saved: ~{param_reduction:.1f}% of full model size")
    
    # Estimate model size
    adapter_size_mb = (lora_trainable_params * 4) / (1024 ** 2)  # 4 bytes per float32
    full_model_size_mb = (total_params * 4) / (1024 ** 2)
    
    print(f"\n Storage Efficiency:")
    print(f"   Full Model Size: ~{full_model_size_mb:.1f} MB")
    print(f"   LoRA Adapter Size: ~{adapter_size_mb:.1f} MB")
    print(f"   Storage Saved: {full_model_size_mb - adapter_size_mb:.1f} MB")
    
    print("\n" + "="*70)
    print(" TRAINING COMPLETE!")
    print("="*70 + "\n")
    
    print(f" Results saved to: {OUTPUT_DIR}")
    print(f"   - Model checkpoint: {OUTPUT_DIR}/")
    print(f"   - Training summary: {OUTPUT_DIR}/training_summary.json")
    print(f"   - Sample outputs: {OUTPUT_DIR}/sample_outputs.json")
    print(f"   - Training logs: {OUTPUT_DIR}/logs/")
    
    print("\n💡 Next Steps:")
    print("   1. Review training logs and loss curves")
    print("   2. Test the model on more examples")
    print("   3. Compare performance with baseline model")
    print("   4. Run evaluation_pipeline.py for quantitative metrics")
    print("   5. Experiment with different LoRA configurations\n")


if __name__ == "__main__":
    main()
