"""
Evaluation Pipeline Lab - Starter Code
Module 2: Evaluating Generative AI Output Quality

This lab explores why strong automated metric scores don't always
translate to user satisfaction, and how to build hybrid evaluation
frameworks combining automated and human assessment.

Setup Instructions:
1. Ensure you have Python 3.8+ installed
2. Install required libraries: pip install evaluate datasets nltk bert-score pandas matplotlib
3. Run this script: python evaluation_pipeline_lab.py
4. Outputs will be saved to the outputs/ folder

Learning Objectives:
- Compute BLEU, ROUGE, and BERTScore metrics
- Identify gaps between metrics and actual quality
- Design hybrid evaluation frameworks
- Apply systematic evaluation to generative AI outputs
"""

import pandas as pd
import numpy as np
from evaluate import load
import nltk
from bert_score import score as bert_score
import warnings
import json
import os
from datetime import datetime

warnings.filterwarnings('ignore')

# Create outputs directory
os.makedirs('outputs', exist_ok=True)

print("="*70)
print("EVALUATION PIPELINE LAB")
print("Module 2: Evaluating Generative AI Output Quality")
print("="*70)
print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

# ============================================================================
# SETUP: Download NLTK data and load datasets
# ============================================================================

print("Setting up environment...")

# Download NLTK data
try:
    nltk.download('punkt', quiet=True)
    print(" NLTK data ready")
except:
    print(" NLTK download issue - continuing anyway")

# Load datasets
print("\nLoading datasets...")

try:
    source_df = pd.read_csv('source_articles.csv')
    reference_df = pd.read_csv('reference_summaries.csv')
    model_df = pd.read_csv('model_summaries.csv')
    
    print(f" Source articles loaded: {len(source_df)}")
    print(f" Reference summaries loaded: {len(reference_df)}")
    print(f" Model summaries loaded: {len(model_df)}")
    print(f" Model versions: {model_df['model_version'].unique()}")
    
except FileNotFoundError as e:
    print(f"ERROR: Could not find data files.")
    print(f"Please ensure the following files are in the current directory:")
    print("  - source_articles.csv")
    print("  - reference_summaries.csv")
    print("  - model_summaries.csv")
    exit(1)

print("\n Environment setup complete!\n")

# ============================================================================
# ACTIVITY 1: TRADITIONAL METRICS (BLEU, ROUGE)
# ============================================================================

print("="*70)
print("ACTIVITY 1: Computing Traditional Metrics")
print("="*70)
print("\nComputing BLEU and ROUGE scores for all model versions...")

# Load metrics
bleu_metric = load("bleu")
rouge_metric = load("rouge")

print(" Metrics loaded: BLEU, ROUGE\n")

def compute_traditional_metrics(references, predictions, model_name):
    """
    Compute BLEU and ROUGE scores.
    
    Args:
        references: list of reference summaries
        predictions: list of generated summaries
        model_name: name of the model version
    
    Returns:
        dict with metric scores
    """
    # BLEU requires tokenized inputs (list of lists for references)
    bleu_refs = [[ref.split()] for ref in references]
    bleu_preds = [pred.split() for pred in predictions]
    
    bleu_results = bleu_metric.compute(
        predictions=bleu_preds,
        references=bleu_refs
    )
    
    # ROUGE
    rouge_results = rouge_metric.compute(
        predictions=predictions,
        references=references
    )
    
    return {
        'model': model_name,
        'bleu': bleu_results['bleu'],
        'rouge1': rouge_results['rouge1'],
        'rouge2': rouge_results['rouge2'],
        'rougeL': rouge_results['rougeL']
    }

# ============================================================================
# Practice 1.1: Compute metrics for all model versions
# ============================================================================

print("-"*70)
print("PRACTICE 1.1: Computing Traditional Metrics for All Models")
print("-"*70)

results = []
for version in ['V1', 'V2', 'V3']:
    print(f"\nComputing metrics for Model {version}...")
    version_data = model_df[model_df['model_version'] == version]
    
    metrics = compute_traditional_metrics(
        reference_df['summary'].tolist(),
        version_data['summary'].tolist(),
        version
    )
    results.append(metrics)
    
    print(f"\n{version} Scores:")
    print(f"  BLEU:     {metrics['bleu']:.3f}")
    print(f"  ROUGE-1:  {metrics['rouge1']:.3f}")
    print(f"  ROUGE-2:  {metrics['rouge2']:.3f}")
    print(f"  ROUGE-L:  {metrics['rougeL']:.3f}")

# Save results
results_df = pd.DataFrame(results)
results_df.to_csv('outputs/traditional_metrics.csv', index=False)

print("\n Traditional metrics computed and saved to outputs/traditional_metrics.csv")

# Display comparison
print("\n" + "="*70)
print("TRADITIONAL METRICS COMPARISON")
print("="*70)
print("\n" + results_df.to_string(index=False))

# Identify best performer per metric
print("\n" + "-"*70)
print("HIGHEST SCORING MODEL PER METRIC:")
print("-"*70)
for col in ['bleu', 'rouge1', 'rouge2', 'rougeL']:
    best_model = results_df.loc[results_df[col].idxmax(), 'model']
    best_score = results_df[col].max()
    print(f"{col.upper():15} → {best_model} ({best_score:.3f})")

# ============================================================================
# Practice 1.2: Manual inspection of sample summaries
# ============================================================================

print("\n\n" + "="*70)
print("PRACTICE 1.2: Manual Inspection - Read and Judge Quality")
print("="*70)
print("\nNow let's read actual summaries and compare them to the metric scores.")
print("Does the highest-scoring model produce the best summaries?\n")

# Select first 3 articles for detailed inspection
for article_id in range(3):
    source_text = source_df.iloc[article_id]['article']
    reference = reference_df.iloc[article_id]['summary']
    
    print("\n" + "="*70)
    print(f"ARTICLE {article_id + 1}: {source_df.iloc[article_id]['title']}")
    print("="*70)
    
    print(f"\nSource Article (excerpt):")
    print(source_text[:400] + "...")
    
    print(f"\n{'Reference Summary:':20}")
    print(reference)
    
    print(f"\n{'Model Summaries:':20}")
    print("-"*70)
    
    for version in ['V1', 'V2', 'V3']:
        version_data = model_df[model_df['model_version'] == version]
        summary = version_data.iloc[article_id]['summary']
        
        print(f"\n{version}:")
        print(summary)
    
    print("\n" + "-"*70)
    print("YOUR TASK:")
    print("  1. Which summary sounds most natural to you?")
    print("  2. Which captures the key information best?")
    print("  3. Do any contain information NOT in the source?")
    print("  4. Does the highest BLEU model match your preference?")
    print("-"*70)
    
    # Pause for inspection (comment out if running automatically)
    # input("\nPress Enter to continue to next article...")

print("\n✓ Activity 1 complete! Review the summaries above before proceeding.\n")

# ============================================================================
# ACTIVITY 2: SEMANTIC METRICS (BERTScore)
# ============================================================================

print("\n" + "="*70)
print("ACTIVITY 2: Computing Semantic Metrics (BERTScore)")
print("="*70)
print("\nNow adding BERTScore to measure semantic similarity...")
print("This captures meaning-level similarity, not just word overlap.\n")

def compute_bertscore_batch(references, predictions, model_name):
    """
    Compute BERTScore for semantic similarity.
    
    Returns:
        dict with precision, recall, F1 scores
    """
    print(f"Computing BERTScore for {model_name}...")
    print("(This may take 1-2 minutes depending on your system)")
    
    P, R, F1 = bert_score(
        predictions,
        references,
        lang="en",
        verbose=False,
        device='cpu',  # Change to 'cuda' if GPU available
        batch_size=8
    )
    
    return {
        'model': model_name,
        'bertscore_precision': P.mean().item(),
        'bertscore_recall': R.mean().item(),
        'bertscore_f1': F1.mean().item()
    }

# ============================================================================
# Practice 2.1: Compute BERTScore for all models
# ============================================================================

print("-"*70)
print("PRACTICE 2.1: Computing BERTScore")
print("-"*70)

bert_results = []
for version in ['V1', 'V2', 'V3']:
    version_data = model_df[model_df['model_version'] == version]
    
    metrics = compute_bertscore_batch(
        reference_df['summary'].tolist(),
        version_data['summary'].tolist(),
        version
    )
    bert_results.append(metrics)
    
    print(f"\n{version} BERTScore:")
    print(f"  Precision: {metrics['bertscore_precision']:.3f}")
    print(f"  Recall:    {metrics['bertscore_recall']:.3f}")
    print(f"  F1:        {metrics['bertscore_f1']:.3f}")

# Merge with traditional metrics
bert_df = pd.DataFrame(bert_results)
combined_df = pd.merge(results_df, bert_df, on='model')
combined_df.to_csv('outputs/combined_metrics.csv', index=False)

print("\n BERTScore computed and combined with traditional metrics")
print(" Results saved to outputs/combined_metrics.csv")

# ============================================================================
# Practice 2.2: Compare all metrics side-by-side
# ============================================================================

print("\n" + "="*70)
print("PRACTICE 2.2: Complete Metric Comparison")
print("="*70)

print("\nALL METRICS COMPARISON:")
print("-"*70)
print(combined_df.to_string(index=False))

print("\n" + "-"*70)
print("HIGHEST SCORING MODEL PER METRIC:")
print("-"*70)

for col in ['bleu', 'rouge1', 'rougeL', 'bertscore_f1']:
    best_model = combined_df.loc[combined_df[col].idxmax(), 'model']
    best_score = combined_df[col].max()
    print(f"{col.upper():20} → {best_model} ({best_score:.3f})")

print("\n" + "-"*70)
print("KEY OBSERVATIONS:")
print("-"*70)
print("• Do all metrics agree on the best model?")
print("• Which metric rankings differ from each other?")
print("• Does BERTScore rank models differently than BLEU?")
print("-"*70)

# ============================================================================
# Practice 2.3: Identify metric-quality discrepancies
# ============================================================================

print("\n" + "="*70)
print("PRACTICE 2.3: Finding Metric-Quality Discrepancies")
print("="*70)
print("\nLet's examine cases where metrics disagree or don't match quality...")

# For each article, show all summaries with their average scores
print("\nDETAILED COMPARISON BY ARTICLE:")

for article_id in range(3):
    source = source_df.iloc[article_id]['article']
    reference = reference_df.iloc[article_id]['summary']
    
    print("\n" + "="*70)
    print(f"ARTICLE {article_id + 1}: {source_df.iloc[article_id]['title']}")
    print("="*70)
    
    print(f"\nSource (excerpt): {source[:200]}...")
    print(f"\nReference: {reference}")
    
    print("\n" + "-"*70)
    print("MODEL SUMMARIES:")
    print("-"*70)
    
    for version in ['V1', 'V2', 'V3']:
        version_data = model_df[model_df['model_version'] == version]
        summary = version_data.iloc[article_id]['summary']
        
        # Get metrics for this model
        model_metrics = combined_df[combined_df['model'] == version].iloc[0]
        
        print(f"\n{version} (BLEU:{model_metrics['bleu']:.2f} | "
              f"ROUGE-L:{model_metrics['rougeL']:.2f} | "
              f"BERTScore:{model_metrics['bertscore_f1']:.2f}):")
        print(summary)
    
    print("\n" + "-"*70)
    print("ANALYSIS QUESTIONS:")
    print("  • Which summary is highest quality to YOU?")
    print("  • Does it match the model with highest BLEU?")
    print("  • Does it match the model with highest BERTScore?")
    print("  • What quality issues do you see that metrics missed?")
    print("  • Any factual errors? Missing key info? Poor coherence?")
    print("-"*70)

print("\n✓ Activity 2 complete! Document any discrepancies you noticed.\n")

# ============================================================================
# ACTIVITY 3: METRIC FAILURE ANALYSIS & HYBRID FRAMEWORK
# ============================================================================

print("\n" + "="*70)
print("ACTIVITY 3: Identifying Metric Failures & Designing Hybrid Evaluation")
print("="*70)
print("\nNow let's systematically identify where metrics fail...")

# ============================================================================
# Practice 3.1: Create failure analysis template
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 3.1: Creating Failure Analysis Template")
print("-"*70)

failure_analysis = []

for article_id in range(len(source_df)):
    source = source_df.iloc[article_id]['article']
    reference = reference_df.iloc[article_id]['summary']
    
    for version in ['V1', 'V2', 'V3']:
        version_data = model_df[model_df['model_version'] == version]
        summary = version_data.iloc[article_id]['summary']
        
        # Get metrics for this specific summary
        model_metrics = combined_df[combined_df['model'] == version].iloc[0]
        
        # Template for manual assessment
        assessment = {
            'article_id': article_id + 1,
            'article_title': source_df.iloc[article_id]['title'],
            'model': version,
            'bleu': model_metrics['bleu'],
            'rougeL': model_metrics['rougeL'],
            'bertscore_f1': model_metrics['bertscore_f1'],
            'summary': summary,
            'reference': reference,
            # Manual assessment columns (fill these in)
            'has_factual_error': '',      # True/False
            'missing_key_info': '',        # True/False
            'poor_coherence': '',          # True/False
            'unnatural_language': '',      # True/False
            'overall_quality_rating': '',  # 1-5 scale
            'specific_issues': ''          # Your notes
        }
        
        failure_analysis.append(assessment)

# Save template
failure_df = pd.DataFrame(failure_analysis)
failure_df.to_csv('outputs/failure_analysis_template.csv', index=False)

print("\n Failure analysis template created")
print(" Saved to: outputs/failure_analysis_template.csv")
print("\nNEXT STEPS:")
print("  1. Open the CSV file")
print("  2. Read each summary carefully")
print("  3. Fill in the assessment columns:")
print("     - has_factual_error: True if summary contains false information")
print("     - missing_key_info: True if summary omits important details")
print("     - poor_coherence: True if summary doesn't flow logically")
print("     - unnatural_language: True if summary sounds robotic")
print("     - overall_quality_rating: Rate 1 (poor) to 5 (excellent)")
print("     - specific_issues: Note any other problems you notice")
print("  4. Save as 'failure_analysis_completed.csv'")

# ============================================================================
# Practice 3.2: Design hybrid evaluation framework
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 3.2: Designing Hybrid Evaluation Framework")
print("-"*70)

# Create a comprehensive hybrid framework
hybrid_framework = {
    'framework_name': 'Enterprise Summarization Evaluator v1.0',
    'version': '1.0',
    'created_date': datetime.now().isoformat(),
    
    'automated_metrics': {
        'bleu': {
            'weight': 0.10,
            'minimum_threshold': 0.30,
            'purpose': 'Basic word overlap check',
            'justification': 'Low weight because it misses synonyms and paraphrasing'
        },
        'rougeL': {
            'weight': 0.20,
            'minimum_threshold': 0.40,
            'purpose': 'Key information recall',
            'justification': 'Moderate weight - checks if important info is captured'
        },
        'bertscore_f1': {
            'weight': 0.30,
            'minimum_threshold': 0.75,
            'purpose': 'Semantic similarity',
            'justification': 'Highest automated weight - best captures meaning'
        }
    },
    
    'human_review_triggers': {
        'low_semantic_similarity': {
            'condition': 'bertscore_f1 < 0.75',
            'action': 'Flag for immediate human review',
            'priority': 'HIGH'
        },
        'length_mismatch': {
            'condition': 'summary_length > 2x OR < 0.5x reference_length',
            'action': 'Flag for review - potential over/under summarization',
            'priority': 'MEDIUM'
        },
        'low_composite_score': {
            'condition': 'composite_score < 0.65',
            'action': 'Require human approval before deployment',
            'priority': 'HIGH'
        },
        'random_sampling': {
            'condition': 'random 10% of all summaries',
            'action': 'Continuous calibration and drift detection',
            'priority': 'MEDIUM'
        }
    },
    
    'manual_review_checklist': [
        {
            'dimension': 'Factual Accuracy',
            'question': 'Does the summary contain only information present in source?',
            'weight': 0.40,
            'critical': True
        },
        {
            'dimension': 'Completeness',
            'question': 'Are all key points from the source captured?',
            'weight': 0.25,
            'critical': True
        },
        {
            'dimension': 'Coherence',
            'question': 'Does the summary flow logically without contradictions?',
            'weight': 0.20,
            'critical': False
        },
        {
            'dimension': 'Naturalness',
            'question': 'Does the language sound human-written and appropriate?',
            'weight': 0.15,
            'critical': False
        }
    ],
    
    'composite_score_calculation': {
        'formula': 'weighted_sum(automated_metrics) * 0.60 + human_score * 0.40',
        'automated_portion': 0.60,
        'human_portion': 0.40,
        'rationale': 'Balanced approach - automation for speed, human for critical judgment'
    },
    
    'deployment_gates': {
        'minimum_composite_score': 0.70,
        'zero_tolerance_issues': [
            'factual_errors',
            'hallucinated_information',
            'missing_critical_details'
        ],
        'approval_requirements': {
            'composite_score >= 0.80': 'Auto-approve',
            '0.70 <= composite_score < 0.80': 'Human approval required',
            'composite_score < 0.70': 'Reject - needs model improvement'
        }
    },
    
    'monitoring_and_logging': {
        'log_all_evaluations': True,
        'track_metrics_over_time': True,
        'alert_on_degradation': {
            'composite_drop': '> 5% decline over 1 week',
            'factuality_issues': '> 2% of summaries flagged'
        },
        'periodic_calibration': 'Monthly human review of random sample'
    }
}

# Save framework
with open('outputs/hybrid_framework.json', 'w') as f:
    json.dump(hybrid_framework, f, indent=2)

print("\n Hybrid Evaluation Framework designed and saved")
print(" Location: outputs/hybrid_framework.json")

print("\n" + "="*70)
print("YOUR HYBRID FRAMEWORK")
print("="*70)
print(json.dumps(hybrid_framework, indent=2))

# ============================================================================
# Practice 3.3: Apply framework to test summaries
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 3.3: Testing Hybrid Framework")
print("-"*70)

def evaluate_with_hybrid_framework(summary_data, framework):
    """
    Apply hybrid evaluation framework to a summary.
    
    Returns evaluation results with automated score and review flags.
    """
    # Compute automated score
    auto_metrics = framework['automated_metrics']
    auto_score = 0
    
    for metric, config in auto_metrics.items():
        if metric in summary_data:
            score = summary_data[metric]
            weight = config['weight']
            auto_score += score * weight
    
    # Normalize to 0-1 range (since weights sum to 0.60 for automated portion)
    auto_score_normalized = auto_score / 0.60
    
    # Check review triggers
    triggers = []
    
    if summary_data.get('bertscore_f1', 1.0) < 0.75:
        triggers.append('LOW_SEMANTIC_SIMILARITY')
    
    # Length check
    ref_len = len(summary_data.get('reference', '').split())
    sum_len = len(summary_data.get('summary', '').split())
    if ref_len > 0:
        if sum_len > 2 * ref_len:
            triggers.append('TOO_LONG')
        elif sum_len < 0.5 * ref_len:
            triggers.append('TOO_SHORT')
    
    if auto_score_normalized < 0.65:
        triggers.append('LOW_COMPOSITE_SCORE')
    
    # Determine status
    needs_review = len(triggers) > 0
    
    if auto_score_normalized >= 0.80 and not needs_review:
        status = 'APPROVED'
    elif auto_score_normalized >= 0.70:
        status = 'PENDING_HUMAN_REVIEW'
    else:
        status = 'REJECTED'
    
    return {
        'automated_score': auto_score_normalized,
        'triggers': triggers,
        'needs_human_review': needs_review,
        'status': status,
        'recommendation': 'Deploy' if status == 'APPROVED' else 
                         'Review Required' if status == 'PENDING_HUMAN_REVIEW' else 
                         'Do Not Deploy'
    }

print("\nApplying framework to all Model V1 summaries...")

test_results = []

for article_id in range(len(source_df)):
    # Get summary and metrics
    version_data = model_df[model_df['model_version'] == 'V1']
    summary = version_data.iloc[article_id]['summary']
    reference = reference_df.iloc[article_id]['summary']
    
    # Get metrics
    model_metrics = combined_df[combined_df['model'] == 'V1'].iloc[0]
    
    summary_data = {
        'article_id': article_id + 1,
        'model': 'V1',
        'bleu': model_metrics['bleu'],
        'rougeL': model_metrics['rougeL'],
        'bertscore_f1': model_metrics['bertscore_f1'],
        'reference': reference,
        'summary': summary
    }
    
    result = evaluate_with_hybrid_framework(summary_data, hybrid_framework)
    
    test_results.append({
        'article_id': article_id + 1,
        'model': 'V1',
        'automated_score': result['automated_score'],
        'status': result['status'],
        'triggers': ', '.join(result['triggers']) if result['triggers'] else 'None',
        'recommendation': result['recommendation']
    })
    
    if article_id < 3:  # Show details for first 3
        print(f"\nArticle {article_id + 1}:")
        print(f"  Automated Score: {result['automated_score']:.3f}")
        print(f"  Triggers: {result['triggers'] if result['triggers'] else 'None'}")
        print(f"  Status: {result['status']}")
        print(f"  Recommendation: {result['recommendation']}")

# Save test results
test_results_df = pd.DataFrame(test_results)
test_results_df.to_csv('outputs/framework_test_results.csv', index=False)

print("\n Framework testing complete")
print(f" Results saved to: outputs/framework_test_results.csv")

# Summary statistics
print("\n" + "="*70)
print("FRAMEWORK TEST SUMMARY")
print("="*70)
approved = sum(1 for r in test_results if r['status'] == 'APPROVED')
pending = sum(1 for r in test_results if r['status'] == 'PENDING_HUMAN_REVIEW')
rejected = sum(1 for r in test_results if r['status'] == 'REJECTED')
total = len(test_results)

print(f"\nTotal Summaries Evaluated: {total}")
print(f"  APPROVED (auto-deploy):   {approved} ({approved/total*100:.1f}%)")
print(f"  PENDING (needs review):   {pending} ({pending/total*100:.1f}%)")
print(f"  REJECTED (do not deploy): {rejected} ({rejected/total*100:.1f}%)")

print("\n" + "-"*70)
print("INTERPRETATION:")
print("-"*70)
if pending / total <= 0.20:
    print(" Good balance - human review load is manageable (~20% or less)")
elif pending / total <= 0.40:
    print(" Moderate - consider adjusting thresholds to reduce review load")
else:
    print(" Too many reviews - thresholds may be too strict")

# ============================================================================
# FINAL SUMMARY AND REFLECTION
# ============================================================================

print("\n\n" + "="*70)
print("LAB COMPLETE! 🎉")
print("="*70)

print("\nCongratulations! You've completed the Evaluation Breakdown Lab.")

print("\nWhat You've Accomplished:")
print("   Computed BLEU, ROUGE, and BERTScore for 3 model versions")
print("   Manually inspected summaries and compared to metric scores")
print("   Identified discrepancies between metrics and quality")
print("   Created failure analysis template for systematic review")
print("   Designed comprehensive hybrid evaluation framework")
print("   Tested framework on real summaries")

print("\nFiles Created:")
print("  • outputs/traditional_metrics.csv - BLEU and ROUGE scores")
print("  • outputs/combined_metrics.csv - All automated metrics")
print("  • outputs/failure_analysis_template.csv - Template for manual review")
print("  • outputs/hybrid_framework.json - Your evaluation framework")
print("  • outputs/framework_test_results.csv - Framework application results")

print("\nKey Insights to Remember:")
print("  1. High metric scores ≠ high quality")
print("  2. Different metrics capture different quality dimensions")
print("  3. Metrics miss critical issues like factuality and coherence")
print("  4. Hybrid evaluation combines automation speed + human judgment")
print("  5. Framework design requires balancing scalability and quality")

print("\nNext Steps for Deeper Learning:")
print("  • Complete the failure_analysis_template.csv with your assessments")
print("  • Compare your quality judgments to metric rankings")
print("  • Adjust hybrid framework weights based on your priorities")
print("  • Consider how framework would work at 1000x scale")

print(f"\nEnd time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("="*70)
print("\nThank you for completing this lab!")
print("="*70)
