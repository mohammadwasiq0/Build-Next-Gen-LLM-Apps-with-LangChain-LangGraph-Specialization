"""
Setup Verification Script for Module 2 Evaluation Pipeline Lab
Checks that all required components are installed and configured correctly
"""

import sys
import os

print("="*70)
print("EVALUATION PIPELINE LAB - SETUP VERIFICATION")
print("Module 2: Evaluating Generative AI Output Quality")
print("="*70)
print()

errors = []
warnings = []

# Check Python version
print("1. Checking Python version...")
if sys.version_info >= (3, 8):
    print(f"    Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
else:
    errors.append(f"   ✗ Python 3.8+ required (found {sys.version_info.major}.{sys.version_info.minor})")

# Check required packages
print("\n2. Checking required packages...")

required_packages = {
    'evaluate': 'Hugging Face Evaluate',
    'datasets': 'Hugging Face Datasets',
    'nltk': 'NLTK',
    'bert_score': 'BERTScore',
    'pandas': 'Pandas',
    'numpy': 'NumPy'
}

for package, name in required_packages.items():
    try:
        module = __import__(package)
        version = getattr(module, '__version__', 'unknown')
        print(f"    {name} (version {version})")
    except ImportError:
        errors.append(f"    {name} not installed")
        print(f"    {name} not installed - run: pip install {package}")

# Check for data files
print("\n3. Checking for data files...")

data_files = [
    'source_articles.csv',
    'reference_summaries.csv',
    'model_summaries.csv'
]

for filename in data_files:
    if os.path.exists(filename):
        try:
            import pandas as pd
            df = pd.read_csv(filename)
            print(f"    {filename} ({len(df)} records)")
        except Exception as e:
            warnings.append(f"    {filename} exists but couldn't be read: {e}")
    else:
        errors.append(f"    {filename} not found")
        print(f"    {filename} not found")

# Check outputs directory
print("\n4. Checking workspace structure...")

if not os.path.exists('outputs'):
    print("    Creating outputs/ directory...")
    try:
        os.makedirs('outputs')
        print("    outputs/ directory created")
    except:
        errors.append("   Could not create outputs/ directory")
else:
    print("   outputs/ directory exists")

# Check write permissions
try:
    test_file = 'outputs/.test_write'
    with open(test_file, 'w') as f:
        f.write('test')
    os.remove(test_file)
    print("    Write permissions OK")
except:
    errors.append("   No write permission to outputs/ directory")

# Check for lab files
print("\n5. Checking for lab files...")

lab_files = {
    'evaluation_pipeline_lab.py': 'required',
    'evaluation_pipeline_solution.py': 'optional'
}

for filename, status in lab_files.items():
    if os.path.exists(filename):
        print(f"   {filename} found")
    else:
        if status == 'required':
            errors.append(f"   {filename} not found (required)")
            print(f"   {filename} not found")
        else:
            warnings.append(f"   {filename} not found (optional)")

# Test NLTK data
print("\n6. Checking NLTK data...")

try:
    import nltk
    print("   Downloading NLTK punkt tokenizer...")
    nltk.download('punkt', quiet=True)
    print("   NLTK data ready")
except Exception as e:
    warnings.append(f"   NLTK setup issue: {e}")

# Summary
print("\n" + "="*70)
print("VERIFICATION SUMMARY")
print("="*70)

if errors:
    print("\n ERRORS FOUND:")
    for error in errors:
        print(error)
    print("\n" + "-"*70)
    print("REQUIRED FIXES:")
    print("-"*70)
    print("\n1. Install missing packages:")
    print("   pip install evaluate datasets nltk bert-score pandas numpy")
    print("\n2. Create missing data files:")
    print("   - source_articles.csv")
    print("   - reference_summaries.csv")
    print("   - model_summaries.csv")
    print("\n3. Ensure evaluation_pipeline_lab.py exists")
    print("\nPlease fix the errors above before running the lab.")
    print("="*70)
    sys.exit(1)
    
elif warnings:
    print("\n  WARNINGS:")
    for warning in warnings:
        print(warning)
    print("\n" + "-"*70)
    print("You can proceed with the lab, but be aware of the warnings above.")
    print("="*70)
    
else:
    print("\n ALL CHECKS PASSED!")
    print("\n" + "-"*70)
    print("Your environment is fully configured and ready for the lab.")
    print("-"*70)
    print("\nNext Steps:")
    print("  1. Run the lab: python evaluation_pipeline_lab.py")
    print("  2. The lab will compute metrics for 3 model versions")
    print("  3. Total runtime: approximately 5-10 minutes")
    print("  4. Outputs will be saved to the outputs/ folder")
    print("\nLab Objectives:")
    print("  • Understand what metrics actually measure")
    print("  • Identify where automated metrics fail")
    print("  • Design hybrid evaluation frameworks")
    print("\nHappy evaluating! 🎯")
    print("="*70)

# Additional system info
print("\n" + "="*70)
print("SYSTEM INFORMATION")
print("="*70)
print(f"Python: {sys.version}")
print(f"Platform: {sys.platform}")
print(f"Current directory: {os.getcwd()}")

try:
    import pandas
    print(f"Pandas: {pandas.__version__}")
except:
    pass

try:
    import evaluate
    print(f"Evaluate: {evaluate.__version__}")
except:
    pass

print("="*70)
