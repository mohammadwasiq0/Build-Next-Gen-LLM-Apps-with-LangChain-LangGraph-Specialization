"""
LLM Decoding Parameters Lab - Starter Code
Module 1: Understanding and Controlling Generative Model Outputs

This lab explores how temperature, top-k, and top-p parameters
affect LLM output quality across different use cases.

Setup Instructions:
1. Ensure you have Python 3.8+ installed
2. Install required libraries: pip install transformers torch pandas
3. Run this script: python decoding_parameters_lab.py
4. Outputs will be saved to the outputs/ folder

Learning Objectives:
- Configure temperature, top-k, and top-p parameters
- Compare parameter effects across use cases
- Select optimal configurations for different tasks
- Validate choices through systematic testing
"""

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import os
import pandas as pd
import json
from datetime import datetime

# Create outputs directory if it doesn't exist
os.makedirs('outputs', exist_ok=True)

print("="*70)
print("LLM DECODING PARAMETERS LAB")
print("="*70)
print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

# ============================================================================
# SETUP: Load Model and Prompts
# ============================================================================

print("Loading GPT-2 model and tokenizer...")
print("(First run will download ~500MB - this may take 5-10 minutes)")

model_name = "gpt2"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

# Fix padding token issue
tokenizer.pad_token = tokenizer.eos_token
model.config.pad_token_id = model.config.eos_token_id

# Move to appropriate device
if torch.backends.mps.is_available():
    device = torch.device("mps")  # Apple Silicon
    print(" Using Apple Metal (MPS)")
elif torch.cuda.is_available():
    device = torch.device("cuda")
    print(" Using CUDA GPU")
else:
    device = torch.device("cpu")
    print(" Using CPU")

model = model.to(device)
print(" Model loaded successfully!\n")

# Load prompts from files
print("Loading test prompts...")

try:
    with open('creative_prompts.txt', 'r') as f:
        creative_prompts = [line.strip() for line in f.readlines() if line.strip()]
    
    with open('technical_prompts.txt', 'r') as f:
        technical_prompts = [line.strip() for line in f.readlines() if line.strip()]
    
    with open('support_prompts.txt', 'r') as f:
        support_prompts = [line.strip() for line in f.readlines() if line.strip()]
    
    print(f" Loaded {len(creative_prompts)} creative prompts")
    print(f" Loaded {len(technical_prompts)} technical prompts")
    print(f" Loaded {len(support_prompts)} support prompts\n")
except FileNotFoundError as e:
    print(f"ERROR: Could not find prompt files. Please ensure the following files exist:")
    print("  - creative_prompts.txt")
    print("  - technical_prompts.txt")
    print("  - support_prompts.txt")
    exit(1)

# ============================================================================
# HELPER FUNCTION: Text Generation
# ============================================================================

def generate_text(prompt, temperature=0.7, top_k=0, top_p=1.0, max_length=150):
    """
    Generate text with specified decoding parameters.
    
    Args:
        prompt (str): Input text to continue
        temperature (float): Controls randomness (0.0 = deterministic, 2.0 = very random)
        top_k (int): Limits to top k tokens (0 = disabled)
        top_p (float): Nucleus sampling threshold (1.0 = disabled)
        max_length (int): Maximum tokens to generate
    
    Returns:
        str: Generated text
    """
    input_ids = tokenizer.encode(prompt, return_tensors="pt").to(device)
    
    output = model.generate(
        input_ids,
        max_length=max_length,
        min_length=50,
        temperature=temperature,
        top_k=top_k if top_k > 0 else None,
        top_p=top_p,
        do_sample=True,
        num_return_sequences=1,
        pad_token_id=tokenizer.eos_token_id,
        no_repeat_ngram_size=2,
        early_stopping=False
    )
    
    return tokenizer.decode(output[0], skip_special_tokens=True)


# ============================================================================
# ACTIVITY 1: TEMPERATURE EXPERIMENTS
# ============================================================================

print("="*70)
print("ACTIVITY 1: TEMPERATURE EXPERIMENTS")
print("="*70)
print("\nExploring how temperature affects output creativity and consistency")
print("Temperature range: 0.2 (deterministic) to 1.5 (highly creative)\n")

# Temperature values to test
temperatures = [0.2, 0.5, 0.7, 1.0, 1.5]

# ============================================================================
# Practice 1.1: Temperature sweep across all use cases
# ============================================================================

print("-"*70)
print("PRACTICE 1.1: Testing Temperature on All Use Cases")
print("-"*70)

# TEST 1: Creative Blog Introduction
print("\n" + "="*70)
print("USE CASE 1: Creative Blog Introduction")
print("="*70)

creative_prompt = creative_prompts[0]
print(f"Prompt: {creative_prompt}\n")

for temp in temperatures:
    print(f"\nGenerating with Temperature = {temp}...")
    output = generate_text(creative_prompt, temperature=temp)
    
    print(f"\n{'='*70}")
    print(f"Temperature: {temp}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/creative_temp_{temp}.txt', 'w') as f:
        f.write(f"Temperature: {temp}\n")
        f.write(f"Prompt: {creative_prompt}\n\n")
        f.write(output)

print("\n Creative blog experiments complete!")

# TEST 2: Technical Product Summary
print("\n" + "="*70)
print("USE CASE 2: Technical Product Summary")
print("="*70)

technical_prompt = technical_prompts[0]
print(f"Prompt: {technical_prompt}\n")

for temp in temperatures:
    print(f"\nGenerating with Temperature = {temp}...")
    output = generate_text(technical_prompt, temperature=temp)
    
    print(f"\n{'='*70}")
    print(f"Temperature: {temp}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/technical_temp_{temp}.txt', 'w') as f:
        f.write(f"Temperature: {temp}\n")
        f.write(f"Prompt: {technical_prompt}\n\n")
        f.write(output)

print("\n✓ Technical summary experiments complete!")

# TEST 3: Customer Support Response
print("\n" + "="*70)
print("USE CASE 3: Customer Support Response")
print("="*70)

support_prompt = support_prompts[0]
print(f"Prompt: {support_prompt}\n")

for temp in temperatures:
    print(f"\nGenerating with Temperature = {temp}...")
    output = generate_text(support_prompt, temperature=temp)
    
    print(f"\n{'='*70}")
    print(f"Temperature: {temp}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/support_temp_{temp}.txt', 'w') as f:
        f.write(f"Temperature: {temp}\n")
        f.write(f"Prompt: {support_prompt}\n\n")
        f.write(output)

print("\n✓ Customer support experiments complete!")

print("\n" + "="*70)
print("ACTIVITY 1 COMPLETE!")
print("="*70)
print("\nKey Observations to Note:")
print("  1. How does temperature affect creative content?")
print("  2. Which temperature keeps technical content accurate?")
print("  3. What temperature balances helpfulness in support responses?")
print("\nOutputs saved to: outputs/")
print("-"*70)


# ============================================================================
# ACTIVITY 2: VOCABULARY CONTROL (TOP-K AND TOP-P)
# ============================================================================

print("\n\n" + "="*70)
print("ACTIVITY 2: VOCABULARY CONTROL - TOP-K AND TOP-P")
print("="*70)
print("\nExploring how vocabulary filtering affects output quality")
print("Fixed temperature at 0.7 to isolate vocabulary control effects\n")

top_k_values = [10, 50, 100]
top_p_values = [0.5, 0.9, 0.95]
fixed_temperature = 0.7

# ============================================================================
# Practice 2.1: Top-K sampling experiments
# ============================================================================

print("-"*70)
print("PRACTICE 2.1: TOP-K SAMPLING")
print("-"*70)
print(f"Temperature fixed at: {fixed_temperature}")
print(f"Testing top-k values: {top_k_values}\n")

# Top-K on Creative Content
print("\n" + "="*70)
print("USE CASE 1: Creative Blog Introduction (Top-K)")
print("="*70)

creative_prompt = creative_prompts[1]
print(f"Prompt: {creative_prompt}\n")

for k in top_k_values:
    print(f"\nGenerating with Top-K = {k}...")
    output = generate_text(
        creative_prompt,
        temperature=fixed_temperature,
        top_k=k,
        top_p=1.0  # Disable top-p
    )
    
    print(f"\n{'='*70}")
    print(f"Top-K: {k}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/creative_topk_{k}.txt', 'w') as f:
        f.write(f"Top-K: {k}, Temperature: {fixed_temperature}\n")
        f.write(f"Prompt: {creative_prompt}\n\n")
        f.write(output)

# Top-K on Technical Content
print("\n" + "="*70)
print("USE CASE 2: Technical Product Summary (Top-K)")
print("="*70)

technical_prompt = technical_prompts[1]
print(f"Prompt: {technical_prompt}\n")

for k in top_k_values:
    print(f"\nGenerating with Top-K = {k}...")
    output = generate_text(
        technical_prompt,
        temperature=fixed_temperature,
        top_k=k,
        top_p=1.0
    )
    
    print(f"\n{'='*70}")
    print(f"Top-K: {k}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/technical_topk_{k}.txt', 'w') as f:
        f.write(f"Top-K: {k}, Temperature: {fixed_temperature}\n")
        f.write(f"Prompt: {technical_prompt}\n\n")
        f.write(output)

# Top-K on Support Content
print("\n" + "="*70)
print("USE CASE 3: Customer Support Response (Top-K)")
print("="*70)

support_prompt = support_prompts[1]
print(f"Prompt: {support_prompt}\n")

for k in top_k_values:
    print(f"\nGenerating with Top-K = {k}...")
    output = generate_text(
        support_prompt,
        temperature=fixed_temperature,
        top_k=k,
        top_p=1.0
    )
    
    print(f"\n{'='*70}")
    print(f"Top-K: {k}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/support_topk_{k}.txt', 'w') as f:
        f.write(f"Top-K: {k}, Temperature: {fixed_temperature}\n")
        f.write(f"Prompt: {support_prompt}\n\n")
        f.write(output)

print("\n Top-K experiments complete!")


# ============================================================================
# Practice 2.2: Top-P (Nucleus Sampling) experiments
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 2.2: TOP-P (NUCLEUS SAMPLING)")
print("-"*70)
print(f"Temperature fixed at: {fixed_temperature}")
print(f"Testing top-p values: {top_p_values}\n")

# Top-P on Creative Content
print("\n" + "="*70)
print("USE CASE 1: Creative Blog Introduction (Top-P)")
print("="*70)

creative_prompt = creative_prompts[2]
print(f"Prompt: {creative_prompt}\n")

for p in top_p_values:
    print(f"\nGenerating with Top-P = {p}...")
    output = generate_text(
        creative_prompt,
        temperature=fixed_temperature,
        top_k=0,  # Disable top-k
        top_p=p
    )
    
    print(f"\n{'='*70}")
    print(f"Top-P: {p}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/creative_topp_{p}.txt', 'w') as f:
        f.write(f"Top-P: {p}, Temperature: {fixed_temperature}\n")
        f.write(f"Prompt: {creative_prompt}\n\n")
        f.write(output)

# Top-P on Technical Content
print("\n" + "="*70)
print("USE CASE 2: Technical Product Summary (Top-P)")
print("="*70)

technical_prompt = technical_prompts[2]
print(f"Prompt: {technical_prompt}\n")

for p in top_p_values:
    print(f"\nGenerating with Top-P = {p}...")
    output = generate_text(
        technical_prompt,
        temperature=fixed_temperature,
        top_k=0,
        top_p=p
    )
    
    print(f"\n{'='*70}")
    print(f"Top-P: {p}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/technical_topp_{p}.txt', 'w') as f:
        f.write(f"Top-P: {p}, Temperature: {fixed_temperature}\n")
        f.write(f"Prompt: {technical_prompt}\n\n")
        f.write(output)

# Top-P on Support Content
print("\n" + "="*70)
print("USE CASE 3: Customer Support Response (Top-P)")
print("="*70)

support_prompt = support_prompts[2]
print(f"Prompt: {support_prompt}\n")

for p in top_p_values:
    print(f"\nGenerating with Top-P = {p}...")
    output = generate_text(
        support_prompt,
        temperature=fixed_temperature,
        top_k=0,
        top_p=p
    )
    
    print(f"\n{'='*70}")
    print(f"Top-P: {p}")
    print(f"{'='*70}")
    print(output)
    
    # Save output
    with open(f'outputs/support_topp_{p}.txt', 'w') as f:
        f.write(f"Top-P: {p}, Temperature: {fixed_temperature}\n")
        f.write(f"Prompt: {support_prompt}\n\n")
        f.write(output)

print("\n Top-P experiments complete!")


# ============================================================================
# Practice 2.3: Top-K vs Top-P Direct Comparison
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 2.3: TOP-K VS TOP-P DIRECT COMPARISON")
print("-"*70)

comparison_prompt = creative_prompts[3]
print(f"\nComparing methods on same prompt:")
print(f"Prompt: {comparison_prompt}\n")

# Generate with top-k=50
print("Generating with Top-K = 50...")
output_topk = generate_text(
    comparison_prompt,
    temperature=0.7,
    top_k=50,
    top_p=1.0
)

# Generate with top-p=0.9
print("Generating with Top-P = 0.9...")
output_topp = generate_text(
    comparison_prompt,
    temperature=0.7,
    top_k=0,
    top_p=0.9
)

print("\n" + "="*70)
print("METHOD 1: Top-K = 50")
print("="*70)
print(output_topk)

print("\n" + "="*70)
print("METHOD 2: Top-P = 0.9")
print("="*70)
print(output_topp)

# Save for comparison
with open('outputs/comparison_topk_50.txt', 'w') as f:
    f.write(f"Method: Top-K = 50, Temperature = 0.7\n")
    f.write(f"Prompt: {comparison_prompt}\n\n")
    f.write(output_topk)

with open('outputs/comparison_topp_0.9.txt', 'w') as f:
    f.write(f"Method: Top-P = 0.9, Temperature = 0.7\n")
    f.write(f"Prompt: {comparison_prompt}\n\n")
    f.write(output_topp)

print("\n Comparison files saved!")
print("   Tip: Use VS Code's 'Compare Selected' feature to examine differences")

print("\n" + "="*70)
print("ACTIVITY 2 COMPLETE!")
print("="*70)
print("\nKey Observations to Note:")
print("  1. How does top-k affect vocabulary richness?")
print("  2. Does top-p produce more natural outputs than top-k?")
print("  3. Which method works better for each use case?")
print("\nOutputs saved to: outputs/")
print("-"*70)


# ============================================================================
# ACTIVITY 3: OPTIMAL CONFIGURATIONS & A/B TESTING
# ============================================================================

print("\n\n" + "="*70)
print("ACTIVITY 3: OPTIMAL CONFIGURATIONS & A/B TESTING")
print("="*70)
print("\nBased on Activities 1 and 2, define and test optimal settings")
print("for each use case.\n")

# ============================================================================
# Practice 3.1: Define optimal configurations
# ============================================================================

print("-"*70)
print("PRACTICE 3.1: Defining Optimal Configurations")
print("-"*70)

# TODO: Adjust these values based on your observations from Activities 1 and 2!
optimal_configs = {
    'Creative Blog': {
        'temperature': 0.9,   # ADJUST THIS
        'top_p': 0.95,        # ADJUST THIS
        'top_k': 0,
        'max_length': 150,
        'reasoning': 'High creativity needed, wide vocabulary for engaging content'
    },
    'Technical Summary': {
        'temperature': 0.3,   # ADJUST THIS
        'top_p': 0.9,         # ADJUST THIS
        'top_k': 0,
        'max_length': 150,
        'reasoning': 'Accuracy critical, moderate vocabulary for professional tone'
    },
    'Customer Support': {
        'temperature': 0.7,   # ADJUST THIS
        'top_p': 0.85,        # ADJUST THIS
        'top_k': 0,
        'max_length': 150,
        'reasoning': 'Balance of helpfulness and natural conversation'
    }
}

print("\nYour Optimal Configurations:")
print("="*70)
for use_case, config in optimal_configs.items():
    print(f"\n{use_case}:")
    print(f"  Temperature: {config['temperature']}")
    print(f"  Top-P: {config['top_p']}")
    print(f"  Top-K: {'Disabled' if config['top_k'] == 0 else config['top_k']}")
    print(f"  Reasoning: {config['reasoning']}")


# ============================================================================
# Practice 3.2: A/B Testing - Validate on all prompts
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 3.2: A/B TESTING - Validating Configurations")
print("-"*70)
print("\nTesting each configuration across all 5 prompts...\n")

# Test Creative Blog Configuration
print("="*70)
print("TEST 1: Creative Blog Configuration")
print("="*70)

creative_config = optimal_configs['Creative Blog']
creative_results = []

for i, prompt in enumerate(creative_prompts):
    print(f"\nGenerating for prompt {i+1}/5...")
    output = generate_text(
        prompt,
        temperature=creative_config['temperature'],
        top_p=creative_config['top_p'],
        top_k=creative_config['top_k'],
        max_length=creative_config['max_length']
    )
    
    print(f"\nPrompt {i+1}: {prompt[:60]}...")
    print(f"Output preview: {output[:200]}...")
    
    creative_results.append({
        'prompt': prompt,
        'output': output,
        'length': len(output.split())
    })
    
    # Save result
    with open(f'outputs/final_creative_{i+1}.txt', 'w') as f:
        f.write(f"Configuration: {creative_config}\n")
        f.write(f"Prompt: {prompt}\n\n")
        f.write(output)

print("\n Creative blog testing complete!")

# Test Technical Summary Configuration
print("\n" + "="*70)
print("TEST 2: Technical Summary Configuration")
print("="*70)

technical_config = optimal_configs['Technical Summary']
technical_results = []

for i, prompt in enumerate(technical_prompts):
    print(f"\nGenerating for prompt {i+1}/5...")
    output = generate_text(
        prompt,
        temperature=technical_config['temperature'],
        top_p=technical_config['top_p'],
        top_k=technical_config['top_k'],
        max_length=technical_config['max_length']
    )
    
    print(f"\nPrompt {i+1}: {prompt[:60]}...")
    print(f"Output preview: {output[:200]}...")
    
    technical_results.append({
        'prompt': prompt,
        'output': output,
        'length': len(output.split())
    })
    
    # Save result
    with open(f'outputs/final_technical_{i+1}.txt', 'w') as f:
        f.write(f"Configuration: {technical_config}\n")
        f.write(f"Prompt: {prompt}\n\n")
        f.write(output)

print("\n Technical summary testing complete!")

# Test Customer Support Configuration
print("\n" + "="*70)
print("TEST 3: Customer Support Configuration")
print("="*70)

support_config = optimal_configs['Customer Support']
support_results = []

for i, prompt in enumerate(support_prompts):
    print(f"\nGenerating for prompt {i+1}/5...")
    output = generate_text(
        prompt,
        temperature=support_config['temperature'],
        top_p=support_config['top_p'],
        top_k=support_config['top_k'],
        max_length=support_config['max_length']
    )
    
    print(f"\nPrompt {i+1}: {prompt[:60]}...")
    print(f"Output preview: {output[:200]}...")
    
    support_results.append({
        'prompt': prompt,
        'output': output,
        'length': len(output.split())
    })
    
    # Save result
    with open(f'outputs/final_support_{i+1}.txt', 'w') as f:
        f.write(f"Configuration: {support_config}\n")
        f.write(f"Prompt: {prompt}\n\n")
        f.write(output)

print("\n Customer support testing complete!")


# ============================================================================
# Practice 3.3: Comprehensive Analysis
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 3.3: Comprehensive Analysis")
print("-"*70)

# Create comparison table
comparison_data = []
for use_case, config in optimal_configs.items():
    comparison_data.append({
        'Use Case': use_case,
        'Temperature': config['temperature'],
        'Top-P': config['top_p'],
        'Top-K': 'Disabled' if config['top_k'] == 0 else config['top_k'],
        'Primary Goal': 'Engaging' if 'Creative' in use_case else 
                       'Accurate' if 'Technical' in use_case else 'Helpful',
        'Reasoning': config['reasoning'][:50] + '...'
    })

df = pd.DataFrame(comparison_data)
print("\n" + "="*70)
print("FINAL PARAMETER CONFIGURATIONS")
print("="*70)
print("\n" + df.to_string(index=False))

# Save configuration summary
df.to_csv('outputs/final_configurations.csv', index=False)
print("\n Configuration table saved to: outputs/final_configurations.csv")

# Calculate and display statistics
print("\n" + "="*70)
print("OUTPUT STATISTICS")
print("="*70)

print(f"\nCreative Blog:")
creative_lengths = [r['length'] for r in creative_results]
print(f"  Average length: {sum(creative_lengths) / len(creative_lengths):.1f} words")
print(f"  Range: {min(creative_lengths)} - {max(creative_lengths)} words")
print(f"  Total outputs: {len(creative_results)}")

print(f"\nTechnical Summary:")
technical_lengths = [r['length'] for r in technical_results]
print(f"  Average length: {sum(technical_lengths) / len(technical_lengths):.1f} words")
print(f"  Range: {min(technical_lengths)} - {max(technical_lengths)} words")
print(f"  Total outputs: {len(technical_results)}")

print(f"\nCustomer Support:")
support_lengths = [r['length'] for r in support_results]
print(f"  Average length: {sum(support_lengths) / len(support_lengths):.1f} words")
print(f"  Range: {min(support_lengths)} - {max(support_lengths)} words")
print(f"  Total outputs: {len(support_results)}")

# Save detailed results as JSON
detailed_results = {
    'configurations': optimal_configs,
    'creative_results': creative_results,
    'technical_results': technical_results,
    'support_results': support_results,
    'statistics': {
        'creative': {
            'avg_length': sum(creative_lengths) / len(creative_lengths),
            'min_length': min(creative_lengths),
            'max_length': max(creative_lengths)
        },
        'technical': {
            'avg_length': sum(technical_lengths) / len(technical_lengths),
            'min_length': min(technical_lengths),
            'max_length': max(technical_lengths)
        },
        'support': {
            'avg_length': sum(support_lengths) / len(support_lengths),
            'min_length': min(support_lengths),
            'max_length': max(support_lengths)
        }
    }
}

with open('outputs/detailed_results.json', 'w') as f:
    json.dump(detailed_results, f, indent=2)

print("\n Detailed results saved to: outputs/detailed_results.json")


# ============================================================================
# Practice 3.4: Reflection
# ============================================================================

print("\n" + "-"*70)
print("PRACTICE 3.4: Lab Reflection")
print("-"*70)

reflection_template = f"""
================================================================================
LLM DECODING PARAMETERS LAB - KEY LEARNINGS & REFLECTION
================================================================================
Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

1. TEMPERATURE IMPACT
-------------------
Creative Content:
  - Optimal range: {optimal_configs['Creative Blog']['temperature']}
  - Observation: [What did you notice about temperature's effect?]

Technical Content:
  - Optimal range: {optimal_configs['Technical Summary']['temperature']}
  - Observation: [How did low temperature affect accuracy?]

Customer Support:
  - Optimal range: {optimal_configs['Customer Support']['temperature']}
  - Observation: [What balance did you find?]

Key Insight: [Your biggest learning about temperature control]


2. TOP-K VS TOP-P COMPARISON
--------------------------
Preferred Method: [top-k or top-p?]
Reasoning: [Why did you prefer this method?]

When to use Top-K: [Your answer]
When to use Top-P: [Your answer]


3. PARAMETER INTERACTIONS
-----------------------
How do temperature and top-p work together?
[Your observation about their interaction]

Which parameter had the biggest impact on output quality?
[temperature, top-k, or top-p - and why?]


4. PRODUCTION RECOMMENDATIONS
---------------------------
For Creative Content:
  Recommended: temp={optimal_configs['Creative Blog']['temperature']}, top_p={optimal_configs['Creative Blog']['top_p']}
  Reasoning: {optimal_configs['Creative Blog']['reasoning']}

For Technical Content:
  Recommended: temp={optimal_configs['Technical Summary']['temperature']}, top_p={optimal_configs['Technical Summary']['top_p']}
  Reasoning: {optimal_configs['Technical Summary']['reasoning']}

For Customer Support:
  Recommended: temp={optimal_configs['Customer Support']['temperature']}, top_p={optimal_configs['Customer Support']['top_p']}
  Reasoning: {optimal_configs['Customer Support']['reasoning']}


5. BIGGEST SURPRISES
------------------
What surprised you most during experimentation?
[Your answer]

Any unexpected behaviors or results?
[Your answer]


6. ADVICE FOR TEAMS
-----------------
What would you tell a team deploying these models?
[Your recommendations]

Most important lesson learned?
[Your key takeaway]


7. NEXT STEPS
-----------
How would you apply these learnings to your own projects?
[Your thoughts]

What additional experiments would you run?
[Your ideas]

================================================================================
"""

print(reflection_template)

# Save reflection template
with open('outputs/lab_reflections.txt', 'w') as f:
    f.write(reflection_template)

print("\n Reflection template saved to: outputs/lab_reflections.txt")
print("  (Edit this file to add your personal observations)")


# ============================================================================
# LAB SUMMARY
# ============================================================================

print("\n\n" + "="*70)
print("LAB COMPLETE! 🎉")
print("="*70)

total_outputs = len(creative_results) + len(technical_results) + len(support_results)
print(f"\nCongratulations! You've completed the LLM Decoding Parameters Lab.")
print(f"\nExperiments Run:")
print(f"   Temperature sweep: 15 outputs (5 temps × 3 use cases)")
print(f"   Top-K experiments: 9 outputs (3 values × 3 use cases)")
print(f"   Top-P experiments: 9 outputs (3 values × 3 use cases)")
print(f"   Direct comparison: 2 outputs (top-k vs top-p)")
print(f"   Final validation: {total_outputs} outputs (5 prompts × 3 use cases)")
print(f"\nTotal outputs generated: {15 + 9 + 9 + 2 + total_outputs}")

print(f"\nFiles Created:")
print(f"   Output text files: Check outputs/ folder")
print(f"   Configuration summary: final_configurations.csv")
print(f"   Detailed results: detailed_results.json")
print(f"   Reflection template: lab_reflections.txt")

print(f"\nNext Steps:")
print(f"  1. Review all outputs in the outputs/ folder")
print(f"  2. Complete the reflection in lab_reflections.txt")
print(f"  3. Compare your configs with the reference solution")
print(f"  4. Consider how to apply these learnings to your projects")

print("\nKey Takeaways:")
print("  • Temperature is your primary creativity control")
print("  • Top-p (nucleus sampling) usually produces more natural outputs")
print("  • Different use cases require different parameter profiles")
print("  • Systematic testing beats trial-and-error")

print(f"\nEnd time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
print("="*70)
print("\nThank you for completing this lab! 🚀")
print("="*70)