"""
Setup Verification Script for LLM Decoding Parameters Lab
Checks that all required components are installed and configured correctly

Run this before starting the lab:
    python verify_setup.py
"""

import sys
import os

print("="*70)
print("LLM DECODING PARAMETERS LAB - SETUP VERIFICATION")
print("="*70)
print()

errors = []
warnings = []

# ============================================================================
# 1. Check Python Version
# ============================================================================
print("1. Checking Python version...")
if sys.version_info >= (3, 8):
    print(f"    Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
else:
    error_msg = f"   ✗ Python 3.8+ required (found {sys.version_info.major}.{sys.version_info.minor})"
    errors.append(error_msg)
    print(error_msg)

# ============================================================================
# 2. Check Required Packages
# ============================================================================
print("\n2. Checking required packages...")

required_packages = {
    'torch': 'PyTorch',
    'transformers': 'Hugging Face Transformers',
    'pandas': 'Pandas'
}

for package, name in required_packages.items():
    try:
        module = __import__(package)
        # Get version if available
        version = getattr(module, '__version__', 'unknown')
        print(f"    {name} (version {version})")
    except ImportError:
        error_msg = f"    {name} not installed"
        errors.append(error_msg)
        print(f"{error_msg}")
        print(f"      Install with: pip install {package}")

# ============================================================================
# 3. Check for Prompt Files
# ============================================================================
print("\n3. Checking for prompt files...")

prompt_files = [
    'creative_prompts.txt',
    'technical_prompts.txt',
    'support_prompts.txt'
]

for filename in prompt_files:
    if os.path.exists(filename):
        try:
            with open(filename, 'r') as f:
                lines = [line.strip() for line in f.readlines() if line.strip()]
                if len(lines) >= 5:
                    print(f"    {filename} ({len(lines)} prompts)")
                else:
                    warning_msg = f"    {filename} has only {len(lines)} prompts (expected 5)"
                    warnings.append(warning_msg)
                    print(warning_msg)
        except Exception as e:
            error_msg = f"    Error reading {filename}: {e}"
            errors.append(error_msg)
            print(error_msg)
    else:
        error_msg = f"    {filename} not found"
        errors.append(error_msg)
        print(error_msg)
        print(f"      Create this file with 5 prompts (one per line)")

# ============================================================================
# 4. Check PyTorch Device Availability
# ============================================================================
print("\n4. Checking compute devices...")

try:
    import torch
    
    if torch.backends.mps.is_available():
        print("    Apple Metal (MPS) available - GPU acceleration enabled")
    elif torch.cuda.is_available():
        cuda_device = torch.cuda.get_device_name(0)
        print(f"    CUDA available - GPU: {cuda_device}")
    else:
        print("    CPU available")
        warning_msg = "    No GPU detected - processing will be slower (but still works)"
        warnings.append(warning_msg)
        print(warning_msg)
        
    # Test basic tensor operation
    try:
        test_tensor = torch.tensor([1.0, 2.0, 3.0])
        print("    PyTorch tensor operations working")
    except Exception as e:
        error_msg = f"    PyTorch tensor test failed: {e}"
        errors.append(error_msg)
        print(error_msg)
        
except ImportError:
    error_msg = "    PyTorch not available - cannot check device"
    errors.append(error_msg)
    print(error_msg)
except Exception as e:
    warning_msg = f"    Could not fully check device availability: {e}"
    warnings.append(warning_msg)
    print(warning_msg)

# ============================================================================
# 5. Check Workspace Structure
# ============================================================================
print("\n5. Checking workspace structure...")

# Check if outputs directory exists or can be created
if not os.path.exists('outputs'):
    print("    Creating outputs/ directory...")
    try:
        os.makedirs('outputs')
        print("    outputs/ directory created")
    except Exception as e:
        error_msg = f"    Could not create outputs/ directory: {e}"
        errors.append(error_msg)
        print(error_msg)
else:
    print("    outputs/ directory exists")

# Check write permissions
try:
    test_file = 'outputs/.test_write'
    with open(test_file, 'w') as f:
        f.write('test')
    os.remove(test_file)
    print("    Write permissions OK")
except Exception as e:
    error_msg = f"    No write permission to outputs/ directory: {e}"
    errors.append(error_msg)
    print(error_msg)

# Check for lab files
lab_files = {
    'decoding_parameters_lab.py': 'required',
    'decoding_parameters_solution.py': 'optional'
}

for filename, status in lab_files.items():
    if os.path.exists(filename):
        print(f"    {filename} found")
    else:
        if status == 'required':
            error_msg = f"    {filename} not found (required)"
            errors.append(error_msg)
            print(error_msg)
        else:
            warning_msg = f"    {filename} not found (optional)"
            warnings.append(warning_msg)
            print(warning_msg)

# ============================================================================
# 6. Check Transformers Model Access
# ============================================================================
print("\n6. Checking model access...")

try:
    from transformers import AutoTokenizer
    print("   ✓ Can import Transformers library")
    
    # Check if we can access Hugging Face
    print("    Testing Hugging Face Hub connection...")
    try:
        # This will check connection without downloading
        tokenizer = AutoTokenizer.from_pretrained("gpt2", use_fast=False)
        print("    Can access Hugging Face Hub")
        print("    GPT-2 tokenizer accessible")
    except Exception as e:
        warning_msg = f"    Could not verify Hugging Face access: {e}"
        warnings.append(warning_msg)
        print(warning_msg)
        print("      Note: Model will download on first lab run (~500MB)")
        
except ImportError:
    error_msg = "    Cannot import Transformers - check installation"
    errors.append(error_msg)
    print(error_msg)

# ============================================================================
# Summary
# ============================================================================
print("\n" + "="*70)
print("VERIFICATION SUMMARY")
print("="*70)

if errors:
    print("\n ERRORS FOUND:")
    for error in errors:
        print(error)
    print("\n" + "-"*70)
    print("REQUIRED FIXES:")
    print("-"*70)
    print("\n1. Install missing packages:")
    print("   pip install transformers torch pandas")
    print("\n2. Create missing prompt files:")
    print("   - creative_prompts.txt")
    print("   - technical_prompts.txt")
    print("   - support_prompts.txt")
    print("\n3. Ensure decoding_parameters_lab.py exists in this directory")
    print("\nPlease fix the errors above before running the lab.")
    print("="*70)
    sys.exit(1)
    
elif warnings:
    print("\n WARNINGS:")
    for warning in warnings:
        print(warning)
    print("\n" + "-"*70)
    print("You can proceed with the lab, but be aware of the warnings above.")
    print("="*70)
    
else:
    print("\n ALL CHECKS PASSED!")
    print("\n" + "-"*70)
    print("Your environment is fully configured and ready for the lab.")
    print("-"*70)
    print("\n Next Steps:")
    print("  1. Run the lab: python decoding_parameters_lab.py")
    print("  2. The first run will download GPT-2 model (~500MB)")
    print("  3. Total runtime: 15-20 minutes first run, 10-15 minutes after")
    print("  4. Outputs will be saved to the outputs/ folder")
    print("\nHappy experimenting!")
    print("="*70)

# ============================================================================
# Additional System Info (for debugging)
# ============================================================================
print("\n" + "="*70)
print("SYSTEM INFORMATION (for reference)")
print("="*70)
print(f"Python: {sys.version}")
print(f"Platform: {sys.platform}")
print(f"Current directory: {os.getcwd()}")

try:
    import torch
    print(f"PyTorch: {torch.__version__}")
    if torch.cuda.is_available():
        print(f"CUDA: {torch.version.cuda}")
    if torch.backends.mps.is_available():
        print(f"MPS (Metal): Available")
except:
    pass

try:
    import transformers
    print(f"Transformers: {transformers.__version__}")
except:
    pass

try:
    import pandas
    print(f"Pandas: {pandas.__version__}")
except:
    pass

print("="*70)
