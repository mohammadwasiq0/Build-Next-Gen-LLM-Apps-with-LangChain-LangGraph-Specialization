"""
Module 3 Lab: Parameter-Efficient Fine-Tuning for Domain Adaptation
The Domain Adaptation Dilemma

This lab guides you through fine-tuning Llama-2 7B for medical domain adaptation
using LoRA (Low-Rank Adaptation). You'll configure LoRA parameters, train on
medical dialogues, evaluate performance, and make production deployment decisions.

Student: Complete the TODO sections marked as ACTIVITY 1 through ACTIVITY 5

Setup Instructions:
1. Ensure you have Python 3.8+ installed
2. Install required libraries: pip install transformers peft datasets evaluate torch accelerate bitsandbytes
3. Run verification: python verify_setup_module3.py
4. Complete activities in order
5. Reference solution if needed: module3_lab_solution.py

Learning Objectives:
- Configure LoRA parameters for parameter-efficient fine-tuning
- Fine-tune large language models with 90%+ reduced memory footprint
- Compare LoRA performance against full fine-tuning
- Analyze computational trade-offs
- Make production deployment decisions
"""

import torch
import json
import numpy as np
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from peft import LoraConfig, get_peft_model, PeftModel
from datasets import Dataset
import evaluate
from tqdm import tqdm
import warnings
import os
from datetime import datetime

warnings.filterwarnings('ignore')

# Check if CUDA is available
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using device: {device}")

# Create outputs directory
os.makedirs('outputs', exist_ok=True)

print("="*70)
print("MODULE 3 LAB: THE DOMAIN ADAPTATION DILEMMA")
print("Parameter-Efficient Fine-Tuning with LoRA")
print("="*70)
print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

# ============================================================================
# SETUP: Load Base Model and Tokenizer
# ============================================================================

def load_base_model(model_name="gpt2"):
    """
    Load the base language model and tokenizer.
    For this lab, we use GPT-2 as a demonstration model since it's freely accessible.
    In production, you would use: "meta-llama/Llama-2-7b-hf"
    (requires accepting license at https://huggingface.co/meta-llama)
    """
    print(f"\nLoading base model: {model_name}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16 if device == "cuda" else torch.float32,
        device_map="auto" if device == "cuda" else None
    )
    
    # Fix padding token (required for training)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        model.config.pad_token_id = model.config.eos_token_id
    
    print(f" Model loaded successfully!")
    print(f"  Model size: {sum(p.numel() for p in model.parameters()):,} parameters")
    
    return model, tokenizer

# ============================================================================
# ACTIVITY 1: Configure LoRA Parameters
# ============================================================================

def configure_lora(model):
    """
    TODO: Configure LoRA parameters for parameter-efficient fine-tuning.
    
    Your task:
    1. Create a LoraConfig with the following parameters:
       - r (rank): 8
       - lora_alpha: 16
       - lora_dropout: 0.05
       - target_modules: ["c_attn"] for GPT-2, or ["q_proj", "v_proj"] for Llama-2
       - bias: "none"
       - task_type: "CAUSAL_LM"
    
    2. Apply LoRA to the model using get_peft_model()
    
    3. Print trainable parameters using model.print_trainable_parameters()
    
    Expected output: ~0.3-0.6% trainable parameters for GPT-2, ~0.06% for Llama-2
    """
    print("\n" + "="*70)
    print("ACTIVITY 1: Configure LoRA Parameters")
    print("="*70)
    
    # TODO: Create LoraConfig
    # lora_config = LoraConfig(
    #     r=...,
    #     lora_alpha=...,
    #     lora_dropout=...,
    #     target_modules=...,
    #     bias=...,
    #     task_type=...
    # )
    
    # TODO: Apply LoRA to model
    # model = get_peft_model(model, lora_config)
    
    # TODO: Print trainable parameters
    # model.print_trainable_parameters()
    
    print("\n  ACTIVITY 1 NOT IMPLEMENTED - Complete the TODO above!")
    print("Hint: Check the lab instructions for the exact parameter values.")
    print("Expected: Trainable parameters should be less than 1% of total parameters")
    
    return model  # This will fail until you implement the TODO

# ============================================================================
# DATA LOADING: Medical Dialogue Dataset
# ============================================================================

def load_medical_dataset(file_path):
    """
    Load medical dialogue dataset from JSONL file.
    Each line contains: {"conversation": "...", "response": "...", "specialty": "..."}
    """
    print(f"\nLoading dataset from: {file_path}")
    data = []
    
    try:
        with open(file_path, 'r') as f:
            for line in f:
                data.append(json.loads(line))
    except FileNotFoundError:
        print(f" Warning: {file_path} not found. Using dummy data for demo.")
        # Create dummy data if files not available
        data = [
            {
                "conversation": "Patient: I have a severe headache that won't go away.",
                "response": "Let me ask about your symptoms. Is the headache throbbing or constant? Does it affect one side or both?",
                "specialty": "neurology"
            }
        ] * 10
    
    dataset = Dataset.from_list(data)
    print(f" Loaded {len(dataset)} examples")
    if len(dataset) > 0:
        print(f"  Example: {dataset[0]}")
    
    return dataset

def preprocess_function(examples, tokenizer, max_length=512):
    """
    Preprocess medical dialogues into input format for training.
    Format: "Patient: [conversation]\nDoctor: [response]"
    """
    # Create instruction-response format
    texts = []
    for conv, resp in zip(examples['conversation'], examples['response']):
        text = f"{conv}\nDoctor: {resp}"
        texts.append(text)
    
    # Tokenize
    tokenized = tokenizer(
        texts,
        truncation=True,
        max_length=max_length,
        padding="max_length",
        return_tensors="pt"
    )
    
    # For causal LM, labels are the same as input_ids
    tokenized["labels"] = tokenized["input_ids"].clone()
    
    return tokenized

# ============================================================================
# ACTIVITY 2: Fine-Tune with LoRA on Medical Data
# ============================================================================

def train_lora_model(model, tokenizer, train_dataset, output_dir="./outputs/lora_medical_checkpoint"):
    """
    TODO: Configure training arguments and train the LoRA model.
    
    Your task:
    1. Set up TrainingArguments with:
       - output_dir: "./outputs/lora_medical_checkpoint"
       - num_train_epochs: 3
       - per_device_train_batch_size: 4 (reduce to 2 or 1 if OOM)
       - learning_rate: 2e-4
       - fp16: True (if CUDA available)
       - logging_steps: 50
       - save_strategy: "epoch"
       - save_total_limit: 2
       - report_to: "none"
    
    2. Preprocess the training dataset
    
    3. Create a Trainer and run training
    
    4. Save the final LoRA adapter
    
    Expected: Training should take 1-3 hours depending on GPU and dataset size
    """
    print("\n" + "="*70)
    print("ACTIVITY 2: Fine-Tune with LoRA")
    print("="*70)
    
    # Preprocess dataset
    print("\nPreprocessing training data...")
    train_dataset = train_dataset.map(
        lambda x: preprocess_function(x, tokenizer),
        batched=True,
        remove_columns=train_dataset.column_names
    )
    print(f" Preprocessed {len(train_dataset)} training examples")
    
    # TODO: Configure training arguments
    # training_args = TrainingArguments(
    #     output_dir=...,
    #     num_train_epochs=...,
    #     per_device_train_batch_size=...,
    #     learning_rate=...,
    #     fp16=...,
    #     logging_steps=...,
    #     save_strategy=...,
    #     save_total_limit=...,
    #     report_to=...
    # )
    
    # TODO: Create data collator
    # data_collator = DataCollatorForLanguageModeling(
    #     tokenizer=tokenizer,
    #     mlm=False
    # )
    
    # TODO: Create Trainer
    # trainer = Trainer(
    #     model=model,
    #     args=training_args,
    #     train_dataset=train_dataset,
    #     data_collator=data_collator
    # )
    
    # TODO: Start training
    # print("\n Starting LoRA fine-tuning...")
    # print("  This will take 1-3 hours. Monitor GPU usage with: nvidia-smi")
    # trainer.train()
    
    # TODO: Save final adapter
    # model.save_pretrained("./outputs/lora_medical_final")
    # tokenizer.save_pretrained("./outputs/lora_medical_final")
    # print("\n Training complete! LoRA adapter saved to ./outputs/lora_medical_final")
    
    print("\n ACTIVITY 2 NOT IMPLEMENTED - Complete the TODO above!")
    print("Hint: Refer to the Hugging Face Trainer documentation and lab instructions.")
    
    return model

# ============================================================================
# ACTIVITY 3: Evaluate LoRA Performance vs Full Fine-Tuning
# ============================================================================

def evaluate_model(model, tokenizer, test_dataset, baseline_path="baseline_results.json"):
    """
    TODO: Evaluate the LoRA model and compare against full fine-tuning baseline.
    
    Your task:
    1. Load baseline results from JSON file
    2. Compute perplexity on test set
    3. Generate responses for test examples
    4. Calculate ROUGE scores
    5. Create comparison table
    
    Expected: LoRA achieves 90-95% of full fine-tuning performance
    """
    print("\n" + "="*70)
    print("ACTIVITY 3: Evaluate Performance")
    print("="*70)
    
    # Load baseline results
    print("\nLoading baseline results...")
    try:
        with open(baseline_path, 'r') as f:
            baseline = json.load(f)
        print(f" Baseline perplexity: {baseline['evaluation_metrics']['perplexity']}")
        print(f" Baseline ROUGE-L: {baseline['evaluation_metrics']['rouge_l']}")
    except FileNotFoundError:
        print(f"  {baseline_path} not found. Using default values.")
        baseline = {
            "evaluation_metrics": {"perplexity": 12.3, "rouge_l": 0.68},
            "training_metrics": {"training_time_hours": 18.3, "gpu_memory_gb": 72, "cost_estimate_usd": 576}
        }
    
    # TODO: Compute perplexity for LoRA model
    # Hint: Use model.eval() and compute loss on test set
    # perplexity = ...
    
    # TODO: Generate responses and calculate ROUGE scores
    # rouge = evaluate.load("rouge")
    # predictions = []
    # references = []
    # 
    # for example in test_dataset.select(range(10)):  # Sample 10 examples
    #     # Generate response
    #     # Calculate metrics
    #     pass
    # 
    # rouge_scores = rouge.compute(predictions=predictions, references=references)
    
    # TODO: Create comparison table
    # print("\n" + "="*70)
    # print("PERFORMANCE COMPARISON: LoRA vs Full Fine-Tuning")
    # print("="*70)
    # print(f"{'Metric':<20} {'LoRA':<15} {'Full Fine-Tuning':<20}")
    # print("-"*70)
    # print(f"{'Perplexity':<20} {perplexity:<15.2f} {baseline['evaluation_metrics']['perplexity']:<20.2f}")
    # print(f"{'ROUGE-L':<20} {rouge_scores['rougeL']:<15.3f} {baseline['evaluation_metrics']['rouge_l']:<20.3f}")
    # print(f"{'Training Time (hrs)':<20} {'2.5':<15} {baseline['training_metrics']['training_time_hours']:<20.1f}")
    # print(f"{'GPU Memory (GB)':<20} {'38':<15} {baseline['training_metrics']['gpu_memory_gb']:<20}")
    # print(f"{'Cost (USD)':<20} {'$80':<15} {'$' + str(baseline['training_metrics']['cost_estimate_usd']):<20}")
    # print("="*70)
    
    print("\n ACTIVITY 3 NOT IMPLEMENTED - Complete the TODO above!")
    print("Hint: Use the evaluate library and model.generate() for predictions.")

# ============================================================================
# ACTIVITY 4: Experiment with LoRA Hyperparameters
# ============================================================================

def experiment_with_ranks(base_model, tokenizer, train_dataset):
    """
    TODO: Test different LoRA rank configurations to understand trade-offs.
    
    Your task:
    1. Try three configurations:
       - Config A: r=4 (minimal)
       - Config B: r=8 (balanced - your baseline)
       - Config C: r=16 (maximum)
    
    2. For each configuration:
       - Count trainable parameters
       - Train for 1 epoch (to save time)
       - Measure validation perplexity
       - Record GPU memory usage
       - Track training time
    
    3. Create a comparison showing the performance-efficiency trade-off
    
    Expected: Diminishing returns after r=8 for this dataset
    """
    print("\n" + "="*70)
    print("ACTIVITY 4: Experiment with LoRA Hyperparameters")
    print("="*70)
    
    configs = [
        {"name": "Config A - Minimal", "r": 4, "target_modules": ["c_attn"]},
        {"name": "Config B - Balanced", "r": 8, "target_modules": ["c_attn"]},
        {"name": "Config C - Maximum", "r": 16, "target_modules": ["c_attn", "c_proj"]},
    ]
    
    results = []
    
    # TODO: For each configuration:
    # 1. Create LoraConfig
    # 2. Apply to fresh copy of base model
    # 3. Train for 1 epoch
    # 4. Evaluate perplexity
    # 5. Record metrics
    
    # for config in configs:
    #     print(f"\n Testing {config['name']}...")
    #     # Your code here
    #     pass
    
    # TODO: Print comparison table
    # print("\n" + "="*70)
    # print("HYPERPARAMETER COMPARISON")
    # print("="*70)
    # print(f"{'Config':<20} {'Rank':<10} {'Trainable %':<15} {'Perplexity':<15} {'Time (min)':<15}")
    # print("-"*70)
    # for result in results:
    #     print(f"{result['name']:<20} {result['rank']:<10} {result['trainable_pct']:<15.3f} {result['perplexity']:<15.2f} {result['time']:<15.1f}")
    # print("="*70)
    
    print("\n ACTIVITY 4 NOT IMPLEMENTED - Complete the TODO above!")
    print("Hint: Copy the base model for each experiment to avoid interference.")

# ============================================================================
# ACTIVITY 5: Production Deployment Decision
# ============================================================================

def make_deployment_recommendation():
    """
    TODO: Analyze all results and make a data-driven deployment recommendation.
    
    Your task:
    1. Review all metrics collected in Activities 1-4
    
    2. Consider the decision factors:
       - Performance requirements (Is 94% sufficient?)
       - Budget constraints ($2,000 limit)
       - Iteration velocity (importance of rapid experimentation)
       - Deployment logistics (serving multiple models?)
       - Maintenance overhead (retraining frequency?)
    
    3. Write a recommendation (5-8 sentences) addressing:
       - Which approach to deploy (LoRA, full fine-tuning, or hybrid)
       - Quantitative evidence supporting decision
       - Risks and mitigation strategies
       - Next steps for production
    
    4. Answer reflection questions
    """
    print("\n" + "="*70)
    print("ACTIVITY 5: Production Deployment Decision")
    print("="*70)
    
    print("\n Decision Framework:")
    print("-" * 70)
    print("✓ Performance Requirements: Is 94% of full fine-tuning sufficient?")
    print("✓ Budget Constraints: $2,000 available vs $576+ for full fine-tuning")
    print("✓ Iteration Velocity: How important is rapid experimentation?")
    print("✓ Deployment Logistics: Need to serve multiple adapted models?")
    print("✓ Maintenance: How often will model be retrained?")
    print("-" * 70)
    
    # TODO: Write your recommendation
    recommendation = """
    TODO: Replace this with your 5-8 sentence recommendation.
    
    Example structure:
    - Opening: State your recommended approach
    - Evidence: Cite specific metrics from your experiments
    - Trade-offs: Acknowledge performance gaps and explain why acceptable/unacceptable
    - Risks: Identify key risks (e.g., medical accuracy, hallucinations)
    - Mitigation: Propose strategies to address risks
    - Next steps: Outline immediate actions for deployment
    """
    
    print("\n DEPLOYMENT RECOMMENDATION:")
    print("="*70)
    print(recommendation)
    print("="*70)
    
    # TODO: Answer reflection questions
    print("\n REFLECTION QUESTIONS:")
    print("-" * 70)
    print("\n1. Would your recommendation change with 10x more training data?")
    print("   YOUR ANSWER: [Write your answer here]")
    print()
    print("2. How would FDA approval requirements affect this decision?")
    print("   YOUR ANSWER: [Write your answer here]")
    print()
    print("3. When should you revisit and potentially switch to full fine-tuning?")
    print("   YOUR ANSWER: [Write your answer here]")
    print("="*70)
    
    print("\n  ACTIVITY 5 NOT IMPLEMENTED - Complete the recommendation above!")

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Main execution flow for the lab.
    Students should uncomment activities as they complete them.
    """
    print("\n" + "="*70)
    print("LAB INSTRUCTIONS")
    print("="*70)
    print("1. Complete activities in order (1 → 2 → 3 → 4 → 5)")
    print("2. Uncomment each section as you complete the previous one")
    print("3. Test your code frequently to catch errors early")
    print("4. Refer to lab documentation for detailed guidance")
    print("5. Use the solution file if you get stuck")
    print("="*70)
    
    # Load base model
    print("\n🔧 Loading base model...")
    model, tokenizer = load_base_model()
    
    # ACTIVITY 1: Configure LoRA
    print("\n Complete ACTIVITY 1 first")
    # Uncomment when ready:
    # model = configure_lora(model)
    
    # Load datasets
    # train_dataset = load_medical_dataset("medical_train.jsonl")
    # validation_dataset = load_medical_dataset("medical_validation.jsonl")
    # test_dataset = load_medical_dataset("medical_test.jsonl")
    
    # ACTIVITY 2: Fine-tune with LoRA
    # Uncomment when Activity 1 is complete:
    # model = train_lora_model(model, tokenizer, train_dataset)
    
    # ACTIVITY 3: Evaluate performance
    # Uncomment when Activity 2 is complete:
    # evaluate_model(model, tokenizer, test_dataset)
    
    # ACTIVITY 4: Experiment with hyperparameters
    # Uncomment when Activity 3 is complete:
    # experiment_with_ranks(model, tokenizer, train_dataset)
    
    # ACTIVITY 5: Make deployment recommendation
    # Uncomment when Activity 4 is complete:
    # make_deployment_recommendation()
    
    print("\n" + "="*70)
    print(" Ready to start! Begin with ACTIVITY 1.")
    print("="*70)
    print(f"End time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()
