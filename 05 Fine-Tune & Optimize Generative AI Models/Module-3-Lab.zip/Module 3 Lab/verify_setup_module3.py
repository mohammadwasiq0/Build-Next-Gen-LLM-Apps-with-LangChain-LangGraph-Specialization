"""
Setup Verification Script for Module 3 LoRA Fine-Tuning Lab
Checks that all required components are installed and configured correctly
"""

import sys
import os

print("="*70)
print("LORA FINE-TUNING LAB - SETUP VERIFICATION")
print("Module 3: Parameter-Efficient Fine-Tuning for Domain Adaptation")
print("="*70)
print()

errors = []
warnings = []

# Check Python version
print("1. Checking Python version...")
if sys.version_info >= (3, 8):
    print(f"    Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
else:
    errors.append(f"    Python 3.8+ required (found {sys.version_info.major}.{sys.version_info.minor})")

# Check required packages
print("\n2. Checking required packages...")

required_packages = {
    'transformers': 'Hugging Face Transformers',
    'peft': 'Parameter-Efficient Fine-Tuning (PEFT)',
    'datasets': 'Hugging Face Datasets',
    'evaluate': 'Hugging Face Evaluate',
    'torch': 'PyTorch',
    'accelerate': 'Hugging Face Accelerate',
    'bitsandbytes': 'BitsAndBytes (for quantization)',
}

for package, name in required_packages.items():
    try:
        module = __import__(package)
        version = getattr(module, '__version__', 'unknown')
        print(f"    {name} (version {version})")
    except ImportError:
        if package == 'bitsandbytes':
            warnings.append(f"     {name} not installed (optional for CPU, required for efficient GPU training)")
            print(f"     {name} not installed - optional but recommended")
        else:
            errors.append(f"    {name} not installed")
            print(f"    {name} not installed - run: pip install {package}")

# Check for GPU availability
print("\n3. Checking GPU availability...")

try:
    import torch
    if torch.cuda.is_available():
        gpu_count = torch.cuda.device_count()
        gpu_name = torch.cuda.get_device_name(0)
        print(f"    CUDA available")
        print(f"    GPU count: {gpu_count}")
        print(f"    GPU 0: {gpu_name}")
        
        # Check CUDA version
        cuda_version = torch.version.cuda
        print(f"    CUDA version: {cuda_version}")
    else:
        warnings.append("     No GPU detected - training will be slower on CPU")
        print("     No GPU detected - lab will run on CPU (slower)")
        print("    GPU highly recommended for this lab")
except Exception as e:
    warnings.append(f"    Could not check GPU: {e}")

# Check for data files
print("\n4. Checking for data files...")

data_files = [
    'medical_train.jsonl',
    'medical_validation.jsonl',
    'medical_test.jsonl',
    'baseline_results.json'
]

for filename in data_files:
    if os.path.exists(filename):
        try:
            import json
            with open(filename, 'r') as f:
                if filename.endswith('.jsonl'):
                    line_count = sum(1 for line in f)
                    print(f"    {filename} ({line_count} records)")
                else:
                    data = json.load(f)
                    print(f"    {filename}")
        except Exception as e:
            warnings.append(f"     {filename} exists but couldn't be read: {e}")
    else:
        if filename == 'baseline_results.json':
            warnings.append(f"     {filename} not found (will use default values)")
            print(f"     {filename} not found (will use defaults)")
        else:
            warnings.append(f"     {filename} not found (will use dummy data)")
            print(f"     {filename} not found (lab will generate dummy data)")

# Check outputs directory
print("\n5. Checking workspace structure...")

if not os.path.exists('outputs'):
    print("   Creating outputs/ directory...")
    try:
        os.makedirs('outputs')
        print("    outputs/ directory created")
    except:
        errors.append("    Could not create outputs/ directory")
else:
    print("    outputs/ directory exists")

# Check write permissions
try:
    test_file = 'outputs/.test_write'
    with open(test_file, 'w') as f:
        f.write('test')
    os.remove(test_file)
    print("    Write permissions OK")
except:
    errors.append("    No write permission to outputs/ directory")

# Check for lab files
print("\n6. Checking for lab files...")

lab_files = {
    'module3_lab_starter.py': 'required',
    'module3_lab_solution.py': 'optional'
}

for filename, status in lab_files.items():
    if os.path.exists(filename):
        print(f"    {filename} found")
    else:
        if status == 'required':
            errors.append(f"    {filename} not found (required)")
            print(f"    {filename} not found")
        else:
            warnings.append(f"     {filename} not found (optional)")

# Check model access (optional)
print("\n7. Checking model access...")

try:
    from transformers import AutoTokenizer
    print("   Testing GPT-2 access (demo model)...")
    tokenizer = AutoTokenizer.from_pretrained("gpt2")
    print("    GPT-2 model accessible")
    print("    Note: Lab uses GPT-2 for demo. For production, use Llama-2 7B")
    print("    Llama-2 requires license: https://huggingface.co/meta-llama")
except Exception as e:
    warnings.append(f"     Could not access models: {e}")

# Summary
print("\n" + "="*70)
print("VERIFICATION SUMMARY")
print("="*70)

if errors:
    print("\n ERRORS FOUND:")
    for error in errors:
        print(error)
    print("\n" + "-"*70)
    print("REQUIRED FIXES:")
    print("-"*70)
    print("\n1. Install missing packages:")
    print("   pip install transformers peft datasets evaluate torch accelerate")
    print("\n2. For GPU support (recommended):")
    print("   pip install bitsandbytes")
    print("\n3. Create missing data files or lab will use dummy data")
    print("\n4. Ensure module3_lab_starter.py exists")
    print("\nPlease fix the errors above before running the lab.")
    print("="*70)
    sys.exit(1)
    
elif warnings:
    print("\n  WARNINGS:")
    for warning in warnings:
        print(warning)
    print("\n" + "-"*70)
    print("You can proceed with the lab, but be aware of the warnings above.")
    print("="*70)
    
else:
    print("\n ALL CHECKS PASSED!")
    print("\n" + "-"*70)
    print("Your environment is fully configured and ready for the lab.")
    print("-"*70)
    print("\n Next Steps:")
    print("  1. Run the starter: python module3_lab_starter.py")
    print("  2. Complete activities 1-5 in order")
    print("  3. Uncomment code sections as instructed")
    print("  4. Total runtime: approximately 1-3 hours (with training)")
    print("\n Lab Objectives:")
    print("  • Configure LoRA for parameter-efficient fine-tuning")
    print("  • Fine-tune models with 90%+ memory reduction")
    print("  • Compare LoRA vs full fine-tuning performance")
    print("  • Make production deployment decisions")
    print("\n Pro Tips:")
    print("  • Start with Activity 1 to configure LoRA")
    print("  • Monitor GPU usage: watch -n 1 nvidia-smi")
    print("  • Reduce batch size if you encounter OOM errors")
    print("  • Review solution file if stuck")
    print("\nHappy fine-tuning! ")
    print("="*70)

# Additional system info
print("\n" + "="*70)
print("SYSTEM INFORMATION")
print("="*70)
print(f"Python: {sys.version}")
print(f"Platform: {sys.platform}")
print(f"Current directory: {os.getcwd()}")

try:
    import torch
    print(f"PyTorch: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"CUDA version: {torch.version.cuda}")
except:
    pass

try:
    import transformers
    print(f"Transformers: {transformers.__version__}")
except:
    pass

try:
    import peft
    print(f"PEFT: {peft.__version__}")
except:
    pass

print("="*70)
