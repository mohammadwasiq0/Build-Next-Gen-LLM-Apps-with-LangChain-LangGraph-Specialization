"""
Module 3, Video 2: Cost Analysis - Compute, Storage, and API Pricing
COMPACT 3-MINUTE DEMO

Run this in Colab or your local environment with:
  pip install pandas matplotlib seaborn numpy

This demo shows:
1. Calculate compute costs (AWS vs GPU) 
2. Calculate storage costs 
3. Compare self-hosted vs API pricing
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

sns.set_style("whitegrid")
print("=" * 70)
print("COST ANALYSIS - Compute, Storage, API Pricing")
print("Scenario: 2M products, 50M queries/month. What's the TCO?")
print("=" * 70)

# ============================================================================
# SCENARIO PARAMETERS
# ============================================================================

catalog_size = 2_000_000  # 2 million products
monthly_updates = 50_000  # Products updated each month
monthly_queries = 50_000_000  # 50 million queries per month
avg_tokens_per_product = 40  # Average description length
avg_tokens_per_query = 10  # Average search query length
embedding_dimensions = 384  # MiniLM-L6-v2 dimension

print(f"\n📊 SCENARIO PARAMETERS:")
print(f"   Products: {catalog_size:,}")
print(f"   Monthly Queries: {monthly_queries:,}")
print(f"   Monthly Updates: {monthly_updates:,}")

# ============================================================================
# STEP 1: COMPUTE COSTS - Self-Hosted
# ============================================================================

print("\n" + "=" * 70)
print("💻 COMPUTE COSTS - Self-Hosted Infrastructure")
print("=" * 70)

# CPU Instance: AWS c5.4xlarge
cpu_hourly_rate = 0.68  # $/hour
cpu_products_per_hour = 8_000

initial_hours_cpu = catalog_size / cpu_products_per_hour
initial_cost_cpu = initial_hours_cpu * cpu_hourly_rate

monthly_update_hours_cpu = monthly_updates / cpu_products_per_hour
monthly_update_cost_cpu = monthly_update_hours_cpu * cpu_hourly_rate

print(f"\n🖥️  CPU (AWS c5.4xlarge @ ${cpu_hourly_rate}/hour):")
print(f"   Encoding Speed: {cpu_products_per_hour:,} products/hour")
print(f"   Initial Embedding: {initial_hours_cpu:.1f} hours = ${initial_cost_cpu:.2f}")
print(f"   Monthly Updates: {monthly_update_hours_cpu:.1f} hours = ${monthly_update_cost_cpu:.2f}/month")

# GPU Instance: AWS g4dn.xlarge
gpu_hourly_rate = 0.526  # $/hour
gpu_products_per_hour = 40_000  # 5x faster

initial_hours_gpu = catalog_size / gpu_products_per_hour
initial_cost_gpu = initial_hours_gpu * gpu_hourly_rate

monthly_update_hours_gpu = monthly_updates / gpu_products_per_hour
monthly_update_cost_gpu = monthly_update_hours_gpu * gpu_hourly_rate

print(f"\n🎮 GPU (AWS g4dn.xlarge @ ${gpu_hourly_rate}/hour):")
print(f"   Encoding Speed: {gpu_products_per_hour:,} products/hour (5x faster!)")
print(f"   Initial Embedding: {initial_hours_gpu:.1f} hours = ${initial_cost_gpu:.2f}")
print(f"   Monthly Updates: {monthly_update_hours_gpu:.2f} hours = ${monthly_update_cost_gpu:.2f}/month")

print(f"\n💡 KEY INSIGHT: GPU is CHEAPER for batch embedding!")
print(f"   GPU saves ${initial_cost_cpu - initial_cost_gpu:.2f} on initial embedding")

# ============================================================================
# STEP 2: STORAGE COSTS
# ============================================================================

print("\n" + "=" * 70)
print("💾 STORAGE COSTS")
print("=" * 70)

bytes_per_embedding = embedding_dimensions * 4  # float32 = 4 bytes
total_embedding_bytes = catalog_size * bytes_per_embedding
total_gb = total_embedding_bytes / (1024**3)
faiss_overhead = 1.2  # 20% overhead for FAISS index
total_gb_with_index = total_gb * faiss_overhead

s3_cost_per_gb = 0.023  # $/GB/month
monthly_storage_cost = total_gb_with_index * s3_cost_per_gb

print(f"\n📦 Storage Requirements:")
print(f"   Raw Embeddings: {total_gb:.2f} GB")
print(f"   With FAISS Index: {total_gb_with_index:.2f} GB (20% overhead)")
print(f"   AWS S3 Cost: ${monthly_storage_cost:.2f}/month")
print(f"\n💡 Storage is NEGLIGIBLE - don't worry about it!")

# ============================================================================
# STEP 3: SERVING COSTS - Self-Hosted
# ============================================================================

print("\n" + "=" * 70)
print("🚀 SERVING COSTS - Query Infrastructure")
print("=" * 70)

# Calculate required instances
avg_qps = monthly_queries / (30 * 24 * 60 * 60)  # Queries per second
peak_qps = avg_qps * 3  # 3x peak traffic

qps_per_instance = 25  # c5.2xlarge can handle 25 qps
instances_needed = int(np.ceil(peak_qps / qps_per_instance))
instances_with_redundancy = instances_needed + 1  # +1 for redundancy

serving_hourly_rate = 0.34  # c5.2xlarge $/hour
monthly_serving_cost = instances_with_redundancy * serving_hourly_rate * 24 * 30

print(f"\n📈 Query Load:")
print(f"   Average: {avg_qps:.1f} queries/second")
print(f"   Peak (3x): {peak_qps:.1f} queries/second")
print(f"   Instance Capacity: {qps_per_instance} qps each")
print(f"   Instances Needed: {instances_needed} + 1 redundancy = {instances_with_redundancy} total")
print(f"\n💰 Serving Cost: {instances_with_redundancy} × ${serving_hourly_rate}/hour × 720 hours")
print(f"   = ${monthly_serving_cost:.2f}/month")

# ============================================================================
# STEP 4: TOTAL SELF-HOSTED COST
# ============================================================================

total_monthly_selfhosted = monthly_update_cost_gpu + monthly_storage_cost + monthly_serving_cost
annual_selfhosted = total_monthly_selfhosted * 12

print("\n" + "=" * 70)
print("💵 TOTAL SELF-HOSTED COST (Monthly)")
print("=" * 70)
print(f"   Compute (updates): ${monthly_update_cost_gpu:.2f}")
print(f"   Storage:           ${monthly_storage_cost:.2f}")
print(f"   Serving:           ${monthly_serving_cost:.2f}")
print(f"   ─────────────────────────────")
print(f"   TOTAL MONTHLY:     ${total_monthly_selfhosted:.2f}")
print(f"   ANNUAL:            ${annual_selfhosted:.2f}")

# ============================================================================
# STEP 5: MANAGED API COSTS (OpenAI)
# ============================================================================

print("\n" + "=" * 70)
print("🌐 MANAGED API COSTS (OpenAI text-embedding-3-small)")
print("=" * 70)

api_cost_per_million_tokens = 0.02  # $0.02 per 1M tokens

# Initial embedding
initial_tokens = catalog_size * avg_tokens_per_product
initial_api_cost = (initial_tokens / 1_000_000) * api_cost_per_million_tokens

# Monthly update embedding
monthly_update_tokens = monthly_updates * avg_tokens_per_product
monthly_update_api_cost = (monthly_update_tokens / 1_000_000) * api_cost_per_million_tokens

# Monthly query encoding
monthly_query_tokens = monthly_queries * avg_tokens_per_query
monthly_query_api_cost = (monthly_query_tokens / 1_000_000) * api_cost_per_million_tokens

total_monthly_api = monthly_update_api_cost + monthly_query_api_cost
annual_api = total_monthly_api * 12

print(f"\n💳 API Pricing (${api_cost_per_million_tokens} per 1M tokens):")
print(f"   Initial Embedding: {initial_tokens/1_000_000:.1f}M tokens = ${initial_api_cost:.2f}")
print(f"   Monthly Updates: {monthly_update_tokens/1_000_000:.1f}M tokens = ${monthly_update_api_cost:.2f}")
print(f"   Monthly Queries: {monthly_query_tokens/1_000_000:.1f}M tokens = ${monthly_query_api_cost:.2f}")
print(f"   ─────────────────────────────")
print(f"   TOTAL MONTHLY:     ${total_monthly_api:.2f}")
print(f"   ANNUAL:            ${annual_api:.2f}")

# ============================================================================
# STEP 6: COMPARISON VISUALIZATION
# ============================================================================

print("\n📊 Creating cost comparison visualizations...")

fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Plot 1: Monthly cost breakdown
approaches = ['Self-Hosted', 'API']
costs = [total_monthly_selfhosted, total_monthly_api]
colors = ['#e74c3c', '#27ae60']

bars = axes[0].bar(approaches, costs, color=colors, alpha=0.8, edgecolor='black', linewidth=2)
axes[0].set_ylabel('Monthly Cost ($)', fontsize=12, fontweight='bold')
axes[0].set_title('Monthly Cost Comparison\n50M queries/month', fontsize=14, fontweight='bold')
axes[0].set_ylim(0, max(costs) * 1.2)
axes[0].grid(axis='y', alpha=0.3)

# Add value labels
for bar, cost in zip(bars, costs):
    height = bar.get_height()
    axes[0].text(bar.get_x() + bar.get_width()/2., height + 10,
                f'${cost:.2f}/mo',
                ha='center', va='bottom', fontsize=12, fontweight='bold')

# Add winner label
winner_idx = np.argmin(costs)
axes[0].text(winner_idx, costs[winner_idx] + 100, 
            '⭐ WINNER\nat this scale',
            ha='center', fontsize=11, fontweight='bold', color='green',
            bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.8))

# Plot 2: Cost breakdown for self-hosted
categories = ['Compute\n(Updates)', 'Storage', 'Serving\n(24/7)']
breakdown = [monthly_update_cost_gpu, monthly_storage_cost, monthly_serving_cost]
colors_breakdown = ['#3498db', '#95a5a6', '#e67e22']

bars2 = axes[1].bar(categories, breakdown, color=colors_breakdown, alpha=0.8, 
                   edgecolor='black', linewidth=2)
axes[1].set_ylabel('Monthly Cost ($)', fontsize=12, fontweight='bold')
axes[1].set_title('Self-Hosted Cost Breakdown\nWhere does the money go?', 
                 fontsize=14, fontweight='bold')
axes[1].set_ylim(0, max(breakdown) * 1.2)
axes[1].grid(axis='y', alpha=0.3)

# Add value labels
for bar, cost in zip(bars2, breakdown):
    height = bar.get_height()
    axes[1].text(bar.get_x() + bar.get_width()/2., height + 10,
                f'${cost:.2f}',
                ha='center', va='bottom', fontsize=11, fontweight='bold')

# Highlight the big one
max_idx = np.argmax(breakdown)
axes[1].text(max_idx, breakdown[max_idx] + 50, 
            '🔥 Biggest\nCost!',
            ha='center', fontsize=10, fontweight='bold', color='red')

plt.tight_layout()
plt.savefig('cost_comparison.png', dpi=150, bbox_inches='tight')
print("📸 Saved: cost_comparison.png")
plt.show()

# ============================================================================
# STEP 7: BREAK-EVEN ANALYSIS
# ============================================================================

print("\n" + "=" * 70)
print("📈 BREAK-EVEN ANALYSIS - When does each approach win?")
print("=" * 70)

# Calculate break-even point
# Self-hosted cost is mostly fixed (serving)
# API cost scales with queries

query_volumes = np.array([5, 10, 25, 50, 100, 200, 500]) * 1_000_000  # Millions
selfhosted_costs = []
api_costs = []

for queries in query_volumes:
    # Self-hosted scales with serving capacity
    qps = queries / (30 * 24 * 60 * 60)
    peak_qps = qps * 3
    instances = int(np.ceil(peak_qps / qps_per_instance)) + 1
    sh_cost = instances * serving_hourly_rate * 24 * 30 + monthly_update_cost_gpu + monthly_storage_cost
    selfhosted_costs.append(sh_cost)
    
    # API scales linearly with queries
    api_cost = (queries * avg_tokens_per_query / 1_000_000) * api_cost_per_million_tokens + monthly_update_api_cost
    api_costs.append(api_cost)

fig, ax = plt.subplots(figsize=(12, 7))

ax.plot(query_volumes / 1_000_000, selfhosted_costs, marker='o', linewidth=3, 
       markersize=10, label='Self-Hosted', color='#e74c3c')
ax.plot(query_volumes / 1_000_000, api_costs, marker='s', linewidth=3, 
       markersize=10, label='API (OpenAI)', color='#27ae60')

# Find break-even point
differences = np.abs(np.array(selfhosted_costs) - np.array(api_costs))
breakeven_idx = np.argmin(differences)
breakeven_queries = query_volumes[breakeven_idx] / 1_000_000

ax.axvline(x=breakeven_queries, color='gray', linestyle='--', linewidth=2, alpha=0.7)
ax.text(breakeven_queries, max(selfhosted_costs) * 0.8, 
       f'Break-even\n~{breakeven_queries:.0f}M queries/mo',
       ha='center', fontsize=11, fontweight='bold',
       bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.8))

ax.fill_between(query_volumes / 1_000_000, 0, max(max(selfhosted_costs), max(api_costs)),
                where=(query_volumes / 1_000_000 <= breakeven_queries),
                alpha=0.2, color='green', label='API Cheaper Zone')
ax.fill_between(query_volumes / 1_000_000, 0, max(max(selfhosted_costs), max(api_costs)),
                where=(query_volumes / 1_000_000 > breakeven_queries),
                alpha=0.2, color='red', label='Self-Hosted Cheaper Zone')

ax.set_xlabel('Monthly Query Volume (Millions)', fontsize=12, fontweight='bold')
ax.set_ylabel('Monthly Cost ($)', fontsize=12, fontweight='bold')
ax.set_title('Break-Even Analysis: Self-Hosted vs API\nWhen does each approach win?', 
            fontsize=14, fontweight='bold')
ax.legend(fontsize=11, loc='upper left')
ax.grid(True, alpha=0.3)
ax.set_xlim(0, max(query_volumes) / 1_000_000)

plt.tight_layout()
plt.savefig('breakeven_analysis.png', dpi=150, bbox_inches='tight')
print("📸 Saved: breakeven_analysis.png")
plt.show()

# ============================================================================
# STEP 8: COST OPTIMIZATION OPPORTUNITIES
# ============================================================================

print("\n" + "=" * 70)
print("💡 COST OPTIMIZATION OPPORTUNITIES")
print("=" * 70)

optimization_data = {
    'Optimization': [
        'Use batch jobs (not 24/7 instances)',
        'Choose GPU for batch embedding',
        'Eliminate duplicate storage',
        'Right-size serving instances',
        'Use spot instances for embedding'
    ],
    'Potential Savings': ['$200-400/mo', '$140/mo', '$50-100/mo', '$300-500/mo', '$50-80/mo'],
    'Difficulty': ['Easy', 'Easy', 'Medium', 'Medium', 'Medium']
}

opt_df = pd.DataFrame(optimization_data)
print(opt_df.to_string(index=False))

# ============================================================================
# FINAL SUMMARY
# ============================================================================

print("\n" + "=" * 70)
print("✅ KEY TAKEAWAYS")
print("=" * 70)
print(f"""
1. THREE COST BUCKETS
   → Compute: ${monthly_update_cost_gpu:.2f}/mo (GPU batch jobs)
   → Storage: ${monthly_storage_cost:.2f}/mo (negligible!)
   → Serving: ${monthly_serving_cost:.2f}/mo (BIGGEST COST - 24/7 instances)

2. SELF-HOSTED vs API AT 50M QUERIES/MONTH
   → Self-Hosted: ${total_monthly_selfhosted:.2f}/month
   → API: ${total_monthly_api:.2f}/month
   → API wins at this scale!

3. BREAK-EVEN POINT
   → Below ~{breakeven_queries:.0f}M queries/month: API is cheaper
   → Above ~{breakeven_queries:.0f}M queries/month: Self-hosted is cheaper
   → API scales linearly, Self-hosted has fixed costs

4. OPTIMIZATION TIPS
   → Use GPU for batch embedding (5x faster, cheaper!)
   → Shut down instances after embedding (don't pay for idle)
   → Store once (S3), load to memory (no duplicate EBS/Redis)
   → Right-size serving instances based on actual QPS

5. REAL-WORLD CASE
   → Company went from $31K/mo → $14K/mo (45% savings!)
   → How? Switched GPU→CPU for serving, eliminated duplicate storage
   → Same accuracy, same latency, huge cost reduction
""")

print("\n" + "=" * 70)