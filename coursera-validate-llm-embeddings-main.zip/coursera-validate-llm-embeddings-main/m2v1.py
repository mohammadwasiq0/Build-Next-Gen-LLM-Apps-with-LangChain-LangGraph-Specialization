"""
Module 2, Video 1: UMAP Fundamentals for Embedding Visualization
=================================================================
Demo Duration: ~3 minutes
Author: Ritesh Vajariya

This script demonstrates:
1. Why dimensionality reduction is essential for 384D embeddings
2. Installing UMAP and creating 2D projections
3. Interpreting UMAP scatter plots to assess embedding quality
4. Tuning hyperparameters (n_neighbors, min_dist)
5. Recognizing healthy vs problematic embedding patterns

Run this in: Local Python environment, Google Colab, or Jupyter
"""

import numpy as np
from sentence_transformers import SentenceTransformer
import umap
import matplotlib.pyplot as plt
import time

# ============================================================================
# PART 1: Generate Embeddings for Product Catalog (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 1: Creating Product Embeddings")
print("=" * 70)

# Realistic e-commerce product catalog with clear categories
products = {
    "Electronics": [
        "Dell XPS 15 laptop with 16GB RAM and Intel i7 processor",
        "MacBook Pro 14-inch with M2 chip and Retina display",
        "HP Spectre x360 convertible laptop touchscreen",
        "Lenovo ThinkPad X1 Carbon business ultrabook",
        "ASUS ROG gaming laptop with RTX 4070 graphics",
        "Acer Predator gaming laptop high performance",
        "Microsoft Surface Laptop Studio creative workstation",
        "Samsung Galaxy Book Pro portable laptop",
        "Razer Blade 15 gaming laptop aluminum chassis",
        "LG Gram lightweight laptop long battery life",
    ],
    "Home & Kitchen": [
        "KitchenAid stand mixer 5-quart tilt head",
        "Ninja blender professional food processor",
        "Instant Pot pressure cooker 8-quart capacity",
        "Cuisinart coffee maker programmable brew",
        "Dyson vacuum cleaner cordless stick",
        "iRobot Roomba robot vacuum smart navigation",
        "Keurig coffee maker single serve pod",
        "Vitamix high-performance blender professional",
        "Breville espresso machine barista express",
        "Shark vacuum cleaner upright bagless",
    ],
    "Furniture": [
        "IKEA desk computer workstation white finish",
        "Herman Miller office chair ergonomic mesh",
        "Standing desk adjustable height electric motor",
        "Gaming chair racing style with lumbar support",
        "L-shaped desk corner workstation large surface",
        "Executive office chair leather high back",
        "Bookshelf storage unit 5-tier wood",
        "Dining table set 6 chairs solid wood",
        "Sofa sectional L-shaped gray fabric",
        "Coffee table modern design glass top",
    ],
    "Clothing": [
        "Nike running shoes breathable mesh men",
        "Adidas sneakers athletic sports casual",
        "Levi's jeans classic fit denim blue",
        "North Face jacket waterproof winter",
        "Columbia fleece pullover outdoor hiking",
        "Patagonia backpack travel hiking 30L",
        "Under Armour athletic shirt moisture wicking",
        "Champion hoodie sweatshirt cotton blend",
        "Timberland boots waterproof leather work",
        "Carhartt work pants durable heavy duty",
    ],
}

# Flatten products and track categories
all_products = []
category_labels = []
for category, items in products.items():
    all_products.extend(items)
    category_labels.extend([category] * len(items))

print(f"Product catalog: {len(all_products)} items across {len(products)} categories")
for category, items in products.items():
    print(f"  - {category}: {len(items)} products")
print()

# Generate embeddings
model = SentenceTransformer('all-MiniLM-L6-v2')
print("Generating 384-dimensional embeddings...")
embeddings = model.encode(all_products, show_progress_bar=False)

print(f"✓ Embeddings generated: {embeddings.shape}")
print(f"  - {embeddings.shape[0]} products × {embeddings.shape[1]} dimensions")
print(f"  - Problem: Humans can't visualize 384 dimensions!")
print()

# ============================================================================
# PART 2: Apply UMAP Dimensionality Reduction (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 2: Reducing 384D → 2D with UMAP")
print("=" * 70)

print("Why UMAP?")
print("  - Preserves both local AND global structure")
print("  - Non-linear (unlike PCA)")
print("  - Reveals semantic clustering patterns")
print()

# Create UMAP reducer with balanced parameters
reducer = umap.UMAP(
    n_neighbors=15,      # Balance local vs global structure
    min_dist=0.1,        # Minimum distance between points
    n_components=2,      # Output dimensions (2D for visualization)
    metric='cosine',     # Distance metric
    random_state=42      # Reproducibility
)

print("UMAP Configuration:")
print(f"  - n_neighbors: 15 (balanced view)")
print(f"  - min_dist: 0.1 (moderate spread)")
print(f"  - n_components: 2 (2D visualization)")
print()

# Fit and transform
print("Applying UMAP transformation...")
start_time = time.time()
embedding_2d = reducer.fit_transform(embeddings)
umap_time = time.time() - start_time

print(f"✓ UMAP complete in {umap_time:.2f} seconds")
print(f"  - Input: {embeddings.shape}")
print(f"  - Output: {embedding_2d.shape}")
print(f"  - Each product now has just 2 coordinates (x, y)")
print()

# ============================================================================
# PART 3: Visualize Embeddings (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 3: Creating UMAP Visualization")
print("=" * 70)

# Create the main visualization
fig, ax = plt.subplots(figsize=(12, 8))

# Color map for categories
category_colors = {
    "Electronics": "#3498db",      # Blue
    "Home & Kitchen": "#e74c3c",   # Red
    "Furniture": "#2ecc71",        # Green
    "Clothing": "#f39c12"          # Orange
}

# Plot each category
for category in products.keys():
    mask = np.array(category_labels) == category
    ax.scatter(
        embedding_2d[mask, 0],
        embedding_2d[mask, 1],
        c=category_colors[category],
        label=category,
        alpha=0.7,
        s=100,
        edgecolors='black',
        linewidth=0.5
    )

# Styling
ax.set_xlabel('UMAP Dimension 1', fontsize=12, fontweight='bold')
ax.set_ylabel('UMAP Dimension 2', fontsize=12, fontweight='bold')
ax.set_title('Product Embeddings: 384D → 2D via UMAP\nHealthy Clustering Pattern', 
             fontsize=14, fontweight='bold', pad=20)
ax.legend(loc='upper right', fontsize=11, framealpha=0.9)
ax.grid(True, alpha=0.3, linestyle='--')

# Add annotations
ax.text(0.02, 0.98, 'What to look for:\n✓ Tight clusters = coherent categories\n✓ Clear separation = distinct semantics\n✓ Smooth transitions = related concepts',
        transform=ax.transAxes, fontsize=10,
        verticalalignment='top',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

plt.tight_layout()
plt.savefig('umap_visualization.png', dpi=150, bbox_inches='tight')
print("✓ Visualization saved: umap_visualization.png")
print()

# Show the plot
plt.show()

# ============================================================================
# PART 4: Interpret the Visualization (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 4: Interpreting UMAP Patterns")
print("=" * 70)

# Calculate cluster tightness for each category
print("Cluster Quality Analysis:")
print("-" * 70)

for category in products.keys():
    mask = np.array(category_labels) == category
    category_points = embedding_2d[mask]
    
    # Calculate centroid
    centroid = category_points.mean(axis=0)
    
    # Calculate distances from centroid
    distances = np.sqrt(((category_points - centroid) ** 2).sum(axis=1))
    avg_distance = distances.mean()
    max_distance = distances.max()
    
    # Determine cluster quality
    if avg_distance < 1.5:
        quality = "EXCELLENT - Very tight cluster"
    elif avg_distance < 3.0:
        quality = "GOOD - Cohesive grouping"
    elif avg_distance < 5.0:
        quality = "MODERATE - Some scatter"
    else:
        quality = "POOR - Highly scattered"
    
    print(f"\n{category}:")
    print(f"  Average spread: {avg_distance:.2f}")
    print(f"  Max distance: {max_distance:.2f}")
    print(f"  Quality: {quality}")

print()
print("=" * 70)
print("WHAT THIS VISUALIZATION TELLS US:")
print("=" * 70)
print("""
✓ HEALTHY PATTERNS (What we want to see):
  1. Tight clusters - Similar products group closely
  2. Clear separation - Different categories are distinct
  3. Smooth transitions - Related items show gradual shifts

✗ PROBLEMATIC PATTERNS (Red flags):
  1. Scattered points - Poor descriptions or data quality
  2. Unexpected mixing - Categories bleeding together
  3. Isolated outliers - Mislabeled or corrupted data
  4. No structure - Model not capturing semantics

Our visualization shows HEALTHY patterns:
→ Electronics (blue) tightly clustered
→ Kitchen (red) clearly separated
→ Furniture (green) well-defined
→ Clothing (orange) distinct grouping
""")

# ============================================================================
# PART 5: Hyperparameter Effects (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 5: UMAP Hyperparameter Impact")
print("=" * 70)

print("Key hyperparameters:")
print("-" * 70)
print("\nn_neighbors (15 in this demo):")
print("  - LOW (5-10): Emphasizes local structure, detailed clusters")
print("  - HIGH (30-50): Emphasizes global structure, broader view")
print("  - SWEET SPOT: 15-20 for balanced visualization")
print()
print("min_dist (0.1 in this demo):")
print("  - LOW (0.0): Very tight clusters, maximum separation")
print("  - HIGH (0.5): Looser clusters, more spread out")
print("  - SWEET SPOT: 0.1 for clear but not over-compressed clusters")
print()

print("When to adjust:")
print("  → Increase n_neighbors if clusters seem too fragmented")
print("  → Decrease n_neighbors if you want more detail")
print("  → Decrease min_dist if clusters overlap too much")
print("  → Increase min_dist if points are too compressed")
print()

# ============================================================================
# SUMMARY (20 seconds)
# ============================================================================
print("=" * 70)
print("DEMO SUMMARY")
print("=" * 70)
print(f"""
UMAP Workflow Complete:
1. ✓ Generated 384-dimensional embeddings for {len(all_products)} products
2. ✓ Reduced to 2D using UMAP in {umap_time:.2f} seconds
3. ✓ Visualized category clustering patterns
4. ✓ Confirmed healthy embedding quality

Key Insights:
→ UMAP reveals semantic structure hidden in high dimensions
→ Tight clusters = semantically coherent embeddings
→ Clear separation = distinct categories well-captured
→ Visual inspection catches issues metrics might miss

Production Value:
→ Use for: Quality checks, debugging, presentations
→ Run: Weekly or after model changes
→ Alert: If cluster quality degrades

Next Steps:
→ Video 2: Detect anomalous clusters with DBSCAN
→ Video 3: Build data cleanup workflows
→ Use visualization to find data quality issues
""")

print("=" * 70)
print("Demo Complete! ✓")
print("=" * 70)