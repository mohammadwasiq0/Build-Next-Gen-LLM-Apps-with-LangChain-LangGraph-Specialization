"""
Module 3, Video 1 (V2): Benchmarking Inference Latency at Scale
================================================================
Author: Ritesh Vajariya

Run this on: Mac (M-series or Intel), Linux, or Windows - NO GPU REQUIRED

pip install sentence-transformers matplotlib seaborn pandas numpy

This Mac-compatible demo shows:
1. CPU latency benchmarking (runs on your Mac)
2. GPU trade-offs (explained with real benchmark data)
3. Quantization for model compression (works on Mac)
4. Caching to reduce repeated encoding (works on Mac)
5. Load testing with concurrent queries (works on Mac)
"""
# Add import at top
import platform
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sentence_transformers import SentenceTransformer
import time
import warnings
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import hashlib
warnings.filterwarnings('ignore')

sns.set_style("whitegrid")
print("=" * 70)
print("LATENCY BENCHMARKING V2 - Comprehensive Production Guide")
print("Scenario: Legal search needs p95 < 200ms")
print("=" * 70)

# ============================================================================
# PART 1: Setup and Test Queries
# ============================================================================
np.random.seed(42)

test_queries = [
    "employment contract termination clause",
    "intellectual property rights agreement",
    "merger and acquisition due diligence",
    "breach of contract damages calculation",
    "non-disclosure agreement template",
    "shareholder voting rights provisions",
    "patent infringement case law",
    "employment discrimination lawsuit precedent",
    "real estate purchase agreement terms",
    "corporate governance best practices"
] * 10  # 100 queries

print(f"\n📊 Test set: {len(test_queries)} realistic legal queries")
print(f"💻 Running on: {'Apple Silicon' if 'arm' in platform.machine().lower() else 'Intel/AMD'}")

# ============================================================================
# PART 2: CPU Baseline Benchmarking
# ============================================================================
print("\n" + "=" * 70)
print("PART 1: CPU BASELINE BENCHMARKING")
print("=" * 70)

model_name = 'all-MiniLM-L6-v2'
print(f"\n⏱️  Loading {model_name} on CPU...")
model = SentenceTransformer(model_name)

# Benchmark CPU latency
print(f"🔍 Benchmarking CPU latency on {len(test_queries)} queries...")
cpu_latencies = []

for query in test_queries:
    start = time.time()
    embedding = model.encode(query, show_progress_bar=False)
    latency = (time.time() - start) * 1000  # milliseconds
    cpu_latencies.append(latency)

cpu_p50 = np.percentile(cpu_latencies, 50)
cpu_p95 = np.percentile(cpu_latencies, 95)
cpu_p99 = np.percentile(cpu_latencies, 99)

print(f"\n✅ CPU Results:")
print(f"   p50: {cpu_p50:.1f}ms | p95: {cpu_p95:.1f}ms | p99: {cpu_p99:.1f}ms")
print(f"   {'✅ MEETS SLA' if cpu_p95 < 200 else '❌ VIOLATES SLA'} (p95 < 200ms)")

# ============================================================================
# PART 3: GPU vs CPU Trade-offs (Theoretical + Practical)
# ============================================================================
print("\n" + "=" * 70)
print("PART 2: GPU vs CPU TRADE-OFFS")
print("=" * 70)

print("\n🖥️  CPU CHARACTERISTICS:")
print("   ✅ Available everywhere (Mac, Linux, Windows)")
print("   ✅ No special setup required")
print("   ✅ Good for real-time queries (low latency)")
print(f"   📊 Our result: p95 = {cpu_p95:.1f}ms")

print("\n🎮 GPU CHARACTERISTICS (if available):")
print("   ⚡ 3-5x faster for BATCH processing")
print("   💰 Costs more (AWS g4dn vs c5 instances)")
print("   🔧 Requires CUDA setup")
print("   📊 Typical result: p95 = 15-25ms (3-4x faster)")

print("\n💡 WHEN TO USE EACH:")
print("   CPU:  Real-time single queries (what we're doing)")
print("   GPU:  Batch encoding large catalogs offline")
print("         (e.g., embedding 1M products at night)")

# Simulate GPU numbers for comparison
gpu_p50_simulated = cpu_p50 / 3.5  # GPUs are ~3-4x faster
gpu_p95_simulated = cpu_p95 / 3.5
gpu_p99_simulated = cpu_p99 / 3.5

print(f"\n📊 COMPARISON TABLE:")
comparison_df = pd.DataFrame({
    'Hardware': ['CPU (Your Mac)', 'GPU (Simulated)', 'Speedup'],
    'p50 (ms)': [f'{cpu_p50:.1f}', f'{gpu_p50_simulated:.1f}', f'{cpu_p50/gpu_p50_simulated:.1f}x'],
    'p95 (ms)': [f'{cpu_p95:.1f}', f'{gpu_p95_simulated:.1f}', f'{cpu_p95/gpu_p95_simulated:.1f}x'],
    'Best For': ['Real-time queries', 'Batch encoding', 'Cost vs Speed']
})
print(comparison_df.to_string(index=False))

print("\n⚠️  PRODUCTION INSIGHT:")
print("   For serving 50M queries/month: Use CPU instances")
print("   For indexing 2M products daily: Use GPU for batch jobs")
print("   Don't pay for idle GPU time on query servers!")

# ============================================================================
# PART 4: Quantization Techniques
# ============================================================================
print("\n" + "=" * 70)
print("PART 3: QUANTIZATION FOR MODEL COMPRESSION")
print("=" * 70)

print("\n🗜️  What is quantization?")
print("   Converting float32 (32-bit) → int8 (8-bit)")
print("   4x smaller model, 2-3x faster inference")
print("   Minimal accuracy loss (<1%)")

# Get model size
import sys
import torch

original_size_mb = sum(p.numel() * p.element_size() for p in model.parameters()) / (1024**2)
print(f"\n📦 ORIGINAL MODEL:")
print(f"   Size: {original_size_mb:.1f} MB (float32)")
print(f"   Parameters: {sum(p.numel() for p in model.parameters()):,}")

# Simulate quantized model (we can't actually quantize sentence-transformers easily on Mac)
# But we can show the concept
quantized_size_mb = original_size_mb / 4
print(f"\n📦 QUANTIZED MODEL (int8):")
print(f"   Size: {quantized_size_mb:.1f} MB (4x smaller)")
print(f"   Speed: ~2-3x faster inference")
print(f"   Accuracy: -0.5% to -1% typical")

print("\n🎯 WHEN TO QUANTIZE:")
print("   ✅ Mobile deployment (smaller = faster downloads)")
print("   ✅ Edge devices (limited memory)")
print("   ✅ High QPS servers (2x speedup matters)")
print("   ❌ Not worth it if CPU time is negligible")

# Benchmark with simulated quantization speedup
print(f"\n⏱️  Simulating quantized inference...")
quantized_speedup = 2.5  # Typical 2-3x speedup
quantized_latencies = [l / quantized_speedup for l in cpu_latencies]
quant_p95 = np.percentile(quantized_latencies, 95)

print(f"   Original p95: {cpu_p95:.1f}ms")
print(f"   Quantized p95: {quant_p95:.1f}ms")
print(f"   Speedup: {cpu_p95/quant_p95:.1f}x faster")

# ============================================================================
# PART 5: Caching Strategies
# ============================================================================
print("\n" + "=" * 70)
print("PART 4: CACHING TO REDUCE REPEATED ENCODING")
print("=" * 70)

print("\n💾 Why cache embeddings?")
print("   Users often repeat queries: 'contract template', 'NDA'")
print("   Encoding takes 45ms, cache lookup takes <1ms")
print("   Cache hit = 45x faster!")

# Build a simple cache
class EmbeddingCache:
    def __init__(self, model):
        self.model = model
        self.cache = {}
        self.hits = 0
        self.misses = 0
    
    def encode(self, text):
        # Hash the text for cache key
        cache_key = hashlib.md5(text.encode()).hexdigest()
        
        if cache_key in self.cache:
            self.hits += 1
            return self.cache[cache_key]
        else:
            self.misses += 1
            embedding = self.model.encode(text, show_progress_bar=False)
            self.cache[cache_key] = embedding
            return embedding
    
    def hit_rate(self):
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0

# Create realistic query distribution with repeats
popular_queries = test_queries[:20]  # 20 popular queries
repeated_queries = popular_queries * 5 + test_queries  # Popular ones repeat 5x

print(f"\n🔍 Testing with {len(repeated_queries)} queries (some repeated)...")

# Without cache
start = time.time()
for query in repeated_queries[:50]:  # Sample for speed
    model.encode(query, show_progress_bar=False)
no_cache_time = time.time() - start

# With cache
cached_model = EmbeddingCache(model)
start = time.time()
for query in repeated_queries[:50]:
    cached_model.encode(query)
cache_time = time.time() - start

print(f"\n📊 CACHE PERFORMANCE:")
print(f"   Without cache: {no_cache_time:.2f}s")
print(f"   With cache:    {cache_time:.2f}s")
print(f"   Speedup:       {no_cache_time/cache_time:.1f}x faster")
print(f"   Hit rate:      {cached_model.hit_rate():.1%}")
print(f"   Cache hits:    {cached_model.hits}")
print(f"   Cache misses:  {cached_model.misses}")

print("\n💡 PRODUCTION CACHING STRATEGIES:")
print("   1. In-memory cache (Redis/Memcached)")
print("   2. LRU eviction (keep hot queries)")
print("   3. TTL: 1 hour (balance freshness vs hits)")
print("   4. Monitor hit rate (aim for 40%+ for ROI)")

print("\n⚠️  WATCH OUT FOR:")
print("   ❌ Cache too large → memory issues")
print("   ❌ Cache stale data → wrong results")
print("   ✅ Cache popular queries only (80/20 rule)")

# ============================================================================
# PART 6: Load Testing with Concurrent Queries
# ============================================================================
print("\n" + "=" * 70)
print("PART 5: LOAD TESTING METHODOLOGIES")
print("=" * 70)

print("\n🚦 Why load test?")
print("   Single-query latency ≠ multi-user latency")
print("   10 concurrent users → contention, queueing")
print("   Need to find: max throughput before degradation")

def encode_query_timed(args):
    """Helper for parallel execution"""
    model, query = args
    start = time.time()
    model.encode(query, show_progress_bar=False)
    return (time.time() - start) * 1000

# Test with increasing concurrency
concurrency_levels = [1, 5, 10, 20]
load_test_results = []

print(f"\n⏱️  Running load tests...")

for n_concurrent in concurrency_levels:
    test_subset = test_queries[:n_concurrent * 5]  # 5 queries per thread
    
    start = time.time()
    with ThreadPoolExecutor(max_workers=n_concurrent) as executor:
        latencies = list(executor.map(
            encode_query_timed,
            [(model, q) for q in test_subset]
        ))
    total_time = time.time() - start
    
    p95_latency = np.percentile(latencies, 95)
    throughput = len(test_subset) / total_time
    
    load_test_results.append({
        'Concurrent Users': n_concurrent,
        'Queries': len(test_subset),
        'Total Time (s)': total_time,
        'Throughput (QPS)': throughput,
        'p95 Latency (ms)': p95_latency
    })
    
    print(f"   {n_concurrent} concurrent: {throughput:.1f} QPS, p95={p95_latency:.0f}ms")

load_df = pd.DataFrame(load_test_results)

print(f"\n📊 LOAD TEST SUMMARY:")
print(load_df.to_string(index=False))

print("\n🎯 CAPACITY PLANNING:")
baseline_qps = load_df[load_df['Concurrent Users'] == 1]['Throughput (QPS)'].values[0]
max_qps = load_df['Throughput (QPS)'].max()
print(f"   Single-user throughput: {baseline_qps:.1f} QPS")
print(f"   Max throughput:         {max_qps:.1f} QPS")
print(f"   Recommended capacity:   {max_qps * 0.7:.1f} QPS (70% utilization)")

print("\n💡 SIZING PRODUCTION INFRASTRUCTURE:")
target_qps = 50  # 50M queries/month = ~19 avg QPS, 57 peak QPS
instances_needed = np.ceil(target_qps / (max_qps * 0.7))
print(f"   Target: 50 QPS (peak traffic)")
print(f"   Instances needed: {int(instances_needed)} @ 70% utilization")
print(f"   With redundancy: {int(instances_needed + 1)} instances")

# ============================================================================
# PART 7: Visualization 1 - Optimization Techniques (4 panels)
# ============================================================================
print("\n" + "=" * 70)
print("CREATING VISUALIZATION 1: Optimization Techniques")
print("=" * 70)

fig1 = plt.figure(figsize=(16, 10))
gs1 = fig1.add_gridspec(2, 2, hspace=0.35, wspace=0.35)

# Panel 1: CPU vs GPU comparison
ax1 = fig1.add_subplot(gs1[0, 0])
hardware_data = {
    'CPU': [cpu_p50, cpu_p95, cpu_p99],
    'GPU (Simulated)': [gpu_p50_simulated, gpu_p95_simulated, gpu_p99_simulated]
}
x = np.arange(3)
width = 0.35
labels = ['p50', 'p95', 'p99']

for i, (hw, values) in enumerate(hardware_data.items()):
    ax1.bar(x + i*width, values, width, label=hw, alpha=0.8)

ax1.axhline(y=200, color='red', linestyle='--', linewidth=2, label='SLA: 200ms')
ax1.set_ylabel('Latency (ms)', fontweight='bold')
ax1.set_title('CPU vs GPU Latency Comparison\nGPU wins for batch, CPU for real-time', fontweight='bold')
ax1.set_xticks(x + width/2)
ax1.set_xticklabels(labels)
ax1.legend()
ax1.grid(axis='y', alpha=0.3)

# Panel 2: Quantization impact
ax2 = fig1.add_subplot(gs1[0, 1])
quant_data = {
    'Model Size (MB)': [original_size_mb, quantized_size_mb],
    'p95 Latency (ms)': [cpu_p95, quant_p95]
}
x2 = np.arange(2)
width2 = 0.35
configs = ['Original\n(float32)', 'Quantized\n(int8)']

ax2_twin = ax2.twinx()
bars1 = ax2.bar(x2 - width2/2, quant_data['Model Size (MB)'], width2, 
                label='Model Size', color='#3498db', alpha=0.8)
bars2 = ax2_twin.bar(x2 + width2/2, quant_data['p95 Latency (ms)'], width2,
                     label='p95 Latency', color='#e67e22', alpha=0.8)

ax2.set_ylabel('Model Size (MB)', fontweight='bold', color='#3498db')
ax2_twin.set_ylabel('p95 Latency (ms)', fontweight='bold', color='#e67e22')
ax2.set_title('Quantization Impact\n4x smaller, 2.5x faster', fontweight='bold')
ax2.set_xticks(x2)
ax2.set_xticklabels(configs)
ax2.tick_params(axis='y', labelcolor='#3498db')
ax2_twin.tick_params(axis='y', labelcolor='#e67e22')

# Add value labels
for bar in bars1:
    height = bar.get_height()
    ax2.text(bar.get_x() + bar.get_width()/2., height,
            f'{height:.0f}MB', ha='center', va='bottom', fontweight='bold')
for bar in bars2:
    height = bar.get_height()
    ax2_twin.text(bar.get_x() + bar.get_width()/2., height,
                 f'{height:.0f}ms', ha='center', va='bottom', fontweight='bold')

# Panel 3: Cache hit rate impact
ax3 = fig1.add_subplot(gs1[1, 0])
cache_scenarios = ['No Cache', 'With Cache\n(60% hit rate)']
times = [no_cache_time, cache_time]
colors = ['#e74c3c', '#27ae60']

bars = ax3.bar(cache_scenarios, times, color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)
ax3.set_ylabel('Total Time (seconds)', fontweight='bold')
ax3.set_title('Caching Strategy Impact\n3x speedup with 60% hit rate', fontweight='bold')
ax3.grid(axis='y', alpha=0.3)

for bar in bars:
    height = bar.get_height()
    ax3.text(bar.get_x() + bar.get_width()/2., height,
            f'{height:.2f}s', ha='center', va='bottom', fontweight='bold', fontsize=11)

# Add speedup annotation
ax3.annotate(f'{no_cache_time/cache_time:.1f}x faster!',
            xy=(1, cache_time), xytext=(0.5, no_cache_time*0.8),
            fontsize=12, fontweight='bold', color='#27ae60',
            arrowprops=dict(arrowstyle='->', color='#27ae60', lw=2),
            bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.8))

# Panel 4: Load testing - QPS vs Concurrency
ax4 = fig1.add_subplot(gs1[1, 1])
concurrency = load_df['Concurrent Users'].values
throughput = load_df['Throughput (QPS)'].values

ax4.plot(concurrency, throughput, marker='o', linewidth=2, markersize=8, color='#3498db')
ax4.axhline(y=max_qps*0.7, color='orange', linestyle='--', linewidth=2, 
           label='70% capacity (safe)')
ax4.fill_between(concurrency, 0, throughput, alpha=0.2, color='#3498db')

ax4.set_xlabel('Concurrent Users', fontweight='bold', fontsize=11)
ax4.set_ylabel('Throughput (QPS)', fontweight='bold', fontsize=11)
ax4.set_title('Load Testing: Throughput vs Concurrency\nPlan for 70% of max capacity', fontweight='bold', fontsize=12)
ax4.legend(fontsize=10)
ax4.grid(True, alpha=0.3)

plt.suptitle('Optimization Techniques: GPU, Quantization, Caching, Load Testing', 
            fontsize=15, fontweight='bold', y=0.995)
plt.tight_layout()
plt.savefig('optimization_techniques.png', dpi=150, bbox_inches='tight')
print("\n📸 Saved: optimization_techniques.png")
plt.show()

# ============================================================================
# PART 8: Visualization 2 - Production Deployment (3 charts + decision box)
# ============================================================================
print("\n" + "=" * 70)
print("CREATING VISUALIZATION 2: Production Deployment Decision")
print("=" * 70)

fig2 = plt.figure(figsize=(16, 8))
gs2 = fig2.add_gridspec(2, 2, hspace=0.35, wspace=0.35)

# Panel 1: Load testing - Latency degradation
ax5 = fig2.add_subplot(gs2[0, 0])
latencies_under_load = load_df['p95 Latency (ms)'].values

ax5.plot(concurrency, latencies_under_load, marker='s', linewidth=3, markersize=10, 
        color='#e74c3c', label='p95 Latency')
ax5.axhline(y=200, color='red', linestyle='--', linewidth=2, label='SLA: 200ms')
ax5.fill_between(concurrency, 0, 200, alpha=0.2, color='green', label='Acceptable Zone')
ax5.fill_between(concurrency, 200, latencies_under_load.max()*1.1, alpha=0.2, 
                color='red', label='SLA Violation Zone')

ax5.set_xlabel('Concurrent Users', fontweight='bold', fontsize=11)
ax5.set_ylabel('p95 Latency (ms)', fontweight='bold', fontsize=11)
ax5.set_title('Latency Under Load\nStay under SLA even at peak', fontweight='bold', fontsize=13)
ax5.legend(fontsize=10)
ax5.grid(True, alpha=0.3)

# Panel 2: Cost comparison with/without caching
ax6 = fig2.add_subplot(gs2[0, 1])
scenarios = ['No Cache\n(2 instances)', 'With Cache\n(1 instance)']
monthly_costs = [2 * 244, 1 * 244]  # Cost per instance
colors_cost = ['#e74c3c', '#27ae60']

bars_cost = ax6.bar(scenarios, monthly_costs, color=colors_cost, alpha=0.8, 
                   edgecolor='black', linewidth=2, width=0.6)
ax6.set_ylabel('Monthly Cost (USD)', fontweight='bold', fontsize=11)
ax6.set_title('Infrastructure Cost Impact', fontweight='bold', fontsize=13)
ax6.grid(axis='y', alpha=0.3)
ax6.set_ylim(0, 600)

# Add value labels on bars
for bar in bars_cost:
    height = bar.get_height()
    ax6.text(bar.get_x() + bar.get_width()/2., height + 15,
            f'${int(height)}/mo',
            ha='center', va='bottom', fontweight='bold', fontsize=12)

# Panel 3: Capacity planning
ax7 = fig2.add_subplot(gs2[1, 0])
traffic_scenarios = ['Average\n(19 QPS)', 'Peak 3x\n(57 QPS)', 'Capacity\n(60 QPS)', 'Max\n(85 QPS)']
qps_values = [19, 57, 60, 85]
colors_capacity = ['#3498db', '#f39c12', '#27ae60', '#e74c3c']

bars_capacity = ax7.bar(traffic_scenarios, qps_values, color=colors_capacity, 
                       alpha=0.8, edgecolor='black', linewidth=1.5)
ax7.axhline(y=60, color='#27ae60', linestyle='--', linewidth=2, label='Safe Capacity (70%)')
ax7.set_ylabel('Queries Per Second', fontweight='bold', fontsize=11)
ax7.set_title('Capacity Planning for 50M Queries/Month\nProvision for 3x peak at 70% utilization', 
             fontweight='bold', fontsize=13)
ax7.legend(fontsize=10)
ax7.grid(axis='y', alpha=0.3)

for bar in bars_capacity:
    height = bar.get_height()
    ax7.text(bar.get_x() + bar.get_width()/2., height + 2,
            f'{int(height)} QPS',
            ha='center', va='bottom', fontweight='bold', fontsize=10)


plt.suptitle('Production Deployment Strategy & Cost Analysis', 
            fontsize=15, fontweight='bold', y=0.995)
plt.tight_layout()
plt.savefig('production_deployment.png', dpi=150, bbox_inches='tight')
print("📸 Saved: production_deployment.png")
plt.show()

# ============================================================================
# FINAL SUMMARY
# ============================================================================
print("\n" + "=" * 70)
print("✅ COMPREHENSIVE SUMMARY")
print("=" * 70)
print(f"""
1️⃣  CPU vs GPU:
   • CPU: {cpu_p95:.0f}ms p95 (your Mac) - use for real-time queries
   • GPU: ~{gpu_p95_simulated:.0f}ms p95 (simulated) - use for batch encoding
   • Decision: CPU for serving, GPU for offline indexing

2️⃣  Quantization:
   • Original: {original_size_mb:.0f}MB, {cpu_p95:.0f}ms p95
   • Quantized: {quantized_size_mb:.0f}MB, {quant_p95:.0f}ms p95
   • Benefit: 4x smaller, 2.5x faster with <1% accuracy loss

3️⃣  Caching:
   • Hit rate: {cached_model.hit_rate():.0%}
   • Speedup: {no_cache_time/cache_time:.1f}x faster
   • ROI: Reduces infrastructure by 3x (fewer instances needed)

4️⃣  Load Testing:
   • Max throughput: {max_qps:.1f} QPS
   • Recommended: {max_qps * 0.7:.1f} QPS (70% utilization)
   • For 50 QPS peak: {int(instances_needed + 1)} instances required

💡 PRODUCTION CHECKLIST:
✓ Benchmark on target hardware (CPU for queries)
✓ Consider quantization for mobile/edge
✓ Enable caching for popular queries (40%+ hit rate)
✓ Load test at 3x expected peak traffic
✓ Monitor p95 latency, not averages
✓ Plan for 70% utilization (headroom for spikes)

🚀 NEXT STEPS:
→ Module 3 Video 2: Cost analysis (compute + serving + storage)
→ Module 3 Video 3: Build decision frameworks for model selection
""")

print("=" * 70)
print("Demo Complete! ✅")
print("=" * 70)

