# Coursera: Validate LLM Embeddings

**Author:** Ritesh Vajariya

This repository contains demo code and examples for the "Validate LLM Embeddings" course. Learn how to generate, validate, and optimize embeddings for production use cases including semantic search, recommendation systems, and similarity-based retrieval.

## Course Overview

This course covers three main modules:

### Module 1: Generating and Validating Embeddings
- **m1v1.py** - Generating Embeddings with Sentence-Transformers
- **m1v2.py** - Building FAISS Index for Fast Similarity Search
- **m1v3.py** - Validating Recall with Test Query Sets

### Module 2: Visualization and Data Quality
- **m2v1.py** - UMAP Fundamentals for Embedding Visualization
- **m2v2.py** - Outlier Detection and Cluster Analysis
- **m2v3.py** - Data Cleanup Workflows from Cluster Analysis

### Module 3: Production Optimization
- **m3v1.py** - Performance Benchmarking and Latency Analysis
- **m3v2.py** - Cost Analysis (Compute, Storage, and API Pricing)
- **m3v3.py** - Model Selection Framework

## Prerequisites

- Python 3.8 or higher
- Basic knowledge of Python programming
- Understanding of machine learning concepts (helpful but not required)

## Setup Instructions

Follow these steps to set up your environment for running the course demos:

### Step 1: Clone the Repository

```bash
git clone https://github.com/desirit/coursera-validate-llm-embeddings.git
cd coursera-validate-llm-embeddings
```

### Step 2: Create a Virtual Environment

Creating a virtual environment helps isolate the project dependencies from your system Python installation.

**On macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**On Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

You should see `(venv)` in your terminal prompt, indicating the virtual environment is active.

### Step 3: Install Dependencies

With the virtual environment activated, install all required packages:

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

This will install:
- **sentence-transformers** - For generating embeddings
- **faiss-cpu** - For fast similarity search
- **numpy** - For numerical operations
- **pandas** - For data manipulation
- **matplotlib** - For creating visualizations
- **seaborn** - For enhanced visualizations
- **umap-learn** - For dimensionality reduction

### Step 4: Verify Installation

Test that everything is installed correctly:

```bash
python -c "import sentence_transformers; import faiss; import umap; print('All dependencies installed successfully!')"
```

If you see "All dependencies installed successfully!", you're ready to go!

## Running the Demos

Each Python file is a standalone demo that can be run independently. Navigate to the code directory and run any module:

```bash
# Example: Run Module 1, Video 1
python m1v1.py

# Example: Run Module 2, Video 1
python m2v1.py

# Example: Run Module 3, Video 2
python m3v2.py
```

### Demo Outputs

Most demos will:
1. Print step-by-step progress to the console
2. Generate visualization PNG files (e.g., `umap_visualization.png`, `cost_comparison.png`)
3. Save intermediate data files (e.g., `product_embeddings.npy`, `product_index.faiss`)

## What Each Module Teaches

### Module 1: Core Fundamentals
- How to generate embeddings using sentence-transformers
- Building and querying FAISS indexes for similarity search
- Measuring search quality with recall metrics
- Creating test query sets with ground truth labels

### Module 2: Quality Assurance
- Visualizing high-dimensional embeddings in 2D using UMAP
- Detecting outliers and problematic data points
- Identifying data quality issues through cluster analysis
- Implementing data cleanup workflows to improve recall

### Module 3: Production Readiness
- Benchmarking latency and throughput
- Analyzing cost tradeoffs (self-hosted vs. API)
- Comparing different embedding models
- Making informed decisions for production deployment

## Troubleshooting

### Issue: "Module not found" errors
**Solution:** Make sure your virtual environment is activated and dependencies are installed:
```bash
source venv/bin/activate  # On macOS/Linux
pip install -r requirements.txt
```

### Issue: FAISS installation fails on Mac M1/M2
**Solution:** Try installing with conda instead:
```bash
conda install -c pytorch faiss-cpu
```

### Issue: Out of memory errors
**Solution:** Some demos process large datasets. Try:
- Reducing batch sizes in the code
- Closing other applications
- Using a machine with more RAM

### Issue: Visualization windows don't appear
**Solution:** If running on a headless server, visualizations will save to PNG files automatically.

## Additional Resources

- [Sentence-Transformers Documentation](https://www.sbert.net/)
- [FAISS Documentation](https://github.com/facebookresearch/faiss)
- [UMAP Documentation](https://umap-learn.readthedocs.io/)

## Course Files Structure

```
.
├── README.md                           # This file
├── requirements.txt                    # Python dependencies
├── .gitignore                         # Git ignore rules
├── m1v1.py                            # Module 1, Video 1
├── m1v2.py                            # Module 1, Video 2
├── m1v3.py                            # Module 1, Video 3
├── m2v1.py                            # Module 2, Video 1
├── m2v2.py                            # Module 2, Video 2
├── m2v3.py                            # Module 2, Video 3
├── m3v1.py                            # Module 3, Video 1
├── m3v2.py                            # Module 3, Video 2
├── m3v3.py                            # Module 3, Video 3
├── *.png                              # Generated visualization files
├── *.npy                              # Saved embedding files
└── *.faiss                            # FAISS index files
```

## Getting Help

If you encounter issues:
1. Check the Troubleshooting section above
2. Review the error message carefully
3. Ensure all dependencies are installed correctly
4. Verify your Python version is 3.8 or higher

## License

This course material is provided for educational purposes.

## Feedback

We welcome your feedback! If you have suggestions or find issues, please reach out through the course platform.

---

**Happy Learning!**

Explore the power of embeddings and learn to build production-ready similarity search systems.
