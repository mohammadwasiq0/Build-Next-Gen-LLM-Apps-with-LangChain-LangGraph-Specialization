"""
Module 1, Video 2: Building FAISS Indices for Similarity Search
================================================================
Demo Duration: ~3 minutes
Author: Ritesh Vajariya

This script demonstrates:
1. Installing and importing FAISS
2. Creating a Flat L2 index for exact nearest-neighbor search
3. Adding embeddings to the index
4. Performing k-nearest neighbor searches
5. Interpreting distance scores and similarity rankings
6. Saving and loading indices for production

Run this in: Local Python environment, Google Colab, or Jupyter

# CPU version (recommended for most users)
pip install sentence-transformers faiss-cpu numpy

# Or GPU version (if you have CUDA)
pip install sentence-transformers faiss-gpu numpy

# For visual demo
pip install sentence-transformers faiss-cpu numpy matplotlib
"""

import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import time

# ============================================================================
# PART 1: Load Pre-generated Embeddings (15 seconds)
# ============================================================================
print("=" * 70)
print("PART 1: Loading Product Embeddings")
print("=" * 70)

# Generate embeddings for 5,000 products (simulating realistic catalog)
model = SentenceTransformer('all-MiniLM-L6-v2')

products = [
    "Dell XPS 15 laptop with 16GB RAM and 512GB SSD",
    "Samsung 27-inch 4K monitor with HDR support",
    "Sony WH-1000XM4 wireless noise-canceling headphones",
    "Logitech MX Master 3 wireless ergonomic mouse",
    "Apple MacBook Pro 14-inch with M2 chip",
    "LG UltraWide 34-inch curved gaming monitor",
    "Bose QuietComfort 45 wireless headphones",
    "Razer DeathAdder V2 gaming mouse",
    "HP Spectre x360 convertible laptop",
    "BenQ PD3220U 4K designer monitor"
] * 500  # 5,000 products total

print(f"Generating embeddings for {len(products)} products...")
embeddings = model.encode(products, batch_size=32, show_progress_bar=False)

print(f"✓ Embeddings generated: {embeddings.shape}")
print(f"  - {embeddings.shape[0]:,} products")
print(f"  - {embeddings.shape[1]} dimensions per product")
print(f"  - Data type: {embeddings.dtype}")
print()

# ============================================================================
# PART 2: Create FAISS Index (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 2: Creating FAISS IndexFlatL2")
print("=" * 70)

# Get embedding dimension
dimension = embeddings.shape[1]

# Create Flat L2 index (exact search using Euclidean distance)
index = faiss.IndexFlatL2(dimension)

print(f"✓ Index created: IndexFlatL2")
print(f"  - Index type: Flat (exact search, no compression)")
print(f"  - Distance metric: L2 (Euclidean distance)")
print(f"  - Dimension: {dimension}")
print(f"  - Current size: {index.ntotal} vectors")
print()

# ============================================================================
# PART 3: Add Embeddings to Index (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 3: Adding Embeddings to Index")
print("=" * 70)

# Add embeddings to index
start_time = time.time()
index.add(embeddings)
add_time = time.time() - start_time

print(f"✓ Added {len(embeddings):,} embeddings in {add_time:.3f} seconds")
print(f"  - Index now contains: {index.ntotal:,} vectors")
print(f"  - Memory usage: ~{(embeddings.nbytes / 1024**2):.1f} MB")
print()

# ============================================================================
# PART 4: Perform K-Nearest Neighbor Search (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 4: Searching with K-Nearest Neighbors")
print("=" * 70)

# Create a search query
query_text = "wireless headphones"
print(f"Query: '{query_text}'")
print()

# Encode the query
query_embedding = model.encode([query_text])

# Search for top 5 nearest neighbors
k = 5
start_time = time.time()
distances, indices = index.search(query_embedding, k)
search_time = time.time() - start_time

print(f"✓ Search completed in {search_time*1000:.2f} milliseconds")
print(f"  - Searched through {index.ntotal:,} vectors")
print(f"  - Returned top {k} results")
print()

# Display results
print("Top 5 Results:")
print("-" * 70)
for rank, (idx, distance) in enumerate(zip(indices[0], distances[0]), 1):
    print(f"{rank}. Product #{idx:,}")
    print(f"   Text: {products[idx][:65]}...")
    print(f"   Distance: {distance:.2f}")
    print()

# ============================================================================
# PART 5: Understanding Distance Scores (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 5: Interpreting Distance Scores")
print("=" * 70)

# Compare different queries to show distance patterns
queries = [
    "wireless headphones",
    "laptop computer", 
    "office furniture"  # Should have high distances (not in catalog)
]

print("Distance patterns for different queries:")
print("-" * 70)

for query_text in queries:
    query_emb = model.encode([query_text])
    D, I = index.search(query_emb, k=3)
    
    avg_distance = np.mean(D[0])
    min_distance = np.min(D[0])
    max_distance = np.max(D[0])
    
    print(f"\nQuery: '{query_text}'")
    print(f"  Top 3 distances: {D[0]}")
    print(f"  Min: {min_distance:.2f} | Avg: {avg_distance:.2f} | Max: {max_distance:.2f}")
    
    if avg_distance < 15:
        quality = "EXCELLENT - Strong matches found"
    elif avg_distance < 25:
        quality = "GOOD - Relevant results"
    elif avg_distance < 35:
        quality = "MODERATE - Some relevance"
    else:
        quality = "POOR - Weak matches (products may not exist)"
    
    print(f"  Match Quality: {quality}")

print()
print("→ Key Insight: Lower distances = better matches!")
print("→ Large distance gaps indicate confidence drops")
print()

# ============================================================================
# PART 6: Save and Load Index (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 6: Saving Index to Disk")
print("=" * 70)

# Save index to disk
index_filename = "product_index.faiss"
faiss.write_index(index, index_filename)

file_size = embeddings.nbytes / (1024**2)
print(f"✓ Index saved: {index_filename}")
print(f"  - File size: ~{file_size:.1f} MB")
print(f"  - Contains: {index.ntotal:,} vectors")
print()

# Demonstrate loading
loaded_index = faiss.read_index(index_filename)
print(f"✓ Index loaded from disk")
print(f"  - Vectors in loaded index: {loaded_index.ntotal:,}")
print(f"  - Index type: {type(loaded_index).__name__}")
print()

# Verify it works
test_query = model.encode(["laptop"])
D, I = loaded_index.search(test_query, k=3)
print(f"✓ Verification search successful")
print(f"  - Found {len(I[0])} results in {D[0][0]:.2f} to {D[0][-1]:.2f} distance range")
print()

# ============================================================================
# SUMMARY (25 seconds)
# ============================================================================
print("=" * 70)
print("DEMO SUMMARY")
print("=" * 70)
print(f"""
Key Takeaways:
1. ✓ FAISS IndexFlatL2: Exact nearest-neighbor search
2. ✓ Added {index.ntotal:,} vectors in {add_time:.3f} seconds
3. ✓ Search speed: {search_time*1000:.2f}ms through {index.ntotal:,} vectors
4. ✓ Distance scores: Lower = better match
5. ✓ Large gaps in distances signal confidence drops
6. ✓ Save once, load instantly for production

Performance Summary:
→ Index building: Instant for flat indices
→ Search latency: Sub-millisecond for 5K vectors
→ Memory efficient: ~{file_size:.1f}MB for 5K products
→ Production ready: Save/load workflow demonstrated

Next Steps:
→ Video 3: Validate recall with test query sets
→ Measure search quality quantitatively
→ Build automated regression testing
""")

print("=" * 70)
print("Demo Complete! ✓")
print("=" * 70)