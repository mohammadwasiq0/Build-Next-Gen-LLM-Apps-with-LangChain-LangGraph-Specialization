"""
Module 1, Video 1: Generating Embeddings with Sentence-Transformers
=====================================================================
Demo Duration: ~3 minutes
Author: Ritesh Vajariya

This script demonstrates:
1. Loading the all-MiniLM-L6-v2 model
2. Encoding a small product catalog into embeddings
3. Understanding embedding dimensions and shapes
4. Batch processing for efficiency
5. Saving embeddings to disk

Run this in: Local Python environment, Google Colab, or Jupyter

# Install dependencies
pip install sentence-transformers numpy

# Run the demo
python module1_video1_demo.py

"""

import numpy as np
from sentence_transformers import SentenceTransformer
import time

# ============================================================================
# PART 1: Load the Model (15 seconds)
# ============================================================================
print("=" * 70)
print("PART 1: Loading Sentence-Transformer Model")
print("=" * 70)

# Load all-MiniLM-L6-v2 model (downloads automatically first time)
model = SentenceTransformer('all-MiniLM-L6-v2')

print(f"✓ Model loaded: all-MiniLM-L6-v2")
print(f"  - Model size: ~80MB")
print(f"  - Parameters: 22 million")
print(f"  - Embedding dimensions: 384")
print()

# ============================================================================
# PART 2: Create Sample Product Catalog (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 2: Sample Product Catalog")
print("=" * 70)

products = [
    "Dell XPS 15 laptop with 16GB RAM and 512GB SSD, perfect for professional work",
    "Samsung 27-inch 4K monitor with HDR support and USB-C connectivity",
    "Sony WH-1000XM4 wireless noise-canceling headphones with 30-hour battery life",
    "Logitech MX Master 3 wireless mouse with ergonomic design and precision tracking",
    "Cotton blend crew neck t-shirt in navy blue, comfortable casual wear"
]

print(f"Products in catalog: {len(products)}")
for i, product in enumerate(products, 1):
    print(f"  {i}. {product[:60]}...")
print()

# ============================================================================
# PART 3: Generate Embeddings (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 3: Generating Embeddings")
print("=" * 70)

# Encode products into embeddings
start_time = time.time()
embeddings = model.encode(products)
encoding_time = time.time() - start_time

print(f"✓ Embeddings generated in {encoding_time:.3f} seconds")
print(f"  - Shape: {embeddings.shape}")
print(f"  - {embeddings.shape[0]} products × {embeddings.shape[1]} dimensions")
print()

# Show what an embedding looks like (first 10 values)
print(f"Sample embedding (first 10 values of product 1):")
print(f"  {embeddings[0][:10]}")
print(f"  ... (374 more values)")
print()

# ============================================================================
# PART 4: Understanding Semantic Similarity (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 4: Semantic Similarity in Action")
print("=" * 70)

# Calculate cosine similarity between products
from numpy.linalg import norm

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    return np.dot(vec1, vec2) / (norm(vec1) * norm(vec2))

# Compare laptop with monitor (related electronics)
sim_laptop_monitor = cosine_similarity(embeddings[0], embeddings[1])

# Compare laptop with t-shirt (unrelated)
sim_laptop_tshirt = cosine_similarity(embeddings[0], embeddings[4])

# Compare headphones with mouse (both peripherals)
sim_headphones_mouse = cosine_similarity(embeddings[2], embeddings[3])

print(f"Similarity Scores (0 to 1, higher = more similar):")
print(f"  Laptop ↔ Monitor:    {sim_laptop_monitor:.3f} (related electronics)")
print(f"  Laptop ↔ T-shirt:    {sim_laptop_tshirt:.3f} (unrelated)")
print(f"  Headphones ↔ Mouse:  {sim_headphones_mouse:.3f} (both peripherals)")
print()
print("→ Notice: Related items have higher similarity scores!")
print()

# ============================================================================
# PART 5: Batch Processing for Production (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 5: Batch Processing for Larger Catalogs")
print("=" * 70)

# Simulate a larger catalog
large_catalog = products * 1000  # 5,000 products

print(f"Processing {len(large_catalog)} products...")

# Encode with batch processing
start_time = time.time()
large_embeddings = model.encode(
    large_catalog, 
    batch_size=32,  # Process 32 at a time
    show_progress_bar=False
)
batch_time = time.time() - start_time

print(f"✓ Encoded {len(large_catalog)} products in {batch_time:.2f} seconds")
print(f"  - Throughput: {len(large_catalog)/batch_time:.0f} products/second")
print(f"  - Final shape: {large_embeddings.shape}")
print()

# ============================================================================
# PART 6: Saving Embeddings to Disk (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 6: Saving Embeddings for Production Use")
print("=" * 70)

# Save embeddings
np.save('product_embeddings.npy', embeddings)
file_size_mb = embeddings.nbytes / (1024 * 1024)

print(f"✓ Embeddings saved to: product_embeddings.npy")
print(f"  - File size: {file_size_mb:.2f} MB")
print(f"  - Contains {len(embeddings)} products")
print()

# Demonstrate loading
loaded_embeddings = np.load('product_embeddings.npy')
print(f"✓ Embeddings loaded from disk")
print(f"  - Loaded shape: {loaded_embeddings.shape}")
print(f"  - Verification: {np.array_equal(embeddings, loaded_embeddings)}")
print()

# ============================================================================
# SUMMARY (25 seconds)
# ============================================================================
print("=" * 70)
print("DEMO SUMMARY")
print("=" * 70)
print("""
Key Takeaways:
1. ✓ Sentence-transformers converts text → 384-dimensional vectors
2. ✓ Semantic similarity captured: laptop closer to monitor than t-shirt
3. ✓ Model: all-MiniLM-L6-v2 - fast, efficient, production-ready
4. ✓ Batch processing: ~{:.0f} products/second
5. ✓ Save once, reuse many times in production

Next Steps:
→ Video 2: Build FAISS index for fast similarity search
→ Video 3: Validate recall with test query sets
""".format(len(large_catalog)/batch_time))

print("=" * 70)
print("Demo Complete! ✓")
print("=" * 70)