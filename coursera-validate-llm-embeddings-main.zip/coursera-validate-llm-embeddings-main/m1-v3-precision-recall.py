"""
Module 1, Video 3: Validating Recall with Test Query Sets
===========================================================
Demo Duration: ~3 minutes
Author: Ritesh Vajariya

This script demonstrates:
1. Creating representative test query sets
2. Defining ground truth relevance labels
3. Calculating recall@k metrics (recall@5 and recall@10)
4. Analyzing failure cases and patterns
5. Comparing different embedding models on recall

Run this in: Local Python environment, Google Colab, or Jupyter

pip install sentence-transformers faiss-cpu numpy

# For visual demo
pip install sentence-transformers faiss-cpu numpy matplotlib

"""

import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
from collections import defaultdict

# ============================================================================
# PART 1: Setup - Product Catalog and Index (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 1: Building Product Search System")
print("=" * 70)

# Realistic e-commerce product catalog
products = [
    # Laptops (IDs 0-4)
    "Dell XPS 15 laptop with 16GB RAM and 512GB SSD for professional work",
    "Apple MacBook Pro 14-inch with M2 chip and 16GB memory",
    "HP Spectre x360 convertible touchscreen laptop 13-inch",
    "Lenovo ThinkPad X1 Carbon business laptop with 16GB RAM",
    "ASUS ROG gaming laptop with RTX 4070 graphics card",
    
    # Monitors (IDs 5-9)
    "Samsung 27-inch 4K UHD monitor with HDR400 support",
    "LG UltraWide 34-inch curved monitor for productivity",
    "Dell UltraSharp 32-inch 4K IPS professional monitor",
    "BenQ PD3220U designer monitor with color calibration",
    "ASUS TUF Gaming 27-inch 165Hz monitor",
    
    # Headphones (IDs 10-14)
    "Sony WH-1000XM4 wireless noise-canceling headphones",
    "Bose QuietComfort 45 Bluetooth headphones with ANC",
    "Apple AirPods Pro with active noise cancellation",
    "Sennheiser HD 660S open-back audiophile headphones",
    "HyperX Cloud Alpha gaming headset with mic",
    
    # Mice (IDs 15-19)
    "Logitech MX Master 3 wireless ergonomic mouse",
    "Razer DeathAdder V2 gaming mouse with 20K DPI",
    "Apple Magic Mouse 2 rechargeable wireless",
    "Microsoft Surface Precision Mouse",
    "Logitech G Pro X Superlight wireless gaming mouse",
    
    # Other electronics (IDs 20-24)
    "iPhone 14 Pro smartphone with 256GB storage",
    "Samsung Galaxy S23 Ultra phone with S Pen",
    "Canon EOS R6 mirrorless camera body",
    "Sony A7 IV full-frame mirrorless camera",
    "GoPro Hero 11 Black action camera",
]

print(f"Products in catalog: {len(products)}")

# Generate embeddings
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(products, show_progress_bar=False)

# Build FAISS index
dimension = embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(embeddings)

print(f"✓ Index built with {index.ntotal} products")
print(f"✓ Embedding model: all-MiniLM-L6-v2 (384 dimensions)")
print()

# ============================================================================
# PART 2: Create Test Query Set with Ground Truth (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 2: Test Query Set with Ground Truth Labels")
print("=" * 70)

# Define test queries with ground truth (which products are relevant)
test_queries = {
    "laptop for work": {
        "relevant_ids": [0, 1, 2, 3],  # All work laptops, not gaming
        "category": "laptop"
    },
    "gaming computer": {
        "relevant_ids": [4],  # Gaming laptop only
        "category": "laptop"
    },
    "wireless headphones": {
        "relevant_ids": [10, 11, 12],  # Wireless headphones
        "category": "headphones"
    },
    "noise canceling headphones": {
        "relevant_ids": [10, 11, 12],  # ANC headphones
        "category": "headphones"
    },
    "4K monitor": {
        "relevant_ids": [5, 7, 8],  # 4K monitors
        "category": "monitor"
    },
    "gaming mouse": {
        "relevant_ids": [16, 19],  # Gaming mice
        "category": "mouse"
    },
    "ergonomic mouse": {
        "relevant_ids": [15, 18],  # Ergonomic mice
        "category": "mouse"
    },
    "professional camera": {
        "relevant_ids": [22, 23],  # Pro cameras
        "category": "camera"
    },
}

print(f"Test queries created: {len(test_queries)}")
print("\nExample test queries:")
for i, (query, info) in enumerate(list(test_queries.items())[:3], 1):
    print(f"{i}. '{query}' → {len(info['relevant_ids'])} relevant products")
print()

# ============================================================================
# PART 3: Calculate Recall@K Metrics (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 3: Calculating Recall@5, Recall@10, Precision@5, Precision@10")
print("=" * 70)

def calculate_recall(retrieved_ids, relevant_ids):
    """Calculate recall: how many relevant items were found"""
    retrieved_set = set(retrieved_ids)
    relevant_set = set(relevant_ids)
    
    hits = len(retrieved_set.intersection(relevant_set))
    total_relevant = len(relevant_set)
    
    if total_relevant == 0:
        return 0.0
    
    return hits / total_relevant

def calculate_precision(retrieved_ids, relevant_ids):
    """Calculate precision: how many retrieved items are relevant"""
    retrieved_set = set(retrieved_ids)
    relevant_set = set(relevant_ids)
    
    hits = len(retrieved_set.intersection(relevant_set))
    total_retrieved = len(retrieved_ids)
    
    if total_retrieved == 0:
        return 0.0
    
    return hits / total_retrieved

# Run all test queries and measure recall and precision
recall_at_5_scores = []
recall_at_10_scores = []
precision_at_5_scores = []
precision_at_10_scores = []
detailed_results = []

print("Running test queries...")
print("-" * 70)

for query_text, ground_truth in test_queries.items():
    # Encode query
    query_embedding = model.encode([query_text])
    
    # Search for top 10 results
    D, I = index.search(query_embedding, k=10)
    retrieved_ids = I[0].tolist()
    
    # Calculate recall@5, recall@10, precision@5, precision@10
    recall_5 = calculate_recall(retrieved_ids[:5], ground_truth['relevant_ids'])
    recall_10 = calculate_recall(retrieved_ids[:10], ground_truth['relevant_ids'])
    precision_5 = calculate_precision(retrieved_ids[:5], ground_truth['relevant_ids'])
    precision_10 = calculate_precision(retrieved_ids[:10], ground_truth['relevant_ids'])
    
    recall_at_5_scores.append(recall_5)
    recall_at_10_scores.append(recall_10)
    precision_at_5_scores.append(precision_5)
    precision_at_10_scores.append(precision_10)
    
    detailed_results.append({
        'query': query_text,
        'category': ground_truth['category'],
        'total_relevant': len(ground_truth['relevant_ids']),
        'recall@5': recall_5,
        'recall@10': recall_10,
        'precision@5': precision_5,
        'precision@10': precision_10,
        'retrieved_top5': retrieved_ids[:5]
    })
    
    # Show first 3 examples
    if len(detailed_results) <= 3:
        print(f"\nQuery: '{query_text}'")
        print(f"  Ground truth: {len(ground_truth['relevant_ids'])} relevant products")
        print(f"  Recall@5:     {recall_5:.1%} ({int(recall_5 * len(ground_truth['relevant_ids']))}/{len(ground_truth['relevant_ids'])} found)")
        print(f"  Recall@10:    {recall_10:.1%} ({int(recall_10 * len(ground_truth['relevant_ids']))}/{len(ground_truth['relevant_ids'])} found)")
        print(f"  Precision@5:  {precision_5:.1%} ({int(precision_5 * 5)}/5 relevant)")
        print(f"  Precision@10: {precision_10:.1%} ({int(precision_10 * 10)}/10 relevant)")

# Calculate overall metrics
avg_recall_5 = np.mean(recall_at_5_scores)
avg_recall_10 = np.mean(recall_at_10_scores)
avg_precision_5 = np.mean(precision_at_5_scores)
avg_precision_10 = np.mean(precision_at_10_scores)

print()
print("=" * 70)
print("OVERALL RESULTS")
print("=" * 70)
print(f"Average Recall@5:     {avg_recall_5:.1%}")
print(f"Average Recall@10:    {avg_recall_10:.1%}")
print(f"Average Precision@5:  {avg_precision_5:.1%}")
print(f"Average Precision@10: {avg_precision_10:.1%}")
print(f"Total queries tested: {len(test_queries)}")
print()

# ============================================================================
# PART 4: Analyze Failure Cases (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 4: Failure Pattern Analysis")
print("=" * 70)

# Categorize results by performance
excellent = [r for r in detailed_results if r['recall@5'] >= 0.8]
good = [r for r in detailed_results if 0.5 <= r['recall@5'] < 0.8]
poor = [r for r in detailed_results if r['recall@5'] < 0.5]

print(f"\nPerformance Distribution:")
print(f"  Excellent (≥80% recall@5): {len(excellent)} queries")
print(f"  Good (50-79% recall@5):     {len(good)} queries")
print(f"  Poor (<50% recall@5):       {len(poor)} queries")
print()

# Identify failure patterns
if poor:
    print("Low-Performing Queries:")
    print("-" * 70)
    for result in poor:
        print(f"  • '{result['query']}' → {result['recall@5']:.1%} recall@5")
        print(f"    Category: {result['category']} | {result['total_relevant']} relevant products")
    print()

# Analyze by category
category_performance = defaultdict(list)
for result in detailed_results:
    category_performance[result['category']].append(result['recall@5'])

print("Performance by Category:")
print("-" * 70)
for category, scores in sorted(category_performance.items()):
    avg_score = np.mean(scores)
    print(f"  {category.capitalize():15} → {avg_score:.1%} avg recall@5 ({len(scores)} queries)")
print()

# ============================================================================
# PART 5: Insights and Recommendations (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 5: Key Insights")
print("=" * 70)

# Determine what issues exist
issues_found = []

if avg_recall_5 < 0.7:
    issues_found.append("Overall recall@5 below 70% - needs improvement")

if poor:
    issues_found.append(f"{len(poor)} queries performing poorly (<50% recall)")

# Check for category imbalances
category_scores = {cat: np.mean(scores) for cat, scores in category_performance.items()}
min_category = min(category_scores, key=category_scores.get)
max_category = max(category_scores, key=category_scores.get)

if category_scores[max_category] - category_scores[min_category] > 0.3:
    issues_found.append(f"Category imbalance: {min_category} ({category_scores[min_category]:.1%}) vs {max_category} ({category_scores[max_category]:.1%})")

if issues_found:
    print("Issues Identified:")
    for i, issue in enumerate(issues_found, 1):
        print(f"  {i}. {issue}")
    print()
    
    print("Recommended Actions:")
    print("  → Investigate poor-performing queries for patterns")
    print("  → Check if ground truth labels are accurate")
    print("  → Consider data augmentation for weak categories")
    print("  → Test alternative embedding models")
else:
    print(f"✓ System performing well: {avg_recall_5:.1%} recall@5")
    print("  → No major issues detected")
    print("  → Ready for production deployment")

print()

# ============================================================================
# SUMMARY (20 seconds)
# ============================================================================
print("=" * 70)
print("DEMO SUMMARY")
print("=" * 70)
print(f"""
Recall & Precision Validation Results:
1. ✓ Tested {len(test_queries)} queries across {len(category_performance)} categories
2. ✓ Average Recall@5:     {avg_recall_5:.1%}
3. ✓ Average Recall@10:    {avg_recall_10:.1%}
4. ✓ Average Precision@5:  {avg_precision_5:.1%}
5. ✓ Average Precision@10: {avg_precision_10:.1%}
6. ✓ {len(excellent)} excellent, {len(good)} good, {len(poor)} poor performing queries

Key Formulas:
  Recall@k    = (Relevant items found in top-k) / (Total relevant items)
  Precision@k = (Relevant items found in top-k) / (k items retrieved)

Example - "laptop for work" query:
  4 relevant products exist in catalog
  System returns 3 relevant + 2 irrelevant in top-5 results
  Recall@5    = 3/4 = 75%  (found 3 out of 4 relevant)
  Precision@5 = 3/5 = 60%  (3 out of 5 retrieved are relevant)

Why BOTH Matter:
→ Recall:    "Did we find everything the user needs?"
→ Precision: "Is what we showed them actually relevant?"
→ Trade-off: You can get 100% recall by returning everything,
             but precision will be terrible!

Why This Matters:
→ You can't improve what you don't measure
→ Recall+Precision reveal different quality dimensions
→ Systematic testing catches problems before users do
→ Baseline metrics essential for A/B testing new models

Next Steps:
→ Build automated regression testing
→ Create alerting for recall/precision degradation
→ Iterate on model selection and data quality
""")

print("=" * 70)
print("Demo Complete! ✓")
print("=" * 70)