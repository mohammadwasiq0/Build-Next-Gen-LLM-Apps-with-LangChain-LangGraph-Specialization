"""
Module 2, Video 2: Identifying Anomalous Clusters and Outliers
===============================================================
Demo Duration: ~3 minutes
Author: Ritesh Vajariya

This script demonstrates:
1. Visual patterns indicating healthy vs problematic embeddings
2. Using DBSCAN to automatically detect outliers
3. Color-coding strategies to validate semantic coherence
4. Calculating quantitative metrics (silhouette scores)
5. Building systematic workflow for diagnosing quality issues

Run this in: Local Python environment, Google Colab, or Jupyter
"""

import numpy as np
from sentence_transformers import SentenceTransformer
import umap
from sklearn.cluster import DBSCAN
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
from collections import Counter

# ============================================================================
# PART 1: Create Dataset with Quality Issues (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 1: Creating Product Dataset with Known Issues")
print("=" * 70)

# Realistic catalog with intentional quality problems
products_good = {
    "Electronics": [
        "Dell XPS 15 laptop with 16GB RAM professional workstation",
        "MacBook Pro 14-inch M2 chip for developers",
        "Lenovo ThinkPad X1 Carbon business ultrabook",
        "HP Spectre x360 convertible touchscreen laptop",
        "ASUS ROG gaming laptop RTX 4070 graphics",
    ],
    "Furniture": [
        "Herman Miller Aeron ergonomic office chair mesh",
        "Standing desk electric adjustable height workstation",
        "IKEA desk computer table white minimalist",
        "Executive office chair leather high back",
        "L-shaped corner desk large workspace surface",
    ],
    "Kitchen": [
        "KitchenAid stand mixer 5-quart professional",
        "Ninja blender professional 1000W food processor",
        "Instant Pot pressure cooker 8-quart capacity",
        "Cuisinart coffee maker programmable 12-cup",
        "Vitamix high-performance blender smoothies",
    ],
}

# INTENTIONAL PROBLEMS: Poor quality products
products_bad = [
    "Product",  # Missing description - outlier
    "N/A",  # Missing description - outlier
    "Item for sale",  # Generic description - outlier
    "High quality product great value",  # Template text - outlier
    "NEW ITEM AVAILABLE NOW CLICK HERE",  # Spam-like - outlier
]

# Flatten good products
all_products = []
categories = []
quality_labels = []  # Track which are good vs bad

for category, items in products_good.items():
    all_products.extend(items)
    categories.extend([category] * len(items))
    quality_labels.extend(["Good"] * len(items))

# Add bad products
all_products.extend(products_bad)
categories.extend(["Unknown"] * len(products_bad))
quality_labels.extend(["Poor"] * len(products_bad))

print(f"Total products: {len(all_products)}")
print(f"  - Good quality: {quality_labels.count('Good')}")
print(f"  - Poor quality: {quality_labels.count('Poor')} (intentional problems)")
print()

print("Poor quality examples:")
for i, prod in enumerate(products_bad, 1):
    print(f"  {i}. '{prod}' ← Problem: Missing/generic description")
print()

# ============================================================================
# PART 2: Generate Embeddings and UMAP (20 seconds)
# ============================================================================
print("=" * 70)
print("PART 2: Generating Embeddings and UMAP Visualization")
print("=" * 70)

model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(all_products, show_progress_bar=False)

print(f"✓ Embeddings generated: {embeddings.shape}")

# Apply UMAP
reducer = umap.UMAP(n_neighbors=5, min_dist=0.1, random_state=42)
embedding_2d = reducer.fit_transform(embeddings)

print(f"✓ UMAP complete: {embedding_2d.shape}")
print()

# ============================================================================
# PART 3: Apply DBSCAN for Outlier Detection (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 3: Detecting Outliers with DBSCAN")
print("=" * 70)

print("What is DBSCAN?")
print("  - Density-Based Spatial Clustering")
print("  - Automatically finds outliers (noise points)")
print("  - Points labeled -1 are outliers")
print()

# Apply DBSCAN
dbscan = DBSCAN(eps=0.5, min_samples=3)
cluster_labels = dbscan.fit_predict(embedding_2d)

# Count outliers
outlier_mask = cluster_labels == -1
num_outliers = outlier_mask.sum()
num_normal = (~outlier_mask).sum()

print(f"DBSCAN Results:")
print(f"  - Normal points: {num_normal}")
print(f"  - Outliers detected: {num_outliers}")
print(f"  - Outlier percentage: {num_outliers/len(all_products)*100:.1f}%")
print()

# Check which categories have outliers
print("Outliers by original category:")
print("-" * 70)
outlier_categories = [categories[i] for i in range(len(categories)) if outlier_mask[i]]
category_counts = Counter(outlier_categories)
for cat, count in category_counts.most_common():
    print(f"  {cat}: {count} outliers")
print()

# List the actual outlier products
print("Detected outlier products:")
print("-" * 70)
for i, is_outlier in enumerate(outlier_mask):
    if is_outlier:
        quality = quality_labels[i]
        marker = "✓" if quality == "Poor" else "⚠"
        print(f"{marker} Product #{i}: '{all_products[i][:50]}'")
        print(f"   Original category: {categories[i]} | Quality: {quality}")
print()

# ============================================================================
# PART 4: Visualize with Outlier Highlighting (40 seconds)
# ============================================================================
print("=" * 70)
print("PART 4: Creating Outlier Visualization")
print("=" * 70)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))

# LEFT PLOT: Color by original category
category_colors = {
    "Electronics": "#3498db",
    "Furniture": "#2ecc71",
    "Kitchen": "#e74c3c",
    "Unknown": "#95a5a6"
}

for category in products_good.keys():
    mask = np.array(categories) == category
    ax1.scatter(
        embedding_2d[mask, 0],
        embedding_2d[mask, 1],
        c=category_colors[category],
        label=category,
        alpha=0.7,
        s=100,
        edgecolors='black',
        linewidth=0.5
    )

# Add unknown/bad products
mask_unknown = np.array(categories) == "Unknown"
ax1.scatter(
    embedding_2d[mask_unknown, 0],
    embedding_2d[mask_unknown, 1],
    c=category_colors["Unknown"],
    label="Poor Quality",
    alpha=0.7,
    s=100,
    edgecolors='red',
    linewidth=2
)

ax1.set_xlabel('UMAP Dimension 1', fontsize=11, fontweight='bold')
ax1.set_ylabel('UMAP Dimension 2', fontsize=11, fontweight='bold')
ax1.set_title('Before DBSCAN: Original Categories\n(Red borders = known poor quality)', 
              fontsize=12, fontweight='bold')
ax1.legend(loc='best', fontsize=9)
ax1.grid(True, alpha=0.3)

# RIGHT PLOT: Color by DBSCAN outlier status
colors_dbscan = ['#e74c3c' if label == -1 else '#95a5a6' for label in cluster_labels]
sizes = [150 if label == -1 else 80 for label in cluster_labels]

ax2.scatter(
    embedding_2d[:, 0],
    embedding_2d[:, 1],
    c=colors_dbscan,
    s=sizes,
    alpha=0.7,
    edgecolors='black',
    linewidth=1
)

# Add legend
from matplotlib.lines import Line2D
legend_elements = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#95a5a6', 
           markersize=8, label='Normal Points'),
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#e74c3c', 
           markersize=10, label='Outliers (DBSCAN)', markeredgecolor='black', markeredgewidth=1)
]
ax2.legend(handles=legend_elements, loc='best', fontsize=9)

ax2.set_xlabel('UMAP Dimension 1', fontsize=11, fontweight='bold')
ax2.set_ylabel('UMAP Dimension 2', fontsize=11, fontweight='bold')
ax2.set_title(f'After DBSCAN: Automatic Outlier Detection\n({num_outliers} outliers found)', 
              fontsize=12, fontweight='bold')
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('outlier_detection.png', dpi=150, bbox_inches='tight')
print("✓ Visualization saved: outlier_detection.png")
print()
plt.show()

# ============================================================================
# PART 5: Calculate Cluster Quality Metrics (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 5: Quantitative Quality Metrics")
print("=" * 70)

# Calculate silhouette score (excluding outliers)
normal_embeddings = embedding_2d[~outlier_mask]
normal_categories = [categories[i] for i in range(len(categories)) if not outlier_mask[i]]

# Need numeric labels for silhouette score
category_to_num = {cat: i for i, cat in enumerate(products_good.keys())}
numeric_labels = [category_to_num.get(cat, -1) for cat in normal_categories]
numeric_labels = np.array([l for l in numeric_labels if l != -1])
valid_embeddings = normal_embeddings[[l != -1 for l in [category_to_num.get(cat, -1) for cat in normal_categories]]]

if len(set(numeric_labels)) > 1:
    sil_score = silhouette_score(valid_embeddings, numeric_labels)
    print(f"Silhouette Score (normal points only): {sil_score:.3f}")
    
    if sil_score > 0.5:
        interpretation = "EXCELLENT - Strong, well-separated clusters"
    elif sil_score > 0.3:
        interpretation = "GOOD - Clear cluster structure"
    elif sil_score > 0.1:
        interpretation = "MODERATE - Some cluster structure"
    else:
        interpretation = "POOR - Weak clustering"
    
    print(f"  Interpretation: {interpretation}")
    print()

# Calculate detection accuracy
true_poor = sum(1 for q in quality_labels if q == "Poor")
detected_poor = sum(1 for i, is_out in enumerate(outlier_mask) if is_out and quality_labels[i] == "Poor")
false_positive = sum(1 for i, is_out in enumerate(outlier_mask) if is_out and quality_labels[i] == "Good")

print("Detection Performance:")
print(f"  - Total poor quality items: {true_poor}")
print(f"  - Correctly detected: {detected_poor} ({detected_poor/true_poor*100:.0f}%)")
print(f"  - False positives: {false_positive}")
print()

# ============================================================================
# PART 6: Diagnostic Workflow (30 seconds)
# ============================================================================
print("=" * 70)
print("PART 6: Systematic Diagnostic Workflow")
print("=" * 70)

print("Step-by-step process for production:")
print("-" * 70)
print()

print("STEP 1: Visual Inspection")
print("  → Run UMAP visualization")
print("  → Look for scattered points")
print("  → Check for unexpected category mixing")
print()

print("STEP 2: Automatic Detection")
print("  → Apply DBSCAN (eps=0.5, min_samples=3)")
print("  → Flag outliers (label=-1)")
print(f"  → Found {num_outliers} outliers ({num_outliers/len(all_products)*100:.1f}%)")
print()

print("STEP 3: Root Cause Analysis")
print("  → Sample outlier products")
print("  → Check common patterns:")
if num_outliers > 0:
    print(f"    • {sum(1 for i, is_out in enumerate(outlier_mask) if is_out and len(all_products[i]) < 20)} have very short descriptions")
    print(f"    • {sum(1 for i, is_out in enumerate(outlier_mask) if is_out and categories[i] == 'Unknown')} from 'Unknown' category")
print()

print("STEP 4: Prioritize Fixes")
print("  → High impact: Products in multiple searches")
print("  → Quick wins: Missing descriptions")
print("  → Systematic: Category-wide issues")
print()

print("STEP 5: Measure Improvement")
print("  → Re-embed after fixes")
print("  → Re-run UMAP + DBSCAN")
print("  → Track outlier percentage over time")
print()

# ============================================================================
# SUMMARY (20 seconds)
# ============================================================================
print("=" * 70)
print("DEMO SUMMARY")
print("=" * 70)
print(f"""
Outlier Detection Complete:
1. ✓ Created dataset with {len(all_products)} products ({true_poor} with quality issues)
2. ✓ Applied DBSCAN: Found {num_outliers} outliers
3. ✓ Detection accuracy: {detected_poor}/{true_poor} poor quality items found
4. ✓ Silhouette score: {sil_score:.3f} (good cluster quality)

Key Insights:
→ DBSCAN automates what your eye sees in UMAP
→ Outliers cluster at -1, normal points cluster by category
→ Visual + automatic detection catches issues early
→ Silhouette score quantifies cluster quality

Red Flags to Watch For:
✗ Outlier % > 10% → Systematic data quality issues
✗ False positives → DBSCAN parameters need tuning
✗ Category mixing → Wrong embedding model or poor descriptions
✗ Silhouette < 0.3 → Weak semantic clustering

Production Workflow:
→ Run weekly or after catalog updates
→ Alert if outlier % increases by >5%
→ Sample outliers manually for root cause
→ Fix and re-measure

Next Steps:
→ Video 3: Build data cleanup workflows
→ Implement automated quality monitoring
→ Set up regression testing
""")

print("=" * 70)