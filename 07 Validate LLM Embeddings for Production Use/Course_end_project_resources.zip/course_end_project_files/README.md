# Course-End Project - Resource Files

## Project Overview: GlobalRetail E-commerce Platform

**Scenario**: You're the lead ML engineer at GlobalRetail, the world's 3rd-largest e-commerce platform
- **Scale**: 50 million products (this is a 10K sample)
- **Traffic**: 500 million monthly searches
- **Business Impact**: $2M infrastructure investment decision
- **Success Goal**: Improve satisfaction from 61% to 75%

## Files Included:

### 1. globalretail_products.csv (10,000 products)
- **Description**: Representative sample of GlobalRetail's product catalog
- **Columns**:
  - `product_id`: Unique identifier (GR000001-GR010000)
  - `title`: Product title with brand, type, and color
  - `description`: Product description (85% detailed, 10% mediocre, 5% poor quality - realistic data)
  - `category`: Product category (10 categories: Laptops, Phones, Headphones, Cameras, Tablets, Smartwatches, Speakers, Monitors, Keyboards, Mice)
  - `price`: Price in USD
  - `rating`: Average customer rating (3.5-5.0)
  - `reviews_count`: Number of customer reviews

**Data Quality Notes:**
- 85% of products have high-quality, detailed descriptions
- 10% have mediocre descriptions (simulating inconsistent data entry)
- 5% have very poor descriptions (data quality issues for you to discover via UMAP)

### 2. globalretail_test_queries.csv (100 queries)
- **Description**: Comprehensive test query set covering all product categories
- **Columns**:
  - `query_id`: Unique identifier (GQ001-GQ100)
  - `query_text`: Search query reflecting real user search patterns
  - `category`: Expected category
  - `relevant_product_ids`: Comma-separated ground truth (8-12 relevant products per query)

**Query Coverage:**
- 10 queries per category (balanced coverage)
- Mix of simple ("gaming laptop") and complex ("waterproof bluetooth headphones running") queries
- Reflects real user search patterns from e-commerce platforms

## Project Phases (60 minutes):

### Phase 1: Baseline Embedding System (12 min)
- Load and clean product data
- Generate embeddings with all-MiniLM-L6-v2
- Build FAISS index
- Calculate baseline recall@5 and recall@10
- **Target**: Achieve 65%+ recall@10 (vs 51% keyword baseline)

### Phase 2: Data Quality Analysis (12 min)
- Generate UMAP 2D visualization
- Apply DBSCAN for outlier detection
- Analyze outlier patterns (short descriptions, specific vendors)
- Formulate 3+ testable hypotheses with evidence
- **Target**: Identify 3+ data quality issues with quantitative proof

### Phase 3: Multi-Model Benchmarking (15 min)
- Benchmark 3 models: all-mpnet-base-v2, all-MiniLM-L6-v2, gte-small
- Measure accuracy (recall@5, recall@10, MRR)
- Measure latency (p50, p95, p99)
- Calculate TCO (one-time + monthly costs)
- **Target**: Comprehensive comparison with clear recommendation

### Phase 4: Production Architecture (10 min)
- Design infrastructure for 50M products, 500M queries/month
- Specify sharding, caching, load balancing
- Define monitoring metrics and alerts
- Plan gradual rollout strategy
- **Target**: Scalable architecture with cost estimates

### Phase 5: Weighted Decision Matrix (6 min)
- Define criteria: Accuracy 35%, Latency 30%, Cost 25%, Complexity 10%
- Score each model objectively
- Calculate weighted rankings
- **Target**: Clear winner with defensible reasoning

### Phase 6: Executive Recommendation (5 min)
- Quantify business impact ($210M revenue protection)
- Calculate ROI (target: <6 month payback)
- Document risks and mitigation
- **Target**: Board-ready presentation (8-12 slides or 2500-3500 words)

## Example Code (Phase 1 - Baseline System):

```python
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

# Load data
products = pd.read_csv('globalretail_products.csv')
test_queries = pd.read_csv('globalretail_test_queries.csv')

# Clean data
products['combined_text'] = products['title'] + " " + products['description']
products['combined_text'] = products['combined_text'].fillna('')

# Generate embeddings
model = SentenceTransformer('all-MiniLM-L6-v2')
embeddings = model.encode(products['combined_text'].tolist(), show_progress_bar=True)

# Build FAISS index
index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(embeddings.astype('float32'))

# Calculate recall@10
test_queries['relevant_ids'] = test_queries['relevant_product_ids'].str.split(',')

recalls_at_10 = []
for _, row in test_queries.iterrows():
    query_emb = model.encode([row['query_text']])
    D, I = index.search(query_emb.astype('float32'), 10)
    
    retrieved = set(products.iloc[I[0]]['product_id'].tolist())
    relevant = set(row['relevant_ids'])
    
    recall = len(retrieved & relevant) / len(relevant)
    recalls_at_10.append(recall)

print(f"Average Recall@10: {np.mean(recalls_at_10):.3f}")
print(f"Target: >0.65 (65%)")
```

## Success Criteria:

✅ **Phase 1**: Recall@10 improvement: 51% → 65%+ (14+ percentage points)
✅ **Phase 2**: 3+ data quality issues identified with quantitative evidence
✅ **Phase 3**: 3 models benchmarked comprehensively
✅ **Phase 4**: Production architecture scales to 50M products, 500M queries/month
✅ **Phase 5**: Clear model recommendation with weighted decision matrix
✅ **Phase 6**: Executive presentation with $210M revenue impact, ROI calculation

## Deliverables:

1. **Production-Quality Python Codebase** - Complete implementation of all phases
2. **Data Quality Analysis Report** - UMAP visualization + 3+ hypotheses
3. **Model Comparison Matrix** - Comprehensive benchmarking results
4. **Executive Presentation** - Board-ready recommendation with ROI
5. **Monitoring Dashboard Specification** - KPIs, alerts, validation strategy

## Expected Business Impact:

- **Satisfaction**: 61% → 75%+ (14 percentage point improvement)
- **Revenue Protection**: $210M annually (14% × $15M per 1%)
- **ROI**: 10,480% ($210M benefit / $2M investment)
- **Payback**: ~4 days
- **Competitive Position**: Match Amazon (78%) and eBay (74%)

Good luck! This project synthesizes everything you've learned across all three modules.
