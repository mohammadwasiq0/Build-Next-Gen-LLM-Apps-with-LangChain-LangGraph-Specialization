# Module 1 HOL - Resource Files

## Files Included:

### 1. techmart_products.csv
- **Description**: TechMart product catalog with 5,000 electronics products
- **Columns**:
  - `product_id`: Unique identifier (e.g., TECH00001)
  - `title`: Product title with brand and color
  - `description`: Product description (95% have detailed descriptions, 5% have minimal descriptions to simulate data quality issues)
  - `category`: Product category (Laptops, Phones, Headphones, Cameras, Tablets)
  - `price`: Product price in USD

### 2. test_queries_with_ground_truth.csv
- **Description**: 50 test queries with ground truth relevance labels
- **Columns**:
  - `query_id`: Unique query identifier (Q001-Q050)
  - `query_text`: The search query (e.g., "wireless headphones", "gaming laptop")
  - `category`: Expected category for the query
  - `relevant_product_ids`: Comma-separated list of relevant product IDs (ground truth for recall calculation)

## Usage Instructions:

1. Load the product catalog CSV using pandas
2. Use the test queries to evaluate your search system
3. For each query, compare your top-10 retrieval results against the ground truth
4. Calculate recall@5 and recall@10 using the formula:
   - recall@k = (number of relevant items in top-k) / (total relevant items in ground truth)

## Example Code:

```python
import pandas as pd

# Load product catalog
products = pd.read_csv('techmart_products.csv')

# Load test queries
test_queries = pd.read_csv('test_queries_with_ground_truth.csv')

# Parse ground truth
test_queries['relevant_ids'] = test_queries['relevant_product_ids'].str.split(',')

# Your embedding and search code here...
```

## Success Criteria:

- Baseline recall@5 should improve from 47% (keyword) to 55%+ (embeddings)
- Your system should handle all 50 test queries
- Analyze failure patterns for queries with low recall scores
